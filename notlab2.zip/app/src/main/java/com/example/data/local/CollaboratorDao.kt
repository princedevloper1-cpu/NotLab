package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.Collaborator
import kotlinx.coroutines.flow.Flow

@Dao
interface CollaboratorDao {
    @Query("SELECT * FROM collaborators ORDER BY isCurrentUser DESC, id ASC")
    fun getAllCollaborators(): Flow<List<Collaborator>>

    @Query("SELECT COUNT(*) FROM collaborators")
    suspend fun getCollaboratorCount(): Int

    @Query("SELECT * FROM collaborators WHERE phoneNumber = :phone LIMIT 1")
    suspend fun getByPhone(phone: String): Collaborator?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollaborator(collaborator: Collaborator): Long

    @Update
    suspend fun updateCollaborator(collaborator: Collaborator)

    @Delete
    suspend fun deleteCollaborator(collaborator: Collaborator)

    @Query("UPDATE collaborators SET isOnline = :isOnline WHERE id = :id")
    suspend fun updateOnlineStatus(id: Long, isOnline: Boolean)
}
