package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.NotebookPage
import kotlinx.coroutines.flow.Flow

@Dao
interface NotebookDao {
    @Query("SELECT * FROM notebook_pages ORDER BY pageNumber ASC")
    fun getAllPages(): Flow<List<NotebookPage>>

    @Query("SELECT * FROM notebook_pages WHERE id = :id LIMIT 1")
    fun getPageById(id: Long): Flow<NotebookPage?>

    @Query("SELECT COUNT(*) FROM notebook_pages")
    suspend fun getPageCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPage(page: NotebookPage): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPages(pages: List<NotebookPage>)

    @Update
    suspend fun updatePage(page: NotebookPage)

    @Delete
    suspend fun deletePage(page: NotebookPage)

    @Query("DELETE FROM notebook_pages WHERE id = :id")
    suspend fun deletePageById(id: Long)

    @Query("DELETE FROM notebook_pages")
    suspend fun deleteAllPages()
}
