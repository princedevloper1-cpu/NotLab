package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.Collaborator
import com.example.data.model.NotebookPage

@Database(
    entities = [NotebookPage::class, Collaborator::class],
    version = 3,
    exportSchema = false
)
abstract class NotebookDatabase : RoomDatabase() {
    abstract fun notebookDao(): NotebookDao
    abstract fun collaboratorDao(): CollaboratorDao

    companion object {
        @Volatile
        private var INSTANCE: NotebookDatabase? = null

        fun getDatabase(context: Context): NotebookDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    NotebookDatabase::class.java,
                    "kaye_not_database"
                )
                    .fallbackToDestructiveMigration(true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
