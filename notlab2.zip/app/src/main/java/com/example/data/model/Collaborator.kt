package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "collaborators")
data class Collaborator(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val phoneNumber: String,
    val tag: String = "B", // "A", "B", "C" label shown in the left margin of the notebook line
    val assignedPages: String = "1", // comma separated page numbers e.g. "1, 2, 3"
    val avatarColor: Long = 0xFF2563EB,
    val canWrite: Boolean = true, // Authorization to write
    val isOnline: Boolean = false,
    val isCurrentUser: Boolean = false,
    val dateAdded: Long = System.currentTimeMillis()
) {
    fun getAssignedPageList(): List<Int> {
        return assignedPages.split(",")
            .mapNotNull { it.trim().toIntOrNull() }
    }
}

data class DeviceContact(
    val name: String,
    val phoneNumber: String,
    val hasNotlab: Boolean = false,
    val avatarUrl: String? = null
)
