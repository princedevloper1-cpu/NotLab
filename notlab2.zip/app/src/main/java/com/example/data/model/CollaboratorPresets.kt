package com.example.data.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight

/**
 * Definition of the 7 unique members (A, B, C, D, E, F, G).
 * Each user in the notebook has their own designated tag, color, style, badge, and handwriting distinction
 * to cleanly separate messages written on the notebook lines.
 */
data class AuthorProfile(
    val tag: String,
    val roleName: String,
    val colorHex: Long,
    val secondaryColorHex: Long,
    val badgeName: String
)

object CollaboratorPresets {
    /**
     * The fixed 7 Member slots (A through G).
     */
    val MEMBERS: List<AuthorProfile> = listOf(
        AuthorProfile(
            tag = "A",
            roleName = "Propriétaire (Auteur A)",
            colorHex = 0xFF1E3A8A, // Deep Classic Royal Blue
            secondaryColorHex = 0xFFDBEAFE,
            badgeName = "Auteur A (Bleu Royal)"
        ),
        AuthorProfile(
            tag = "B",
            roleName = "Collaborateur (Auteur B)",
            colorHex = 0xFF047857, // Emerald Green
            secondaryColorHex = 0xFFD1FAE5,
            badgeName = "Auteur B (Émeraude)"
        ),
        AuthorProfile(
            tag = "C",
            roleName = "Collaborateur (Auteur C)",
            colorHex = 0xFF7C3AED, // Violet / Purple
            secondaryColorHex = 0xFFEDE9FE,
            badgeName = "Auteur C (Violet)"
        ),
        AuthorProfile(
            tag = "D",
            roleName = "Collaborateur (Auteur D)",
            colorHex = 0xFFB45309, // Amber / Warm Brown Ochre
            secondaryColorHex = 0xFFFEF3C7,
            badgeName = "Auteur D (Ocre Ambré)"
        ),
        AuthorProfile(
            tag = "E",
            roleName = "Collaborateur (Auteur E)",
            colorHex = 0xFFBE185D, // Berry Rose / Magenta
            secondaryColorHex = 0xFFFCE7F3,
            badgeName = "Auteur E (Rose Magenta)"
        ),
        AuthorProfile(
            tag = "F",
            roleName = "Collaborateur (Auteur F)",
            colorHex = 0xFF0E7490, // Deep Cyan / Turquoise
            secondaryColorHex = 0xFFCFFAFE,
            badgeName = "Auteur F (Cyan Foncé)"
        ),
        AuthorProfile(
            tag = "G",
            roleName = "Collaborateur (Auteur G)",
            colorHex = 0xFFC2410C, // Terracotta / Crimson Rust
            secondaryColorHex = 0xFFFFEDD5,
            badgeName = "Auteur G (Terracotta)"
        )
    )

    val ALLOWED_TAGS: List<String> = MEMBERS.map { it.tag }

    fun getProfile(tag: String): AuthorProfile {
        return MEMBERS.firstOrNull { it.tag.equals(tag, ignoreCase = true) }
            ?: MEMBERS[0]
    }

    fun getColorForTag(tag: String): Color {
        return Color(getProfile(tag).colorHex)
    }

    fun getNextAvailableTag(existingTags: List<String>): String {
        val uppercaseExisting = existingTags.map { it.uppercase().trim() }.toSet()
        // Find first unused tag from B to G (since A is reserved for owner)
        return ALLOWED_TAGS.drop(1).firstOrNull { !uppercaseExisting.contains(it) } ?: "G"
    }
}
