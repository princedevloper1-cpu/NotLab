package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class DrawingPoint(
    val x: Float,
    val y: Float
)

enum class ToolType(val labelCreole: String, val labelFr: String) {
    PEN("Plim", "Plume"),
    PENCIL("Kreyon", "Crayon"),
    HIGHLIGHTER("Makè", "Surligneur"),
    ERASER("Gonm", "Gomme"),
    TEXT("Tèks", "Texte")
}

data class DrawingStroke(
    val id: String = UUID.randomUUID().toString(),
    val points: List<DrawingPoint>,
    val color: Long, // ARGB Long representation
    val strokeWidth: Float,
    val toolType: String = ToolType.PEN.name,
    val alpha: Float = 1.0f
) {
    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("color", color)
        json.put("strokeWidth", strokeWidth.toDouble())
        json.put("toolType", toolType)
        json.put("alpha", alpha.toDouble())

        val pointsArray = JSONArray()
        for (point in points) {
            val pointObj = JSONObject()
            pointObj.put("x", point.x.toDouble())
            pointObj.put("y", point.y.toDouble())
            pointsArray.put(pointObj)
        }
        json.put("points", pointsArray)
        return json
    }

    companion object {
        fun fromJson(json: JSONObject): DrawingStroke {
            val id = json.optString("id", UUID.randomUUID().toString())
            val color = json.optLong("color", 0xFF1E3A8A.toLong())
            val strokeWidth = json.optDouble("strokeWidth", 4.0).toFloat()
            val toolType = json.optString("toolType", ToolType.PEN.name)
            val alpha = json.optDouble("alpha", 1.0).toFloat()

            val pointsList = mutableListOf<DrawingPoint>()
            val pointsArray = json.optJSONArray("points")
            if (pointsArray != null) {
                for (i in 0 until pointsArray.length()) {
                    val pObj = pointsArray.getJSONObject(i)
                    pointsList.add(
                        DrawingPoint(
                            x = pObj.optDouble("x", 0.0).toFloat(),
                            y = pObj.optDouble("y", 0.0).toFloat()
                        )
                    )
                }
            }

            return DrawingStroke(
                id = id,
                points = pointsList,
                color = color,
                strokeWidth = strokeWidth,
                toolType = toolType,
                alpha = alpha
            )
        }

        fun listToJson(strokes: List<DrawingStroke>): String {
            val array = JSONArray()
            for (stroke in strokes) {
                array.put(stroke.toJson())
            }
            return array.toString()
        }

        fun listFromJson(jsonStr: String?): List<DrawingStroke> {
            if (jsonStr.isNullOrBlank()) return emptyList()
            val list = mutableListOf<DrawingStroke>()
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    list.add(fromJson(item))
                }
            } catch (e: Exception) {
                // Return empty if parsing error
            }
            return list
        }
    }
}
