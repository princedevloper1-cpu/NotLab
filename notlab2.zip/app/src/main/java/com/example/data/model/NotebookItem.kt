package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Represents a Notebook in Notlab.
 * Displayed on the Home screen ("Mes notes", "Partagées", "Favoris").
 */
data class NotebookItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val memberCount: Int = 1,
    val pageCount: Int = 1,
    val dateModified: Long = System.currentTimeMillis(),
    val isShared: Boolean = false,
    val isFavorite: Boolean = false,
    val coverTone: String = "ivory"
) {
    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("title", title)
        json.put("memberCount", memberCount)
        json.put("pageCount", pageCount)
        json.put("dateModified", dateModified)
        json.put("isShared", isShared)
        json.put("isFavorite", isFavorite)
        json.put("coverTone", coverTone)
        return json
    }

    companion object {
        fun fromJson(json: JSONObject): NotebookItem {
            return NotebookItem(
                id = json.optString("id", UUID.randomUUID().toString()),
                title = json.optString("title", "Sans titre"),
                memberCount = json.optInt("memberCount", 1),
                pageCount = json.optInt("pageCount", 1),
                dateModified = json.optLong("dateModified", System.currentTimeMillis()),
                isShared = json.optBoolean("isShared", false),
                isFavorite = json.optBoolean("isFavorite", false),
                coverTone = json.optString("coverTone", "ivory")
            )
        }

        fun listToJson(list: List<NotebookItem>): String {
            val array = JSONArray()
            for (item in list) {
                array.put(item.toJson())
            }
            return array.toString()
        }

        fun listFromJson(jsonStr: String?): List<NotebookItem> {
            if (jsonStr.isNullOrBlank()) return emptyList()
            val list = mutableListOf<NotebookItem>()
            try {
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    list.add(fromJson(array.getJSONObject(i)))
                }
            } catch (e: Exception) {
                // Return empty list on parse error
            }
            return list
        }
    }
}
