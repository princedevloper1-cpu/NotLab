package com.example.data.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * Represents a single line entry on the ruled notebook paper,
 * where each user gets their turn on a line.
 * Shows the author label (e.g., 'A', 'B', or Author Name) in the left margin,
 * exactly like handwriting/chat on ruled notebook lines.
 */
data class NotebookLineEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val pageNumber: Int,
    val lineIndex: Int, // 0 = first line, 1 = second line...
    val authorName: String,
    val authorPhone: String,
    val authorTag: String, // "A", "B", "C" or initials
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val authorColor: Long = 0xFF1E3A8A,
    val fontFamilyId: String = "handwriting_1",
    val fontSizeSp: Float = 17f,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val isUnderline: Boolean = false,
    val textColor: Long = 0xFF1E293B,
    val textAlign: String = "left"
) {
    fun toJson(): JSONObject {
        val json = JSONObject()
        json.put("id", id)
        json.put("pageNumber", pageNumber)
        json.put("lineIndex", lineIndex)
        json.put("authorName", authorName)
        json.put("authorPhone", authorPhone)
        json.put("authorTag", authorTag)
        json.put("content", content)
        json.put("timestamp", timestamp)
        json.put("authorColor", authorColor)
        json.put("fontFamilyId", fontFamilyId)
        json.put("fontSizeSp", fontSizeSp.toDouble())
        json.put("isBold", isBold)
        json.put("isItalic", isItalic)
        json.put("isUnderline", isUnderline)
        json.put("textColor", textColor)
        json.put("textAlign", textAlign)
        return json
    }

    companion object {
        fun fromJson(json: JSONObject): NotebookLineEntry {
            return NotebookLineEntry(
                id = json.optString("id", java.util.UUID.randomUUID().toString()),
                pageNumber = json.optInt("pageNumber", 1),
                lineIndex = json.optInt("lineIndex", 0),
                authorName = json.optString("authorName", "Moi"),
                authorPhone = json.optString("authorPhone", ""),
                authorTag = json.optString("authorTag", "A"),
                content = json.optString("content", ""),
                timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                authorColor = json.optLong("authorColor", 0xFF1E3A8A),
                fontFamilyId = json.optString("fontFamilyId", "handwriting_1"),
                fontSizeSp = json.optDouble("fontSizeSp", 17.0).toFloat(),
                isBold = json.optBoolean("isBold", false),
                isItalic = json.optBoolean("isItalic", false),
                isUnderline = json.optBoolean("isUnderline", false),
                textColor = json.optLong("textColor", 0xFF1E293B),
                textAlign = json.optString("textAlign", "left")
            )
        }

        fun listToJson(list: List<NotebookLineEntry>): String {
            val arr = JSONArray()
            for (item in list) {
                arr.put(item.toJson())
            }
            return arr.toString()
        }

        fun listFromJson(jsonStr: String?): List<NotebookLineEntry> {
            if (jsonStr.isNullOrBlank()) return emptyList()
            val result = mutableListOf<NotebookLineEntry>()
            try {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    result.add(fromJson(arr.getJSONObject(i)))
                }
            } catch (e: Exception) {
                // Return empty if parsing error
            }
            return result
        }
    }
}
