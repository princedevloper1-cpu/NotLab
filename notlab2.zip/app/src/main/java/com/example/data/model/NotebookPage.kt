package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "notebook_pages")
data class NotebookPage(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val pageNumber: Int,
    val title: String = "",
    val dateCreated: Long = System.currentTimeMillis(),
    val dateModified: Long = System.currentTimeMillis(),
    val strokesJson: String = "[]",
    val textContent: String = "",
    val linesJson: String = "[]", // Serialized List<NotebookLineEntry>
    val lineStyle: String = "ruled", // "ruled", "grid", "blank"
    val paperTone: String = "ivory"  // "ivory", "cream", "white", "blueprint"
)
