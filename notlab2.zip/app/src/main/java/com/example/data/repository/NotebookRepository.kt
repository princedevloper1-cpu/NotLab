package com.example.data.repository

import com.example.data.local.NotebookDao
import com.example.data.model.NotebookPage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class NotebookRepository(private val dao: NotebookDao) {

    val allPages: Flow<List<NotebookPage>> = dao.getAllPages()

    fun getPage(id: Long): Flow<NotebookPage?> = dao.getPageById(id)

    suspend fun insertPage(page: NotebookPage): Long = dao.insertPage(page)

    suspend fun updatePage(page: NotebookPage) = dao.updatePage(page)

    suspend fun deletePage(page: NotebookPage) {
        dao.deletePage(page)
        // Renumber remaining pages sequentially
        val remaining = dao.getAllPages().firstOrNull() ?: emptyList()
        val renumbered = remaining.mapIndexed { index, p ->
            p.copy(pageNumber = index + 1)
        }
        dao.insertPages(renumbered)
    }

    suspend fun deletePageById(id: Long) {
        dao.deletePageById(id)
        val remaining = dao.getAllPages().firstOrNull() ?: emptyList()
        val renumbered = remaining.mapIndexed { index, p ->
            p.copy(pageNumber = index + 1)
        }
        dao.insertPages(renumbered)
    }

    suspend fun ensureDefaultPage(): NotebookPage {
        val count = dao.getPageCount()
        if (count == 0) {
            val page2Lines = listOf(
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 0,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "Plan pou pwojè Notlab la:",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 1,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "[ ] Finaliser le design UI/UX",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 2,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "[ ] Développer le module temps réel",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 3,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "[ ] Connecter Google Sheets",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 4,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "[x] Tester avec Alexandre",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 5,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "[ ] Préparer la démo",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 6,
                    authorName = "Alexandre",
                    authorPhone = "+509 3712 3456",
                    authorTag = "B",
                    content = "Wi, nap fè sa ansanm ! 🚀",
                    authorColor = 0xFF2563EB
                ),
                com.example.data.model.NotebookLineEntry(
                    pageNumber = 2,
                    lineIndex = 7,
                    authorName = "John",
                    authorPhone = "+509 3700 1234",
                    authorTag = "A",
                    content = "Parfait !",
                    authorColor = 0xFF10B981
                )
            )

            val titles = listOf(
                "Aperçu du projet",
                "Plan pou pwojè Notlab la:",
                "Recherche & Idées",
                "Architecture Notlab",
                "Contacts & Téléphone",
                "Notes de réunion",
                "Maquettes & UI",
                "Feuille de route"
            )

            val initialPages = (1..8).map { num ->
                NotebookPage(
                    pageNumber = num,
                    title = titles.getOrElse(num - 1) { "Page $num" },
                    strokesJson = "[]",
                    textContent = if (num == 2) "Plan pou pwojè Notlab la:\n[ ] Finaliser le design UI/UX\n[ ] Développer le module temps réel\n[ ] Connecter Google Sheets\n[x] Tester avec Alexandre\n[ ] Préparer la démo" else "",
                    linesJson = if (num == 2) com.example.data.model.NotebookLineEntry.listToJson(page2Lines) else "[]",
                    lineStyle = "ruled"
                )
            }
            dao.insertPages(initialPages)
            val list = dao.getAllPages().firstOrNull() ?: emptyList()
            return list.getOrNull(1) ?: list.first()
        } else {
            val list = dao.getAllPages().firstOrNull() ?: emptyList()
            return list.getOrNull(1) ?: list.first()
        }
    }

    suspend fun addNewPage(): NotebookPage {
        val count = dao.getPageCount()
        val newPageNumber = count + 1
        val newPage = NotebookPage(
            pageNumber = newPageNumber,
            title = "Nòt $newPageNumber",
            strokesJson = "[]",
            textContent = "",
            lineStyle = "ruled"
        )
        val id = dao.insertPage(newPage)
        return newPage.copy(id = id)
    }
}
