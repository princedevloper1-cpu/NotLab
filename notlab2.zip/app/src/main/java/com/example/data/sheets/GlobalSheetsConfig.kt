package com.example.data.sheets

/**
 * Configuration globale de la base de données Google Sheets pour NotLab.app.
 * Contient le code Google Apps Script complet qui crée et configure automatiquement
 * tous les onglets (Users, Elements_Texte, Strokes_Dessin, Pages) avec leurs colonnes.
 */
object GlobalSheetsConfig {

    /**
     * URL par défaut du Webhook Google Apps Script pour l'application.
     */
    const val GLOBAL_APPS_SCRIPT_WEBHOOK_URL =
        "https://script.google.com/macros/s/AKfycbyaIao4AkSOYHjVuUvxMOccZeEwBA6u-Zf115eaRJsNed6UlOBgg_JbD0CF3MQcSZ0BiA/exec"

    /**
     * Code Google Apps Script complet à copier dans Extensions > Apps Script du Google Sheet.
     */
    val APPS_SCRIPT_SOURCE = """
        /**
         * ===================================================================
         * NOTLAB.APP - GOOGLE SHEETS DATABASE BACKEND (APPS SCRIPT)
         * ===================================================================
         * Ce script configure automatiquement toutes les tables (onglets) 
         * et leurs colonnes pour gérer les utilisateurs, les éléments de texte
         * et les strokes de dessin de manière granulaire et collaborative.
         */

        // 1. Menu personnalisé dans Google Sheets pour créer/vérifier les tables en 1 clic
        function onOpen() {
          var ui = SpreadsheetApp.getUi();
          ui.createMenu("📓 NotLab Base de Données")
            .addItem("⚡ Initialiser / Vérifier les Tables", "setupDatabase")
            .addToUi();
        }

        // 2. Initialisation automatique de toutes les tables et colonnes
        function setupDatabase() {
          var ss = SpreadsheetApp.getActiveSpreadsheet();

          // Table 1 : Users (Utilisateurs inscrits)
          initSheet(ss, "Users", [
            "User ID", "Nom d'utilisateur", "Téléphone", "Date d'inscription", "Statut"
          ], "#1E3A8A"); // Bleu Nuit

          // Table 2 : Elements_Texte (Textes par élément et par ligne)
          initSheet(ss, "Elements_Texte", [
            "Element ID", "Page ID", "User ID", "Nom Auteur", "Tag Auteur", "Ligne Index", "Contenu", "Couleur", "Dernière Modification"
          ], "#0F9D58"); // Vert Google Sheets

          // Table 3 : Strokes_Dessin (Tracés et dessins granulaires)
          initSheet(ss, "Strokes_Dessin", [
            "Stroke ID", "Page ID", "User ID", "Type Outil", "Couleur", "Épaisseur", "Points (JSON)", "Dernière Modification"
          ], "#E65100"); // Ambre / Orange

          // Table 4 : Pages (Métadonnées des pages du cahier)
          initSheet(ss, "Pages", [
            "Page ID", "Numéro Page", "Titre", "Nombre Lignes", "Confidentiel", "Dernière Modification"
          ], "#5E35B1"); // Violet

          // Supprimer ou masquer l'onglet vide par défaut 'Feuille 1' s'il n'est plus utile
          var defaultSheet = ss.getSheetByName("Feuille 1") || ss.getSheetByName("Sheet1");
          if (defaultSheet && defaultSheet.getLastRow() === 0 && ss.getSheets().length > 1) {
            try { ss.deleteSheet(defaultSheet); } catch(e) {}
          }

          Logger.log("✅ Toutes les tables NotLab.app ont été créées avec succès !");
        }

        // Fonction utilitaire pour créer et styliser une table
        function initSheet(ss, sheetName, headers, headerColor) {
          var sheet = ss.getSheetByName(sheetName);
          if (!sheet) {
            sheet = ss.insertSheet(sheetName);
          }
          
          // Si la première ligne est vide, on ajoute les en-têtes
          if (sheet.getLastRow() === 0) {
            sheet.appendRow(headers);
          } else {
            // S'assurer que les en-têtes correspondent
            sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
          }

          // Mise en forme professionnelle des en-têtes
          var headerRange = sheet.getRange(1, 1, 1, headers.length);
          headerRange.setFontWeight("bold")
                     .setFontColor("#FFFFFF")
                     .setBackground(headerColor)
                     .setHorizontalAlignment("center");
          
          sheet.setFrozenRows(1); // Figer la ligne d'en-tête
          sheet.autoResizeColumns(1, headers.length);
          return sheet;
        }

        // 3. Réception des requêtes POST envoyées par l'application
        function doPost(e) {
          var lock = LockService.getScriptLock();
          lock.tryLock(10000); // Éviter les conflits de concurrence

          try {
            setupDatabase(); // S'assurer que les tables existent toujours
            var ss = SpreadsheetApp.getActiveSpreadsheet();

            if (!e || !e.postData || !e.postData.contents) {
              return jsonResponse({ status: "error", message: "Aucune donnée reçue" });
            }

            var data = JSON.parse(e.postData.contents);
            var action = data.action || "register_user"; // Action par défaut si inscription

            var now = new Date().toLocaleString();

            // CAS A : Inscription Utilisateur
            if (action === "register_user" || (!data.action && data.name)) {
              var userSheet = ss.getSheetByName("Users");
              var userId = data.id || data.user_id || ("USER-" + new Date().getTime());
              var name = data.name || "";
              var phone = data.phone || "";
              var date = data.date || now;
              var status = data.status || "Actif";

              userSheet.appendRow([userId, name, phone, date, status]);
              return jsonResponse({ status: "success", message: "Utilisateur enregistré avec succès", user_id: userId });
            }

            // CAS B : Sauvegarde d'un Élément Texte granulaire
            if (action === "save_element") {
              var elemSheet = ss.getSheetByName("Elements_Texte");
              var elemId = data.element_id || ("EL-" + new Date().getTime());
              var pageId = data.page_id || "page_001";
              var userId = data.user_id || "";
              var authorName = data.author_name || "";
              var authorTag = data.author_tag || "A";
              var lineIndex = data.line_index !== undefined ? data.line_index : -1;
              var content = data.content || "";
              var color = data.color || "#121212";

              elemSheet.appendRow([elemId, pageId, userId, authorName, authorTag, lineIndex, content, color, now]);
              return jsonResponse({ status: "success", message: "Élément texte enregistré", element_id: elemId });
            }

            // CAS C : Sauvegarde d'un Stroke (Dessin / Tracé de plume)
            if (action === "save_stroke") {
              var strokeSheet = ss.getSheetByName("Strokes_Dessin");
              var strokeId = data.stroke_id || ("STRK-" + new Date().getTime());
              var pageId = data.page_id || "page_001";
              var userId = data.user_id || "";
              var toolType = data.tool_type || "PEN";
              var color = data.color || "#000000";
              var width = data.width || 3.0;
              var points = typeof data.points === "string" ? data.points : JSON.stringify(data.points || []);

              strokeSheet.appendRow([strokeId, pageId, userId, toolType, color, width, points, now]);
              return jsonResponse({ status: "success", message: "Stroke enregistré", stroke_id: strokeId });
            }

            // CAS D : Batch de plusieurs éléments/strokes
            if (action === "sync_batch") {
              if (data.elements && data.elements.length > 0) {
                var elemSheet = ss.getSheetByName("Elements_Texte");
                data.elements.forEach(function(el) {
                  elemSheet.appendRow([
                    el.element_id || ("EL-" + new Date().getTime()),
                    el.page_id || "page_001",
                    el.user_id || "",
                    el.author_name || "",
                    el.author_tag || "A",
                    el.line_index !== undefined ? el.line_index : -1,
                    el.content || "",
                    el.color || "#121212",
                    now
                  ]);
                });
              }

              if (data.strokes && data.strokes.length > 0) {
                var strokeSheet = ss.getSheetByName("Strokes_Dessin");
                data.strokes.forEach(function(st) {
                  strokeSheet.appendRow([
                    st.stroke_id || ("STRK-" + new Date().getTime()),
                    st.page_id || "page_001",
                    st.user_id || "",
                    st.tool_type || "PEN",
                    st.color || "#000000",
                    st.width || 3.0,
                    typeof st.points === "string" ? st.points : JSON.stringify(st.points || []),
                    now
                  ]);
                });
              }

              return jsonResponse({ status: "success", message: "Synchronisation batch effectuée" });
            }

            return jsonResponse({ status: "error", message: "Action non reconnue: " + action });

          } catch (err) {
            return jsonResponse({ status: "error", message: err.toString() });
          } finally {
            lock.releaseLock();
          }
        }

        // 4. Réception des requêtes GET (pour tester ou lire les données)
        function doGet(e) {
          try {
            setupDatabase();
            var action = e && e.parameter ? e.parameter.action : "init";

            if (action === "init") {
              return jsonResponse({
                status: "success",
                message: "Base de données NotLab.app prête et initialisée avec succès !",
                tables: ["Users", "Elements_Texte", "Strokes_Dessin", "Pages"]
              });
            }

            return jsonResponse({ status: "success", message: "API NotLab.app en ligne" });
          } catch(err) {
            return jsonResponse({ status: "error", message: err.toString() });
          }
        }

        function jsonResponse(obj) {
          return ContentService.createTextOutput(JSON.stringify(obj))
            .setMimeType(ContentService.MimeType.JSON);
        }
    """.trimIndent()
}

