package com.example.data.sheets

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class CreateSpreadsheetRequest(
    val properties: SpreadsheetProperties,
    val sheets: List<SheetData>? = null
)

@JsonClass(generateAdapter = true)
data class SpreadsheetProperties(
    val title: String
)

@JsonClass(generateAdapter = true)
data class SheetData(
    val properties: SheetInnerProperties
)

@JsonClass(generateAdapter = true)
data class SheetInnerProperties(
    val sheetId: Int? = null,
    val title: String
)

@JsonClass(generateAdapter = true)
data class SpreadsheetResponse(
    val spreadsheetId: String,
    val properties: SpreadsheetProperties? = null,
    val spreadsheetUrl: String? = null
)

@JsonClass(generateAdapter = true)
data class ValueRange(
    val range: String? = null,
    val majorDimension: String = "ROWS",
    val values: List<List<String>> = emptyList()
)

@JsonClass(generateAdapter = true)
data class AppendValuesResponse(
    val spreadsheetId: String? = null,
    val tableRange: String? = null,
    val updates: UpdateValuesResponse? = null
)

@JsonClass(generateAdapter = true)
data class UpdateValuesResponse(
    val spreadsheetId: String? = null,
    val updatedRange: String? = null,
    val updatedRows: Int? = null,
    val updatedColumns: Int? = null,
    val updatedCells: Int? = null
)

@JsonClass(generateAdapter = true)
data class GoogleUserInfo(
    val sub: String? = null,
    val name: String? = null,
    val email: String? = null,
    val picture: String? = null
)
