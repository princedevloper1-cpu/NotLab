package com.example.data.sheets

import android.content.Context
import android.util.Log
import com.example.data.model.Collaborator
import com.example.data.model.NotebookLineEntry
import com.example.data.model.NotebookPage
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

class GoogleSheetsSyncService(private val context: Context) {

    private val prefs = context.getSharedPreferences("google_sheets_sync_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "SheetsSync"
        private const val BASE_URL = "https://sheets.googleapis.com/"
        private const val PREF_SPREADSHEET_ID = "pref_spreadsheet_id"
        private const val PREF_SPREADSHEET_URL = "pref_spreadsheet_url"
        private const val PREF_ACCESS_TOKEN = "pref_access_token"
        private const val PREF_AUTO_SYNC = "pref_auto_sync_enabled"
        private const val PREF_LAST_SYNC_TIME = "pref_last_sync_time"
    }

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private val apiService: GoogleSheetsApiService = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GoogleSheetsApiService::class.java)

    fun getSpreadsheetId(): String? = prefs.getString(PREF_SPREADSHEET_ID, null)
    fun getSpreadsheetUrl(): String? = prefs.getString(PREF_SPREADSHEET_URL, null)
    fun getAccessToken(): String? = prefs.getString(PREF_ACCESS_TOKEN, null)
    fun isAutoSyncEnabled(): Boolean = prefs.getBoolean(PREF_AUTO_SYNC, true)
    fun getLastSyncTime(): Long = prefs.getLong(PREF_LAST_SYNC_TIME, 0L)

    fun saveSpreadsheetInfo(id: String, url: String?) {
        prefs.edit()
            .putString(PREF_SPREADSHEET_ID, id)
            .putString(PREF_SPREADSHEET_URL, url)
            .apply()
    }

    fun saveAccessToken(token: String) {
        prefs.edit().putString(PREF_ACCESS_TOKEN, token.trim()).apply()
    }

    fun setAutoSyncEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(PREF_AUTO_SYNC, enabled).apply()
    }

    fun markLastSyncTime() {
        prefs.edit().putLong(PREF_LAST_SYNC_TIME, System.currentTimeMillis()).apply()
    }

    /**
     * Initializes or connects to a Google Spreadsheet.
     * If no spreadsheetId exists, it creates one titled "Cahier NotLab - Partagé".
     */
    suspend fun getOrCreateSpreadsheet(token: String): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        try {
            val existingId = getSpreadsheetId()
            val authHeader = "Bearer $token"

            if (!existingId.isNullOrBlank()) {
                val checkResponse = apiService.getSpreadsheet(authHeader, existingId)
                if (checkResponse.isSuccessful) {
                    val body = checkResponse.body()
                    val url = body?.spreadsheetUrl ?: "https://docs.google.com/spreadsheets/d/$existingId"
                    saveSpreadsheetInfo(existingId, url)
                    return@withContext Result.success(Pair(existingId, url))
                }
            }

            // Create new spreadsheet
            val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.FRENCH)
            val sheetTitle = "Cahier NotLab - ${dateFormat.format(Date())}"
            val request = CreateSpreadsheetRequest(
                properties = SpreadsheetProperties(title = sheetTitle),
                sheets = listOf(
                    SheetData(SheetInnerProperties(sheetId = 0, title = "Pages_Cahier")),
                    SheetData(SheetInnerProperties(sheetId = 1, title = "Lignes_Collaborateurs"))
                )
            )

            val createResponse = apiService.createSpreadsheet(authHeader, request)
            if (createResponse.isSuccessful && createResponse.body() != null) {
                val created = createResponse.body()!!
                val newId = created.spreadsheetId
                val newUrl = created.spreadsheetUrl ?: "https://docs.google.com/spreadsheets/d/$newId"
                saveSpreadsheetInfo(newId, newUrl)

                // Initialize headers
                setupInitialHeaders(authHeader, newId)

                Result.success(Pair(newId, newUrl))
            } else {
                val err = createResponse.errorBody()?.string() ?: "Erreur HTTP ${createResponse.code()}"
                Result.failure(Exception("Échec de création Google Sheet: $err"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getOrCreateSpreadsheet", e)
            Result.failure(e)
        }
    }

    private suspend fun setupInitialHeaders(authHeader: String, spreadsheetId: String) {
        try {
            // Header for Pages_Cahier
            val pagesHeader = ValueRange(
                range = "Pages_Cahier!A1:E1",
                values = listOf(
                    listOf("Numéro Page", "Titre", "Contenu Texte", "Dernière Modification", "Total Lignes")
                )
            )
            apiService.updateValues(authHeader, spreadsheetId, "Pages_Cahier!A1:E1", body = pagesHeader)

            // Header for Lignes_Collaborateurs (A, B, A, B...)
            val linesHeader = ValueRange(
                range = "Lignes_Collaborateurs!A1:G1",
                values = listOf(
                    listOf("Page", "Ligne", "Auteur Tag (A, B...)", "Nom Auteur", "Téléphone", "Contenu Ligne", "Date")
                )
            )
            apiService.updateValues(authHeader, spreadsheetId, "Lignes_Collaborateurs!A1:G1", body = linesHeader)
        } catch (e: Exception) {
            Log.w(TAG, "Failed setting up initial headers: ${e.message}")
        }
    }

    /**
     * Uploads the notebook pages and all line entries to Google Sheets.
     */
    suspend fun syncAllToSheets(
        token: String,
        pages: List<NotebookPage>,
        collaborators: List<Collaborator>
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val sheetInfo = getOrCreateSpreadsheet(token).getOrThrow()
            val spreadsheetId = sheetInfo.first
            val authHeader = "Bearer $token"
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

            // 1. Prepare Pages_Cahier rows
            val pageRows = mutableListOf<List<String>>()
            // Add header
            pageRows.add(listOf("Numéro Page", "Titre", "Contenu Texte", "Dernière Modification", "Total Lignes"))

            val allLinesRows = mutableListOf<List<String>>()
            // Add lines header
            allLinesRows.add(listOf("Page", "Ligne", "Auteur Tag (A, B...)", "Nom Auteur", "Téléphone", "Contenu Ligne", "Date"))

            pages.sortedBy { it.pageNumber }.forEach { page ->
                val lines = NotebookLineEntry.listFromJson(page.linesJson)
                pageRows.add(
                    listOf(
                        page.pageNumber.toString(),
                        page.title.ifBlank { "Page ${page.pageNumber}" },
                        page.textContent,
                        dateFormat.format(Date(page.dateModified)),
                        lines.size.toString()
                    )
                )

                lines.forEachIndexed { idx, line ->
                    allLinesRows.add(
                        listOf(
                            page.pageNumber.toString(),
                            (idx + 1).toString(),
                            line.authorTag,
                            line.authorName,
                            line.authorPhone,
                            line.content,
                            dateFormat.format(Date(line.timestamp))
                        )
                    )
                }
            }

            // Push Pages_Cahier
            apiService.updateValues(
                authHeader = authHeader,
                spreadsheetId = spreadsheetId,
                range = "Pages_Cahier!A1:E${pageRows.size}",
                body = ValueRange(range = "Pages_Cahier!A1:E${pageRows.size}", values = pageRows)
            )

            // Push Lignes_Collaborateurs
            apiService.updateValues(
                authHeader = authHeader,
                spreadsheetId = spreadsheetId,
                range = "Lignes_Collaborateurs!A1:G${allLinesRows.size}",
                body = ValueRange(range = "Lignes_Collaborateurs!A1:G${allLinesRows.size}", values = allLinesRows)
            )

            markLastSyncTime()
            Result.success(sheetInfo.second)
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing to sheets", e)
            Result.failure(e)
        }
    }

    /**
     * Appends a newly written line entry immediately to the Google Sheet.
     */
    suspend fun appendSingleLine(
        token: String,
        pageNumber: Int,
        lineNumber: Int,
        entry: NotebookLineEntry
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val spreadsheetId = getSpreadsheetId() ?: return@withContext Result.failure(Exception("Pas de feuille configurée"))
            val authHeader = "Bearer $token"
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

            val row = listOf(
                pageNumber.toString(),
                lineNumber.toString(),
                entry.authorTag,
                entry.authorName,
                entry.authorPhone,
                entry.content,
                dateFormat.format(Date(entry.timestamp))
            )

            val body = ValueRange(
                values = listOf(row)
            )

            apiService.appendValues(
                authHeader = authHeader,
                spreadsheetId = spreadsheetId,
                range = "Lignes_Collaborateurs!A:G",
                body = body
            )

            markLastSyncTime()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error appending line to sheet", e)
            Result.failure(e)
        }
    }

    /**
     * Reads lines from Google Sheet to import edits made by others.
     */
    suspend fun fetchLinesFromSheet(token: String): Result<List<List<String>>> = withContext(Dispatchers.IO) {
        try {
            val spreadsheetId = getSpreadsheetId() ?: return@withContext Result.failure(Exception("Pas de feuille connectée"))
            val authHeader = "Bearer $token"

            val resp = apiService.getValues(
                authHeader = authHeader,
                spreadsheetId = spreadsheetId,
                range = "Lignes_Collaborateurs!A2:G500"
            )

            if (resp.isSuccessful && resp.body() != null) {
                Result.success(resp.body()!!.values)
            } else {
                Result.failure(Exception("Erreur lecture: ${resp.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
