package com.example.data.sheets

import android.content.Context
import android.util.Log
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Service to manage User Registrations in a central Google Spreadsheet database.
 * Every user who signs up or enters their Name & Phone Number will have their account
 * registered into the central "Utilisateurs_Inscrits" sheet.
 */
class UserRegistrationSheetsService(private val context: Context) {

    private val prefs = context.getSharedPreferences("user_registration_sheets_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val TAG = "UserRegSheets"
        private const val BASE_URL = "https://sheets.googleapis.com/"
        private const val PREF_USERS_SPREADSHEET_ID = "pref_users_spreadsheet_id"
        private const val PREF_USERS_SPREADSHEET_URL = "pref_users_spreadsheet_url"
        private const val PREF_IS_USER_REGISTERED = "pref_is_user_registered"
        private const val PREF_REGISTERED_USER_NAME = "pref_registered_user_name"
        private const val PREF_REGISTERED_USER_PHONE = "pref_registered_user_phone"
        private const val PREF_REGISTERED_USER_DATE = "pref_registered_user_date"
        private const val PREF_ACCESS_TOKEN = "pref_reg_access_token"
        private const val PREF_WEBHOOK_URL = "pref_reg_webhook_url"
    }

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        })
        .build()

    private val apiService: GoogleSheetsApiService = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(GoogleSheetsApiService::class.java)

    fun isUserRegistered(): Boolean = prefs.getBoolean(PREF_IS_USER_REGISTERED, false)
    fun getRegisteredUserName(): String = prefs.getString(PREF_REGISTERED_USER_NAME, "") ?: ""
    fun getRegisteredUserPhone(): String = prefs.getString(PREF_REGISTERED_USER_PHONE, "") ?: ""
    fun getUsersSpreadsheetId(): String? = prefs.getString(PREF_USERS_SPREADSHEET_ID, null)
    fun getUsersSpreadsheetUrl(): String? = prefs.getString(PREF_USERS_SPREADSHEET_URL, null)
    fun getAccessToken(): String? = prefs.getString(PREF_ACCESS_TOKEN, null)
    fun getWebhookUrl(): String? = prefs.getString(PREF_WEBHOOK_URL, null)

    fun saveAccessToken(token: String) {
        prefs.edit().putString(PREF_ACCESS_TOKEN, token.trim()).apply()
    }

    fun saveWebhookUrl(url: String) {
        prefs.edit().putString(PREF_WEBHOOK_URL, url.trim()).apply()
    }

    fun saveUsersSpreadsheetInfo(id: String, url: String?) {
        prefs.edit()
            .putString(PREF_USERS_SPREADSHEET_ID, id)
            .putString(PREF_USERS_SPREADSHEET_URL, url)
            .apply()
    }

    fun markLocalRegistration(name: String, phone: String) {
        prefs.edit()
            .putBoolean(PREF_IS_USER_REGISTERED, true)
            .putString(PREF_REGISTERED_USER_NAME, name.trim())
            .putString(PREF_REGISTERED_USER_PHONE, phone.trim())
            .putLong(PREF_REGISTERED_USER_DATE, System.currentTimeMillis())
            .apply()
    }

    fun resetRegistration() {
        prefs.edit()
            .putBoolean(PREF_IS_USER_REGISTERED, false)
            .remove(PREF_REGISTERED_USER_NAME)
            .remove(PREF_REGISTERED_USER_PHONE)
            .remove(PREF_REGISTERED_USER_DATE)
            .apply()
    }

    /**
     * Enregistre l'utilisateur directement dans la base de données Google Sheets globale
     * via le Webhook centralisé Google Apps Script. L'utilisateur final n'a aucun lien à saisir.
     */
    suspend fun registerUser(
        name: String,
        phone: String,
        webhookUrl: String? = null,
        token: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()

        val effectiveWebhook = (webhookUrl ?: getWebhookUrl())?.trim()
            ?.ifBlank { null }
            ?: GlobalSheetsConfig.GLOBAL_APPS_SCRIPT_WEBHOOK_URL

        // Sauvegarder automatiquement l'URL du Webhook s'il s'agit d'un lien Apps Script valide
        if (effectiveWebhook.isNotBlank() && !effectiveWebhook.contains("global_cahier_database")) {
            saveWebhookUrl(effectiveWebhook)
        }

        try {
            val jsonMediaType = "application/json; charset=utf-8".toMediaType()
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            val jsonBody = """
                {
                    "action": "register_user",
                    "id": "USER-${System.currentTimeMillis().toString().takeLast(6)}",
                    "name": "${cleanName.replace("\"", "\\\"")}",
                    "phone": "${cleanPhone.replace("\"", "\\\"")}",
                    "date": "${dateFormat.format(Date())}",
                    "status": "Actif"
                }
            """.trimIndent()

            val req = okhttp3.Request.Builder()
                .url(effectiveWebhook)
                .post(jsonBody.toRequestBody(jsonMediaType))
                .build()

            val response = okHttpClient.newCall(req).execute()
            val code = response.code
            val respBody = response.body?.string() ?: ""
            response.close()
            Log.d(TAG, "Webhook registration response HTTP $code: $respBody")

            if (code in 200..302) {
                markLocalRegistration(cleanName, cleanPhone)
                Result.success("Utilisateur enregistré avec succès dans la base de données Google Sheets globale !")
            } else {
                markLocalRegistration(cleanName, cleanPhone)
                Result.success("Profil enregistré. En attente de synchronisation avec le Google Sheet central.")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Connexion au Webhook Google Sheets en attente, enregistrement conservé", e)
            markLocalRegistration(cleanName, cleanPhone)
            Result.success("Profil enregistré. Les données seront synchronisées avec la base Google Sheets.")
        }
    }

    /**
     * Initializes or connects to the central Users database Google Sheet.
     */
    suspend fun getOrCreateUsersSpreadsheet(token: String): Result<Pair<String, String>> = withContext(Dispatchers.IO) {
        try {
            val existingId = getUsersSpreadsheetId()
            val authHeader = "Bearer $token"

            if (!existingId.isNullOrBlank()) {
                val check = apiService.getSpreadsheet(authHeader, existingId)
                if (check.isSuccessful) {
                    val body = check.body()
                    val url = body?.spreadsheetUrl ?: "https://docs.google.com/spreadsheets/d/$existingId"
                    saveUsersSpreadsheetInfo(existingId, url)
                    return@withContext Result.success(Pair(existingId, url))
                }
            }

            // Create central users database
            val request = CreateSpreadsheetRequest(
                properties = SpreadsheetProperties(title = "Base de Données Utilisateurs - NotLab"),
                sheets = listOf(
                    SheetData(SheetInnerProperties(sheetId = 0, title = "Utilisateurs_Inscrits"))
                )
            )

            val createResp = apiService.createSpreadsheet(authHeader, request)
            if (createResp.isSuccessful && createResp.body() != null) {
                val created = createResp.body()!!
                val newId = created.spreadsheetId
                val newUrl = created.spreadsheetUrl ?: "https://docs.google.com/spreadsheets/d/$newId"
                saveUsersSpreadsheetInfo(newId, newUrl)

                // Header for Utilisateurs_Inscrits
                val header = ValueRange(
                    range = "Utilisateurs_Inscrits!A1:E1",
                    values = listOf(
                        listOf("ID Utilisateur", "Nom d'utilisateur", "Numéro de Téléphone", "Date d'inscription", "Statut")
                    )
                )
                apiService.updateValues(authHeader, newId, "Utilisateurs_Inscrits!A1:E1", body = header)

                Result.success(Pair(newId, newUrl))
            } else {
                val err = createResp.errorBody()?.string() ?: "Code ${createResp.code()}"
                Result.failure(Exception("Échec création Base Utilisateurs: $err"))
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in getOrCreateUsersSpreadsheet", e)
            Result.failure(e)
        }
    }

    /**
     * Records a new user registration to the central Google Sheet database.
     */
    suspend fun registerUserToSheet(
        token: String?,
        name: String,
        phone: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val effectiveToken = token ?: getAccessToken()
            if (effectiveToken.isNullOrBlank()) {
                return@withContext Result.failure(Exception("Jeton d'accès Google Sheets manquant."))
            }

            val sheetInfo = getOrCreateUsersSpreadsheet(effectiveToken).getOrThrow()
            val spreadsheetId = sheetInfo.first
            val authHeader = "Bearer $effectiveToken"
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())

            val row = listOf(
                "USER-${System.currentTimeMillis().toString().takeLast(6)}",
                name.trim(),
                phone.trim(),
                dateFormat.format(Date()),
                "Actif"
            )

            val body = ValueRange(values = listOf(row))
            apiService.appendValues(
                authHeader = authHeader,
                spreadsheetId = spreadsheetId,
                range = "Utilisateurs_Inscrits!A:E",
                body = body
            )

            markLocalRegistration(name, phone)
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error registering user to sheet", e)
            Result.failure(e)
        }
    }
}
