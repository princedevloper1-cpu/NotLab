package com.example.data.util

import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat
import com.example.data.model.DeviceContact

object ContactHelper {

    fun hasContactPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun fetchDeviceContacts(context: Context): List<DeviceContact> {
        if (!hasContactPermission(context)) {
            return getFallbackContacts()
        }

        val contactsList = mutableListOf<DeviceContact>()
        val contentResolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val sortOrder = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"

        try {
            contentResolver.query(uri, projection, null, null, sortOrder)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIndex = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                while (cursor.moveToNext()) {
                    val name = if (nameIndex >= 0) cursor.getString(nameIndex) ?: "" else ""
                    val number = if (numberIndex >= 0) cursor.getString(numberIndex) ?: "" else ""
                    if (name.isNotBlank() && number.isNotBlank()) {
                        val cleanedNumber = number.replace(" ", "").replace("-", "")
                        contactsList.add(DeviceContact(name, cleanedNumber))
                    }
                }
            }
        } catch (e: Exception) {
            // Fallback if query fails
            return getFallbackContacts()
        }

        return if (contactsList.isNotEmpty()) {
            contactsList.distinctBy { it.phoneNumber }
        } else {
            getFallbackContacts()
        }
    }

    fun getFallbackContacts(): List<DeviceContact> {
        return listOf(
            DeviceContact("Alexandre", "+509 3712 3456", hasNotlab = true),
            DeviceContact("Marie Joseph", "+509 4821 7890", hasNotlab = true),
            DeviceContact("Pierre Michel", "+509 3145 6789", hasNotlab = true),
            DeviceContact("Sophie Augustin", "+509 4234 5678", hasNotlab = true),
            DeviceContact("Jean Dupont", "+509 3788 1234", hasNotlab = false),
            DeviceContact("Nathalie Clerc", "+509 4678 1234", hasNotlab = false),
            DeviceContact("David Paul", "+509 3890 4321", hasNotlab = false),
            DeviceContact("Marc Antoine", "+509 3678 9012", hasNotlab = false)
        )
    }

    /**
     * Checks if a phone number contains exactly 8 digits (excluding country code).
     * Example: 1234 5678, 3712 3456.
     */
    fun isExact8Digits(rawInput: String): Boolean {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return digitsOnly.length == 8
    }

    /**
     * Formats 8 digits cleanly as "1234 5678".
     */
    fun format8Digits(rawInput: String): String {
        val digits = rawInput.filter { it.isDigit() }.take(8)
        return if (digits.length > 4) {
            "${digits.take(4)} ${digits.drop(4)}"
        } else {
            digits
        }
    }

    /**
     * Validates if a phone number is plausible:
     * - Must contain at least 8 digits
     * - Only allows +, digits, spaces, hyphens, and parenthesis
     */
    fun isValidPhoneNumber(phone: String): Boolean {
        val digitsOnly = phone.filter { it.isDigit() }
        if (digitsOnly.length < 8 || digitsOnly.length > 15) {
            return false
        }
        val allowedPattern = Regex("^[+]?[0-9\\s-()]+$")
        return allowedPattern.matches(phone.trim())
    }

    /**
     * Formats a phone number cleanly.
     * If user enters an 8-digit Haitian number like "37001234", formats to "+509 3700 1234".
     */
    fun formatPhoneNumber(phone: String, countryCode: String = "+509"): String {
        val trimmed = phone.trim()
        val digits = trimmed.filter { it.isDigit() }
        return when {
            trimmed.startsWith("+") -> trimmed
            digits.length == 8 -> "$countryCode ${digits.take(4)} ${digits.drop(4)}"
            digits.startsWith("509") && digits.length == 11 -> "+509 ${digits.drop(3).take(4)} ${digits.takeLast(4)}"
            else -> if (digits.isNotEmpty()) "$countryCode $digits" else trimmed
        }
    }
}
