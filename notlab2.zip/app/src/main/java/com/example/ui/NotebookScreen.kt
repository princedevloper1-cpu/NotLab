package com.example.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AuthOnboardingScreen
import com.example.ui.components.CollaborationDialog
import com.example.ui.components.GoogleSheetsSyncDialog
import com.example.ui.components.HomeScreen
import com.example.ui.components.NotebookPaper
import com.example.ui.components.NotebookToolbar
import com.example.ui.components.PageListSheet
import com.example.ui.components.PageNavigationHeader
import com.example.ui.components.PagesBottomSheet
import com.example.ui.components.TypographyBottomSheet
import com.example.ui.components.UserRegistrationDialog
import com.example.ui.viewmodel.NotebookViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotebookScreen(
    viewModel: NotebookViewModel,
    modifier: Modifier = Modifier
) {
    val pages by viewModel.pages.collectAsStateWithLifecycle()
    val currentPageIndex by viewModel.currentPageIndex.collectAsStateWithLifecycle()
    val currentPage by viewModel.currentPage.collectAsStateWithLifecycle()
    val strokes by viewModel.strokes.collectAsStateWithLifecycle()
    val lineEntries by viewModel.lineEntries.collectAsStateWithLifecycle()
    val canUndo by viewModel.canUndo.collectAsStateWithLifecycle()
    val canRedo by viewModel.canRedo.collectAsStateWithLifecycle()
    val selectedTool by viewModel.selectedTool.collectAsStateWithLifecycle()
    val selectedColor by viewModel.selectedColor.collectAsStateWithLifecycle()
    val strokeWidth by viewModel.strokeWidth.collectAsStateWithLifecycle()
    val textContent by viewModel.textContent.collectAsStateWithLifecycle()
    val pageTitle by viewModel.pageTitle.collectAsStateWithLifecycle()
    val lineStyle by viewModel.lineStyle.collectAsStateWithLifecycle()
    val paperTone by viewModel.paperTone.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()

    // Screen navigation & Home notebooks
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val notebooks by viewModel.notebooks.collectAsStateWithLifecycle()

    // Drawing settings
    val isStrokeSmoothingEnabled by viewModel.isStrokeSmoothingEnabled.collectAsStateWithLifecycle()
    val penStyle by viewModel.penStyle.collectAsStateWithLifecycle()
    val isPenSettingsOpen by viewModel.isPenSettingsOpen.collectAsStateWithLifecycle()
    val isPagesSheetOpen by viewModel.isPagesSheetOpen.collectAsStateWithLifecycle()

    // Typography states
    val selectedFontId by viewModel.selectedFontId.collectAsStateWithLifecycle()
    val selectedFontSize by viewModel.selectedFontSize.collectAsStateWithLifecycle()
    val isBold by viewModel.isBold.collectAsStateWithLifecycle()
    val isItalic by viewModel.isItalic.collectAsStateWithLifecycle()
    val isUnderline by viewModel.isUnderline.collectAsStateWithLifecycle()
    val selectedTextColor by viewModel.selectedTextColor.collectAsStateWithLifecycle()
    val selectedTextAlign by viewModel.selectedTextAlign.collectAsStateWithLifecycle()
    val isTypographySheetOpen by viewModel.isTypographySheetOpen.collectAsStateWithLifecycle()

    // Collaboration states
    val collaborators by viewModel.collaborators.collectAsStateWithLifecycle()
    val deviceContacts by viewModel.deviceContacts.collectAsStateWithLifecycle()
    val userPhoneNumber by viewModel.userPhoneNumber.collectAsStateWithLifecycle()
    val activeCollaboratorOnPage by viewModel.activeCollaboratorOnPage.collectAsStateWithLifecycle()
    val isPrivacyModeEnabled by viewModel.isPrivacyModeEnabled.collectAsStateWithLifecycle()
    val privacyPin by viewModel.privacyPin.collectAsStateWithLifecycle()
    val isSheetsSyncing by viewModel.isSheetsSyncing.collectAsStateWithLifecycle()
    val spreadsheetUrl by viewModel.spreadsheetUrl.collectAsStateWithLifecycle()
    val lastSheetsSyncTime by viewModel.lastSheetsSyncTime.collectAsStateWithLifecycle()
    val isUserRegistered by viewModel.isUserRegistered.collectAsStateWithLifecycle()
    val isOnboardingCompleted by viewModel.isOnboardingCompleted.collectAsStateWithLifecycle()
    val registeredUserName by viewModel.registeredUserName.collectAsStateWithLifecycle()
    val isRegistering by viewModel.isRegistering.collectAsStateWithLifecycle()
    val registrationError by viewModel.registrationError.collectAsStateWithLifecycle()

    val currentUser = collaborators.firstOrNull { it.isCurrentUser }
    val canCurrentUserWrite = currentUser?.canWrite ?: true

    val snackbarHostState = remember { SnackbarHostState() }
    val pageSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val collabSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val sheetsSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var showPageListSheet by remember { mutableStateOf(false) }
    var showCollaborationDialog by remember { mutableStateOf(false) }
    var showSheetsSyncDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var showUnlockPrivacyDialog by remember { mutableStateOf(false) }
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    // Display feedback message
    LaunchedEffect(message) {
        message?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearMessage()
        }
    }

    if (!isOnboardingCompleted) {
        AuthOnboardingScreen(
            isRegistering = isRegistering,
            registrationError = registrationError,
            isUserRegistered = isUserRegistered,
            registeredUserName = registeredUserName,
            initialWebhookUrl = viewModel.initialWebhookUrl,
            onRegister = { name, phone, webhookUrl ->
                viewModel.registerUser(name, phone, webhookUrl)
            },
            onLogin = { name, phone ->
                viewModel.loginUser(name, phone)
            },
            onComplete = {
                viewModel.completeOnboarding()
            },
            onClearError = {
                viewModel.clearRegistrationError()
            },
            modifier = modifier.fillMaxSize()
        )
    } else if (currentScreen == NotebookViewModel.AppScreen.HOME) {
        Box(modifier = modifier.fillMaxSize()) {
            HomeScreen(
                notebooks = notebooks,
                onOpenNotebook = { notebook ->
                    viewModel.selectNotebook(notebook)
                },
                onAddNewNotebook = {
                    viewModel.createNewNotebook()
                },
                onToggleFavorite = { notebookId ->
                    viewModel.toggleNotebookFavorite(notebookId)
                },
                onDeleteNotebook = { notebookId ->
                    viewModel.deleteNotebook(notebookId)
                },
                onOpenAccount = {
                    viewModel.openAuthScreen()
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    } else {
        Scaffold(
            modifier = modifier.fillMaxSize().testTag("notebook_scaffold"),
            snackbarHost = { SnackbarHost(snackbarHostState) },
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ) { innerPadding ->
        val guestCollaborators = collaborators.filter { !it.isCurrentUser }
        val isSoloMode = guestCollaborators.isNotEmpty() && guestCollaborators.none { it.canWrite }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Direct 3-Screen Preview Tabs (Screen 1: Page du cahier, Screen 2: Outils, Screen 3: Partage & Collab)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = androidx.compose.ui.graphics.Color(0xFF1E2433),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            viewModel.selectTool(com.example.data.model.ToolType.PEN)
                            showCollaborationDialog = false
                        }
                        .testTag("tab_screen_1_notebook")
                ) {
                    Text(
                        text = "1. Page Cahier",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.ui.graphics.Color.White,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(vertical = 5.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = androidx.compose.ui.graphics.Color(0xFF1E2433),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            viewModel.selectTool(com.example.data.model.ToolType.PEN)
                            showCollaborationDialog = false
                        }
                        .testTag("tab_screen_2_tools")
                ) {
                    Text(
                        text = "2. Outils",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.ui.graphics.Color.White,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(vertical = 5.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = androidx.compose.ui.graphics.Color(0xFF2563EB).copy(alpha = 0.25f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, androidx.compose.ui.graphics.Color(0xFF3B82F6)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable {
                            showCollaborationDialog = true
                        }
                        .testTag("tab_screen_3_collaboration")
                ) {
                    Text(
                        text = "3. Partage & Collab",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = androidx.compose.ui.graphics.Color(0xFF60A5FA),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.padding(vertical = 5.dp)
                    )
                }
            }

            // 1. Page Header (Title, Page switch, Collab button, Add page, Delete page)
            PageNavigationHeader(
                currentPageNumber = (currentPage?.pageNumber ?: (currentPageIndex + 1)),
                totalPages = pages.size.coerceAtLeast(1),
                pageTitle = pageTitle,
                dateModified = currentPage?.dateModified ?: System.currentTimeMillis(),
                collaboratorCount = collaborators.size,
                activeCollaborator = activeCollaboratorOnPage,
                isSoloMode = isSoloMode,
                isPrivacyMode = isPrivacyModeEnabled,
                onToggleSoloMode = {
                    viewModel.toggleAllCollaboratorsWritePermission(isSoloMode)
                },
                onTogglePrivacyMode = {
                    if (!isPrivacyModeEnabled) {
                        viewModel.togglePrivacyMode(true)
                    } else {
                        showUnlockPrivacyDialog = true
                    }
                },
                onPreviousPage = { viewModel.previousPage() },
                onNextPage = { viewModel.nextPage() },
                onAddPage = { viewModel.addNewPage() },
                onDeletePage = {
                    showDeleteConfirmDialog = true
                },
                onOpenPageList = {
                    viewModel.openPagesSheet()
                    showPageListSheet = true
                },
                onOpenCollaboration = {
                    showCollaborationDialog = true
                },
                onOpenGoogleSheetsSync = {
                    showSheetsSyncDialog = true
                },
                onNavigateHome = {
                    viewModel.navigateToHome()
                },
                onTitleChange = { viewModel.updateTitle(it) }
            )

            // 2. Main Lined Paper Canvas (Feuille de Cahier avec A, B dans la marge & lignes ordonnées)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            ) {
                NotebookPaper(
                    strokes = strokes,
                    lineEntries = lineEntries,
                    selectedTool = selectedTool,
                    selectedColor = selectedColor,
                    strokeWidth = strokeWidth,
                    lineStyle = lineStyle,
                    paperTone = paperTone,
                    textContent = textContent,
                    collaborators = collaborators,
                    canCurrentUserWrite = canCurrentUserWrite,
                    isPrivacyMode = isPrivacyModeEnabled,
                    isStrokeSmoothingEnabled = isStrokeSmoothingEnabled,
                    penStyle = penStyle,
                    onTogglePrivacyMode = {
                        if (!isPrivacyModeEnabled) {
                            viewModel.togglePrivacyMode(true)
                        } else {
                            showUnlockPrivacyDialog = true
                        }
                    },
                    onTextChange = { viewModel.updateTextContent(it) },
                    onStrokeDrawn = { stroke -> viewModel.addStroke(stroke) },
                    onEraseAtPoint = { point -> viewModel.eraseStrokesNear(point) },
                    onAddLineEntry = { text, authorId ->
                        viewModel.addLineEntry(text, authorId)
                    },
                    onToggleChecklist = { entry ->
                        viewModel.toggleChecklistLine(entry)
                    },
                    onDeleteLineEntry = { entry ->
                        viewModel.deleteLineEntry(entry)
                    },
                    selectedFontId = selectedFontId,
                    selectedFontSize = selectedFontSize,
                    isBold = isBold,
                    isItalic = isItalic,
                    isUnderline = isUnderline,
                    selectedTextColor = selectedTextColor,
                    selectedTextAlign = selectedTextAlign,
                    onOpenTypography = { viewModel.openTypographySheet() }
                )
            }

            // 3. Notebook Toolbar (Plume, Surligneur, Gomme, Texte, Couleur, Plus)
            NotebookToolbar(
                selectedTool = selectedTool,
                selectedColor = selectedColor,
                strokeWidth = strokeWidth,
                canUndo = canUndo,
                canRedo = canRedo,
                lineStyle = lineStyle,
                selectedFontId = selectedFontId,
                fontSize = selectedFontSize,
                isBold = isBold,
                isItalic = isItalic,
                isUnderline = isUnderline,
                selectedTextColor = selectedTextColor,
                selectedTextAlign = selectedTextAlign,
                isStrokeSmoothingEnabled = isStrokeSmoothingEnabled,
                penStyle = penStyle,
                onStrokeSmoothingToggled = { viewModel.setStrokeSmoothing(it) },
                onPenStyleSelected = { viewModel.setPenStyle(it) },
                isPenSettingsOpen = isPenSettingsOpen,
                onTogglePenSettings = { viewModel.togglePenSettings() },
                onClosePenSettings = { viewModel.closePenSettings() },
                onOpenTypographySheet = { viewModel.openTypographySheet() },
                onFontSizeChanged = { viewModel.setFontSize(it) },
                onToggleBold = { viewModel.toggleBold() },
                onToggleItalic = { viewModel.toggleItalic() },
                onToggleUnderline = { viewModel.toggleUnderline() },
                onTextColorSelected = { viewModel.setTextColor(it) },
                onTextAlignSelected = { viewModel.setTextAlign(it) },
                onToolSelected = { tool -> viewModel.selectTool(tool) },
                onColorSelected = { color -> viewModel.selectColor(color) },
                onStrokeWidthSelected = { width -> viewModel.setStrokeWidth(width) },
                onLineStyleSelected = { style -> viewModel.setLineStyle(style) },
                onUndo = { viewModel.undo() },
                onRedo = { viewModel.redo() },
                onClearPage = { showClearConfirmDialog = true },
                onAddImage = { viewModel.addImageAction() },
                onAddChecklist = { viewModel.addChecklistAction() },
                onAddShape = { viewModel.addShapeAction() },
                onAddVoiceNote = { viewModel.addVoiceNoteAction() },
                onAddAttachment = { viewModel.addAttachmentAction() },
                onAddNewPage = { viewModel.addNewPage() }
            )
        }

        // Delete Page Confirmation Dialog
        if (showDeleteConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirmDialog = false },
                title = { Text("Supprimer cette page ?") },
                text = {
                    Text("Êtes-vous sûr de vouloir supprimer définitivement la page ${currentPage?.pageNumber ?: (currentPageIndex + 1)} ? Toutes les notes et dessins seront effacés.")
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showDeleteConfirmDialog = false
                            viewModel.deleteCurrentPage()
                        },
                        modifier = Modifier.testTag("dialog_confirm_delete")
                    ) {
                        Text("Oui, Supprimer", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showDeleteConfirmDialog = false },
                        modifier = Modifier.testTag("dialog_cancel_delete")
                    ) {
                        Text("Annuler")
                    }
                }
            )
        }

        // Clear Page Confirmation Dialog
        if (showClearConfirmDialog) {
            AlertDialog(
                onDismissRequest = { showClearConfirmDialog = false },
                title = { Text("Nettoyer la page ?") },
                text = {
                    Text("Voulez-vous effacer tout ce qui se trouve sur cette page ?")
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            showClearConfirmDialog = false
                            viewModel.clearCurrentPage()
                        },
                        modifier = Modifier.testTag("dialog_confirm_clear")
                    ) {
                        Text("Oui, Nettoyer", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { showClearConfirmDialog = false }
                    ) {
                        Text("Annuler")
                    }
                }
            )
        }

        // Pages Bottom Sheet ("Toutes les pages" with thumbnail previews and page management)
        if (showPageListSheet || isPagesSheetOpen) {
            PagesBottomSheet(
                pages = pages,
                currentPageIndex = currentPageIndex,
                sheetState = pageSheetState,
                onDismiss = {
                    showPageListSheet = false
                    viewModel.closePagesSheet()
                },
                onSelectPage = { index ->
                    viewModel.selectPage(index)
                    showPageListSheet = false
                    viewModel.closePagesSheet()
                },
                onAddNewPage = {
                    viewModel.addNewPage()
                },
                onRenamePage = { targetPage, newTitle ->
                    viewModel.renamePage(targetPage, newTitle)
                },
                onDuplicatePage = { targetPage ->
                    viewModel.duplicatePage(targetPage)
                },
                onDeletePage = { targetPage ->
                    viewModel.deletePage(targetPage)
                }
            )
        }

        // Collaboration & Contact Selection Dialog with Write Authorizations
        if (showCollaborationDialog) {
            CollaborationDialog(
                collaborators = collaborators,
                deviceContacts = deviceContacts,
                userPhoneNumber = userPhoneNumber,
                totalPages = pages.size,
                sheetState = collabSheetState,
                onDismiss = { showCollaborationDialog = false },
                onUpdateUserPhone = { newPhone ->
                    viewModel.setUserPhoneNumber(newPhone)
                },
                onInviteCollaborator = { name, phone, pagesList, canWrite ->
                    viewModel.inviteCollaborator(name, phone, pagesList, canWrite)
                },
                onToggleWriteAuthorization = { collab, canWrite ->
                    viewModel.toggleWriteAuthorization(collab, canWrite)
                },
                onToggleAllCollaboratorsWrite = { allowGuests ->
                    viewModel.toggleAllCollaboratorsWritePermission(allowGuests)
                },
                onRemoveCollaborator = { collab ->
                    viewModel.removeCollaborator(collab)
                },
                onUpdateCollaboratorPages = { collab, newPagesList ->
                    viewModel.updateCollaboratorPages(collab, newPagesList)
                },
                onRefreshContacts = {
                    viewModel.loadDeviceContacts()
                }
            )
        }

        // Privacy Unlock PIN Dialog
        if (showUnlockPrivacyDialog) {
            AlertDialog(
                onDismissRequest = {
                    showUnlockPrivacyDialog = false
                    enteredPin = ""
                    pinError = false
                },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                },
                title = {
                    Text("Mode Confidentiel", fontWeight = FontWeight.Bold)
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Les messages des collaborateurs sont masqués pour protéger votre vie privée. Entrez votre code PIN pour les réafficher.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = enteredPin,
                            onValueChange = {
                                enteredPin = it.take(6)
                                pinError = false
                            },
                            label = { Text("Code PIN (défaut: 1234)") },
                            singleLine = true,
                            isError = pinError,
                            supportingText = {
                                if (pinError) {
                                    Text("Code PIN incorrect", color = MaterialTheme.colorScheme.error)
                                } else {
                                    Text("Entrez le code secret à 4 chiffres")
                                }
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_privacy_pin")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val success = viewModel.togglePrivacyMode(false, enteredPin)
                            if (success) {
                                showUnlockPrivacyDialog = false
                                enteredPin = ""
                                pinError = false
                            } else {
                                pinError = true
                            }
                        },
                        modifier = Modifier.testTag("button_confirm_unlock_privacy")
                    ) {
                        Text("Déverrouiller")
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = {
                            showUnlockPrivacyDialog = false
                            enteredPin = ""
                            pinError = false
                        }
                    ) {
                        Text("Annuler")
                    }
                }
            )
        }

        // Google Sheets Real-Time Cloud Sync BottomSheet
        if (showSheetsSyncDialog) {
            GoogleSheetsSyncDialog(
                sheetUrl = spreadsheetUrl,
                isSyncing = isSheetsSyncing,
                lastSyncTime = lastSheetsSyncTime,
                collaboratorCount = collaborators.size,
                onSyncNow = { token ->
                    viewModel.syncCurrentNotebookToGoogleSheets(token)
                },
                onPullFromSheet = { token ->
                    viewModel.pullLinesFromGoogleSheets(token)
                },
                onSaveToken = { token ->
                    viewModel.saveSheetsAccessToken(token)
                },
                onDismiss = {
                    showSheetsSyncDialog = false
                },
                sheetState = sheetsSheetState
            )
        }

        // Dialogue d'inscription obligatoire avec enregistrement dans Google Sheets
        if (!isUserRegistered) {
            UserRegistrationDialog(
                isRegistering = isRegistering,
                registrationError = registrationError,
                initialWebhookUrl = viewModel.initialWebhookUrl,
                onRegister = { name, phone, webhookUrl ->
                    viewModel.registerUser(name, phone, webhookUrl)
                },
                onClearError = {
                    viewModel.clearRegistrationError()
                }
            )
        }

        // Typographie BottomSheet (Écriture manuscrite & Classique)
        if (isTypographySheetOpen) {
            TypographyBottomSheet(
                selectedFontId = selectedFontId,
                onFontSelected = { fontId ->
                    viewModel.setFont(fontId)
                    viewModel.closeTypographySheet()
                },
                onDismiss = {
                    viewModel.closeTypographySheet()
                }
            )
        }
    }
}
}
