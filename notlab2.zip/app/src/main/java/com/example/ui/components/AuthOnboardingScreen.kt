package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.Handwriting1FontFamily
import com.example.ui.theme.Handwriting3FontFamily

enum class AuthStep {
    LANDING,
    FORM_REGISTER,
    FORM_LOGIN,
    SUCCESS
}

enum class SupportedLanguage(val displayName: String, val flag: String) {
    FRANCAIS("Français", "🇫🇷"),
    KREYOL("Kreyòl Ayisyen", "🇭🇹"),
    ENGLISH("English", "🇺🇸")
}

/**
 * Modern Onboarding & Authentication Flow for Notlab.
 * Screen 1: Landing with illustrated paper note & language selector
 * Screen 2: Account creation / Login form with Haiti phone +509
 * Screen 3: Welcome success screen with glowing book badge and handwriting note
 */
@Composable
fun AuthOnboardingScreen(
    isRegistering: Boolean,
    registrationError: String?,
    isUserRegistered: Boolean,
    registeredUserName: String,
    initialWebhookUrl: String?,
    onRegister: (name: String, phone: String, webhookUrl: String?) -> Unit,
    onLogin: (name: String, phone: String) -> Unit,
    onComplete: () -> Unit,
    onClearError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentStep by remember {
        mutableStateOf(if (isUserRegistered) AuthStep.SUCCESS else AuthStep.LANDING)
    }
    var currentLanguage by remember { mutableStateOf(SupportedLanguage.FRANCAIS) }

    // When registration succeeds while on the form, transition to SUCCESS screen
    LaunchedEffect(isUserRegistered) {
        if (isUserRegistered && (currentStep == AuthStep.FORM_REGISTER || currentStep == AuthStep.FORM_LOGIN)) {
            currentStep = AuthStep.SUCCESS
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B0F19))
            .testTag("auth_onboarding_screen")
    ) {
        AnimatedContent(
            targetState = currentStep,
            transitionSpec = {
                if (targetState.ordinal > initialState.ordinal) {
                    (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> -width } + fadeOut()
                    )
                } else {
                    (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                        slideOutHorizontally { width -> width } + fadeOut()
                    )
                }
            },
            label = "auth_step_transition"
        ) { step ->
            when (step) {
                AuthStep.LANDING -> {
                    LandingScreenContent(
                        currentLanguage = currentLanguage,
                        onLanguageChange = { currentLanguage = it },
                        onCreateAccountClick = {
                            onClearError()
                            currentStep = AuthStep.FORM_REGISTER
                        },
                        onLoginClick = {
                            onClearError()
                            currentStep = AuthStep.FORM_LOGIN
                        }
                    )
                }

                AuthStep.FORM_REGISTER -> {
                    AuthFormScreenContent(
                        isRegisterMode = true,
                        currentLanguage = currentLanguage,
                        isRegistering = isRegistering,
                        registrationError = registrationError,
                        initialWebhookUrl = initialWebhookUrl,
                        onBack = {
                            onClearError()
                            currentStep = AuthStep.LANDING
                        },
                        onSubmit = { name, phone, webhook ->
                            onRegister(name, phone, webhook)
                        },
                        onToggleMode = {
                            onClearError()
                            currentStep = AuthStep.FORM_LOGIN
                        },
                        onClearError = onClearError
                    )
                }

                AuthStep.FORM_LOGIN -> {
                    AuthFormScreenContent(
                        isRegisterMode = false,
                        currentLanguage = currentLanguage,
                        isRegistering = isRegistering,
                        registrationError = registrationError,
                        initialWebhookUrl = initialWebhookUrl,
                        onBack = {
                            onClearError()
                            currentStep = AuthStep.LANDING
                        },
                        onSubmit = { name, phone, _ ->
                            onLogin(name, phone)
                        },
                        onToggleMode = {
                            onClearError()
                            currentStep = AuthStep.FORM_REGISTER
                        },
                        onClearError = onClearError
                    )
                }

                AuthStep.SUCCESS -> {
                    WelcomeSuccessScreenContent(
                        userName = registeredUserName,
                        currentLanguage = currentLanguage,
                        onStart = onComplete
                    )
                }
            }
        }
    }
}

// -----------------------------------------------------------------------------
// SCREEN 1: LANDING & ONBOARDING
// -----------------------------------------------------------------------------
@Composable
private fun LandingScreenContent(
    currentLanguage: SupportedLanguage,
    onLanguageChange: (SupportedLanguage) -> Unit,
    onCreateAccountClick: () -> Unit,
    onLoginClick: () -> Unit
) {
    var languageMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Bar: Language Dropdown
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0xFF161F33))
                        .clickable { languageMenuExpanded = true }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("button_auth_language"),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = currentLanguage.displayName,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFE2E8F0)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Public,
                        contentDescription = "Langue",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(16.dp)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(18.dp)
                    )
                }

                DropdownMenu(
                    expanded = languageMenuExpanded,
                    onDismissRequest = { languageMenuExpanded = false },
                    modifier = Modifier.background(Color(0xFF1E293B))
                ) {
                    SupportedLanguage.values().forEach { lang ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "${lang.flag}  ${lang.displayName}",
                                    color = if (lang == currentLanguage) Color(0xFF60A5FA) else Color.White,
                                    fontWeight = if (lang == currentLanguage) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            onClick = {
                                onLanguageChange(lang)
                                languageMenuExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Center Block: Logo + Brand + Tagline + Realistic Note Card
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Notlab Book App Icon with subtle cyan/blue glow
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .shadow(20.dp, RoundedCornerShape(22.dp), ambientColor = Color(0xFF0066FF), spotColor = Color(0xFF38BDF8))
                    .clip(RoundedCornerShape(22.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF1E3A8A), Color(0xFF0284C7))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.MenuBook,
                    contentDescription = "Logo Notlab",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title "Notlab"
            Text(
                text = "Notlab",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Tagline
            val tagline = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Ekri. Pataje. Ale pi lwen."
                SupportedLanguage.ENGLISH -> "Write. Share. Go further."
                else -> "Écrire. Partager. Aller plus loin."
            }
            Text(
                text = tagline,
                fontSize = 14.sp,
                color = Color(0xFF94A3B8),
                letterSpacing = 0.2.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Realistic Notebook Card with Spiral Rings and Handwriting Note
            IllustratedNotebookCard(
                text = when (currentLanguage) {
                    SupportedLanguage.KREYOL -> "Pi bon lide yo\nkòmanse\nla. ♡"
                    SupportedLanguage.ENGLISH -> "Better ideas\nstart\nhere. ♡"
                    else -> "De meilleures\nidées\ncommencent\nici. ♡"
                }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Bottom Actions: Create Account & Login Buttons + Carousel Dots
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Primary Blue Button: "Créer un compte"
            val createAccountText = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Kreye yon kont"
                SupportedLanguage.ENGLISH -> "Create an account"
                else -> "Créer un compte"
            }
            Button(
                onClick = onCreateAccountClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(8.dp, RoundedCornerShape(27.dp), ambientColor = Color(0xFF0066FF))
                    .testTag("button_auth_create_account"),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066FF),
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = createAccountText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Secondary Outlined/Dark Button: "Se connecter"
            val loginText = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Konekte"
                SupportedLanguage.ENGLISH -> "Log in"
                else -> "Se connecter"
            }
            Button(
                onClick = onLoginClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .border(1.dp, Color(0xFF26334D), RoundedCornerShape(27.dp))
                    .testTag("button_auth_login"),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0E1424),
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = loginText,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 3-dot Carousel Indicator
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 20.dp, height = 6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(Color(0xFF0066FF))
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2E3A52))
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF2E3A52))
                )
            }
        }
    }
}

/**
 * Center illustrated paper card with subtle perspective, realistic spiral rings,
 * light ruled lines, and natural handwriting blue ink.
 */
@Composable
private fun IllustratedNotebookCard(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth(0.88f)
            .height(220.dp)
            .shadow(16.dp, RoundedCornerShape(16.dp), ambientColor = Color.Black)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFFF9F7F2)) // Soft warm notebook paper
    ) {
        // Draw spiral notebook details & ruled lines
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val lineSpacing = 26.dp.toPx()
            val startY = 36.dp.toPx()

            // Left spiral margin line (subtle red/pink or blue margin)
            drawLine(
                color = Color(0x33DC2626),
                start = Offset(44.dp.toPx(), 0f),
                end = Offset(44.dp.toPx(), h),
                strokeWidth = 1.5.dp.toPx()
            )

            // Ruled notebook lines
            var y = startY
            while (y < h - 16.dp.toPx()) {
                drawLine(
                    color = Color(0x221E293B),
                    start = Offset(46.dp.toPx(), y),
                    end = Offset(w - 16.dp.toPx(), y),
                    strokeWidth = 1.dp.toPx()
                )
                y += lineSpacing
            }

            // Left spiral holes and rings
            val spiralCount = 7
            val spiralStep = h / (spiralCount + 1)
            for (i in 1..spiralCount) {
                val cy = i * spiralStep
                // Spiral hole
                drawCircle(
                    color = Color(0xFFDCD6CA),
                    radius = 4.5.dp.toPx(),
                    center = Offset(16.dp.toPx(), cy)
                )
                drawCircle(
                    color = Color(0xFF475569),
                    radius = 4.5.dp.toPx(),
                    center = Offset(16.dp.toPx(), cy),
                    style = Stroke(width = 1.dp.toPx())
                )
                // Spiral metal ring arc
                drawArc(
                    color = Color(0xFF64748B),
                    startAngle = 120f,
                    sweepAngle = 220f,
                    useCenter = false,
                    topLeft = Offset(4.dp.toPx(), cy - 7.dp.toPx()),
                    size = Size(18.dp.toPx(), 14.dp.toPx()),
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }

        // Handwritten note text in blue fountain-pen ink
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 54.dp, end = 20.dp, top = 28.dp, bottom = 16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Column(
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = text,
                    fontFamily = Handwriting1FontFamily,
                    fontSize = 24.sp,
                    lineHeight = 32.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E3A8A), // Royal blue fountain ink
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}

// -----------------------------------------------------------------------------
// SCREEN 2: AUTH FORM ("Créer un compte" / "Se connecter")
// -----------------------------------------------------------------------------
@Composable
private fun AuthFormScreenContent(
    isRegisterMode: Boolean,
    currentLanguage: SupportedLanguage,
    isRegistering: Boolean,
    registrationError: String?,
    initialWebhookUrl: String?,
    onBack: () -> Unit,
    onSubmit: (name: String, phone: String, webhook: String?) -> Unit,
    onToggleMode: () -> Unit,
    onClearError: () -> Unit
) {
    var userName by remember { mutableStateOf("") }
    var userPhone by remember { mutableStateOf("") }
    var localError by remember { mutableStateOf<String?>(null) }
    val focusManager = LocalFocusManager.current

    val activeError = localError ?: registrationError

    val title = when {
        !isRegisterMode -> when (currentLanguage) {
            SupportedLanguage.KREYOL -> "Konekte"
            SupportedLanguage.ENGLISH -> "Sign In"
            else -> "Se connecter"
        }
        else -> when (currentLanguage) {
            SupportedLanguage.KREYOL -> "Kreye yon kont"
            SupportedLanguage.ENGLISH -> "Create an account"
            else -> "Créer un compte"
        }
    }

    val subtitle = when {
        !isRegisterMode -> when (currentLanguage) {
            SupportedLanguage.KREYOL -> "Konekte sou Notlab pou jwenn tout nòt ou yo."
            SupportedLanguage.ENGLISH -> "Log in to Notlab to find all your notes."
            else -> "Connectez-vous à Notlab pour retrouver vos notes."
        }
        else -> when (currentLanguage) {
            SupportedLanguage.KREYOL -> "Antre nan Notlab epi kòmanse ekri lide ou tout kote."
            SupportedLanguage.ENGLISH -> "Join Notlab and start writing your ideas everywhere."
            else -> "Rejoignez Notlab et commencez à écrire vos idées partout."
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp)
            .padding(top = 16.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Top Bar: Back Arrow button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("button_auth_back")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Retour",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Title
            Text(
                text = title,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 0.3.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtitle
            Text(
                text = subtitle,
                fontSize = 14.sp,
                color = Color(0xFF94A3B8),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Active Error Alert Banner
            if (activeError != null) {
                Surface(
                    color = Color(0xFF3B151E),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 18.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFFF87171),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = activeError,
                            color = Color(0xFFFCA5A5),
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Input 1: Nom d'utilisateur
            val usernameLabel = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Non itilizatè"
                SupportedLanguage.ENGLISH -> "Username"
                else -> "Nom d'utilisateur"
            }
            Text(
                text = usernameLabel,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Custom Styled Input Field
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF131B2E))
                    .border(1.dp, Color(0xFF2E3A52), RoundedCornerShape(14.dp))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        if (userName.isEmpty()) {
                            Text(
                                text = "John",
                                color = Color(0xFF64748B),
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = userName,
                            onValueChange = {
                                userName = it
                                localError = null
                                onClearError()
                            },
                            textStyle = TextStyle(
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            singleLine = true,
                            cursorBrush = SolidColor(Color(0xFF0066FF)),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Text,
                                imeAction = ImeAction.Next
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_auth_username")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Caption under username
            val usernameHelper = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Lòt itilizatè yo ap wè non sa a."
                SupportedLanguage.ENGLISH -> "This name will be visible to other users."
                else -> "Ce nom sera visible pour les autres utilisateurs."
            }
            Text(
                text = usernameHelper,
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(22.dp))

            // Input 2: Numéro de téléphone (With Haiti flag 🇭🇹 and +509 prefix)
            val phoneLabel = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Nimewo telefòn"
                SupportedLanguage.ENGLISH -> "Phone number"
                else -> "Numéro de téléphone"
            }
            Text(
                text = phoneLabel,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFFE2E8F0)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Phone Input Field Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF131B2E))
                    .border(1.dp, Color(0xFF2E3A52), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Phone,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(19.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))

                    // Haiti Flag Badge
                    HaitiFlagBadge()

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "+509",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFE2E8F0)
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Vertical divider
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(24.dp)
                            .background(Color(0xFF2E3A52))
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Phone input
                    Box(modifier = Modifier.weight(1f)) {
                        if (userPhone.isEmpty()) {
                            Text(
                                text = "1234 5678",
                                color = Color(0xFF64748B),
                                fontSize = 15.sp
                            )
                        }
                        BasicTextField(
                            value = userPhone,
                            onValueChange = { input ->
                                val digitsOnly = input.filter { it.isDigit() }.take(8)
                                userPhone = digitsOnly
                                localError = null
                                onClearError()
                            },
                            textStyle = TextStyle(
                                color = Color.White,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Normal
                            ),
                            singleLine = true,
                            cursorBrush = SolidColor(Color(0xFF0066FF)),
                            keyboardOptions = KeyboardOptions(
                                keyboardType = KeyboardType.Phone,
                                imeAction = ImeAction.Done
                            ),
                            keyboardActions = KeyboardActions(
                                onDone = { focusManager.clearFocus() }
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_auth_phone")
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Caption under phone
            val phoneHelper = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Antre yon nimewo 8 chif."
                SupportedLanguage.ENGLISH -> "Enter an 8-digit phone number."
                else -> "Entrez un numéro de 8 chiffres."
            }
            Text(
                text = phoneHelper,
                fontSize = 12.sp,
                color = Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Action Button: "Créer mon compte" or "Se connecter"
            val buttonText = when {
                !isRegisterMode -> when (currentLanguage) {
                    SupportedLanguage.KREYOL -> "Konekte"
                    SupportedLanguage.ENGLISH -> "Log In"
                    else -> "Se connecter"
                }
                else -> when (currentLanguage) {
                    SupportedLanguage.KREYOL -> "Kreye kont mwen"
                    SupportedLanguage.ENGLISH -> "Create my account"
                    else -> "Créer mon compte"
                }
            }

            Button(
                onClick = {
                    if (userName.isBlank()) {
                        localError = when (currentLanguage) {
                            SupportedLanguage.KREYOL -> "Tanpri antre yon non itilizatè valab."
                            SupportedLanguage.ENGLISH -> "Please enter a valid username."
                            else -> "Veuillez entrer un nom d'utilisateur valide."
                        }
                        return@Button
                    }
                    if (userPhone.length < 8) {
                        localError = when (currentLanguage) {
                            SupportedLanguage.KREYOL -> "Tanpri antre yon nimewo telefòn 8 chif."
                            SupportedLanguage.ENGLISH -> "Please enter an 8-digit phone number."
                            else -> "Veuillez entrer un numéro de téléphone à 8 chiffres."
                        }
                        return@Button
                    }
                    val fullPhone = if (userPhone.startsWith("+509")) userPhone else "+509 $userPhone"
                    onSubmit(userName.trim(), fullPhone, initialWebhookUrl)
                },
                enabled = !isRegistering,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(8.dp, RoundedCornerShape(27.dp), ambientColor = Color(0xFF0066FF))
                    .testTag("button_auth_submit"),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066FF),
                    contentColor = Color.White,
                    disabledContainerColor = Color(0xFF1E3A8A)
                )
            ) {
                if (isRegistering) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Text(
                        text = buttonText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Toggle Mode link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val switchText = when {
                    isRegisterMode -> when (currentLanguage) {
                        SupportedLanguage.KREYOL -> "Ou gen yon kont deja ? Konekte"
                        SupportedLanguage.ENGLISH -> "Already have an account? Log in"
                        else -> "Déjà un compte ? Se connecter"
                    }
                    else -> when (currentLanguage) {
                        SupportedLanguage.KREYOL -> "Ou pa gen kont ? Kreye yon kont"
                        SupportedLanguage.ENGLISH -> "Don't have an account? Sign up"
                        else -> "Pas encore de compte ? Créer un compte"
                    }
                }
                Text(
                    text = switchText,
                    fontSize = 13.5.sp,
                    color = Color(0xFF60A5FA),
                    modifier = Modifier
                        .clickable { onToggleMode() }
                        .padding(4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Security & Terms Footer with Lock icon
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = Color(0xFF64748B),
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            val termsPrefix = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Lè ou kreye yon kont, ou aksepte "
                SupportedLanguage.ENGLISH -> "By creating an account, you agree to our "
                else -> "En créant un compte, vous acceptez nos\n"
            }
            val termsCondition = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Kondisyon Itilizasyon"
                SupportedLanguage.ENGLISH -> "Terms of Service"
                else -> "Conditions d'utilisation"
            }
            val termsAnd = when (currentLanguage) {
                SupportedLanguage.KREYOL -> " ak "
                SupportedLanguage.ENGLISH -> " and "
                else -> " et notre "
            }
            val termsPrivacy = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Politik Konfidansyalite nou."
                SupportedLanguage.ENGLISH -> "Privacy Policy."
                else -> "Politique de confidentialité."
            }

            Text(
                text = "$termsPrefix$termsCondition$termsAnd$termsPrivacy",
                fontSize = 12.sp,
                color = Color(0xFF64748B),
                textAlign = TextAlign.Center,
                lineHeight = 17.sp
            )
        }
    }
}

/**
 * Compact high-fidelity Haiti Flag Badge 🇭🇹
 */
@Composable
private fun HaitiFlagBadge() {
    Box(
        modifier = Modifier
            .size(width = 24.dp, height = 16.dp)
            .clip(RoundedCornerShape(3.dp))
            .border(0.5.dp, Color(0xFF334155), RoundedCornerShape(3.dp))
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Top Blue Half
            drawRect(
                color = Color(0xFF00209F),
                topLeft = Offset(0f, 0f),
                size = Size(w, h / 2f)
            )

            // Bottom Red Half
            drawRect(
                color = Color(0xFFD21034),
                topLeft = Offset(0f, h / 2f),
                size = Size(w, h / 2f)
            )

            // Center Coat of Arms white square
            val squareW = 7.dp.toPx()
            val squareH = 6.dp.toPx()
            drawRoundRect(
                color = Color.White,
                topLeft = Offset((w - squareW) / 2f, (h - squareH) / 2f),
                size = Size(squareW, squareH),
                cornerRadius = CornerRadius(1.dp.toPx(), 1.dp.toPx())
            )

            // Tiny palm tree green center dot
            drawCircle(
                color = Color(0xFF0F9D58),
                radius = 1.2.dp.toPx(),
                center = Offset(w / 2f, h / 2f)
            )
        }
    }
}

// -----------------------------------------------------------------------------
// SCREEN 3: WELCOME SUCCESS ("Bienvenue sur Notlab !")
// -----------------------------------------------------------------------------
@Composable
private fun WelcomeSuccessScreenContent(
    userName: String,
    currentLanguage: SupportedLanguage,
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp)
            .padding(top = 40.dp, bottom = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Center: Glowing Notlab Book Icon with Radiating Sparks & Success Check Badge
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(170.dp)
            ) {
                // Radiating spark lines / burst
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = Offset(size.width / 2f, size.height / 2f)
                    val sparkColor = Color(0xFF38BDF8)
                    val strokeW = 3.dp.toPx()

                    // Top spark
                    drawLine(sparkColor, Offset(c.x, 6.dp.toPx()), Offset(c.x, 18.dp.toPx()), strokeW, StrokeCap.Round)
                    // Top-Left spark
                    drawLine(sparkColor, Offset(c.x - 46.dp.toPx(), 22.dp.toPx()), Offset(c.x - 36.dp.toPx(), 32.dp.toPx()), strokeW, StrokeCap.Round)
                    // Top-Right spark
                    drawLine(sparkColor, Offset(c.x + 46.dp.toPx(), 22.dp.toPx()), Offset(c.x + 36.dp.toPx(), 32.dp.toPx()), strokeW, StrokeCap.Round)
                    // Left spark
                    drawLine(sparkColor, Offset(10.dp.toPx(), c.y), Offset(22.dp.toPx(), c.y), strokeW, StrokeCap.Round)
                    // Right spark
                    drawLine(sparkColor, Offset(size.width - 10.dp.toPx(), c.y), Offset(size.width - 22.dp.toPx(), c.y), strokeW, StrokeCap.Round)
                }

                // Notlab book logo box
                Box(
                    modifier = Modifier
                        .size(88.dp)
                        .shadow(24.dp, RoundedCornerShape(26.dp), ambientColor = Color(0xFF0066FF), spotColor = Color(0xFF38BDF8))
                        .clip(RoundedCornerShape(26.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFF1E3A8A), Color(0xFF0284C7))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(48.dp)
                    )
                }

                // Blue Checkmark Badge at bottom-right
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 28.dp, bottom = 28.dp)
                        .size(34.dp)
                        .shadow(8.dp, CircleShape, ambientColor = Color(0xFF0066FF))
                        .clip(CircleShape)
                        .background(Color(0xFF0066FF))
                        .border(3.dp, Color(0xFF0B0F19), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Succès",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Welcome Title
            val welcomeTitle = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Byenvini sou Notlab !"
                SupportedLanguage.ENGLISH -> "Welcome to Notlab!"
                else -> "Bienvenue sur Notlab !"
            }
            Text(
                text = welcomeTitle,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Welcome Subtitle
            val welcomeSubtitle = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Kont ou pare.\nKòmanse ekri lide ou yo depi kounye a."
                SupportedLanguage.ENGLISH -> "Your account is ready.\nStart writing your ideas right now."
                else -> "Votre compte est prêt.\nCommencez à écrire vos idées dès maintenant."
            }
            Text(
                text = welcomeSubtitle,
                fontSize = 15.sp,
                color = Color(0xFF94A3B8),
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(36.dp))

            // "Commencer" Primary Button
            val startButtonText = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Kòmanse"
                SupportedLanguage.ENGLISH -> "Get Started"
                else -> "Commencer"
            }
            Button(
                onClick = onStart,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .shadow(10.dp, RoundedCornerShape(27.dp), ambientColor = Color(0xFF0066FF))
                    .testTag("button_auth_start"),
                shape = RoundedCornerShape(27.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF0066FF),
                    contentColor = Color.White
                )
            ) {
                Text(
                    text = startButtonText,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Bottom Decorative Element: Cursive Handwritten note with double brush underline
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            val cursivePhrase = when (currentLanguage) {
                SupportedLanguage.KREYOL -> "Gwo lide ap tann ou ! ♡"
                SupportedLanguage.ENGLISH -> "Great ideas await you! ♡"
                else -> "De grandes\nidées vous attendent ! ♡"
            }

            Text(
                text = cursivePhrase,
                fontFamily = Handwriting3FontFamily,
                fontSize = 22.sp,
                color = Color(0xFFE2E8F0),
                textAlign = TextAlign.Center,
                lineHeight = 28.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Double dynamic brush curve stroke in cyan/blue
            Canvas(
                modifier = Modifier
                    .width(140.dp)
                    .height(12.dp)
            ) {
                val path1 = Path().apply {
                    moveTo(10.dp.toPx(), 4.dp.toPx())
                    quadraticTo(70.dp.toPx(), 11.dp.toPx(), 130.dp.toPx(), 3.dp.toPx())
                }
                drawPath(
                    path = path1,
                    color = Color(0xFF38BDF8),
                    style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                )

                val path2 = Path().apply {
                    moveTo(24.dp.toPx(), 9.dp.toPx())
                    quadraticTo(75.dp.toPx(), 14.dp.toPx(), 115.dp.toPx(), 8.dp.toPx())
                }
                drawPath(
                    path = path2,
                    color = Color(0xFF0284C7),
                    style = Stroke(width = 1.8.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
    }
}
