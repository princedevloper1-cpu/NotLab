package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuthorProfile
import com.example.data.model.CollaboratorPresets

/**
 * Visual styling definition for each of the 7 members (A, B, C, D, E, F, G).
 * Each user has:
 * - A unique shape badge in the margin
 * - A distinct cursive/display font nuance (weight, style, letter spacing)
 * - Distinct ink color and tint
 */
data class TagVisualSpec(
    val shape: Shape,
    val primaryColor: Color,
    val containerColor: Color,
    val borderColor: Color,
    val textColor: Color,
    val fontStyle: FontStyle = FontStyle.Normal,
    val fontWeight: FontWeight = FontWeight.Bold,
    val fontScale: Float = 1f
)

object AuthorTagVisuals {

    fun getVisualSpec(tag: String, isMasked: Boolean = false): TagVisualSpec {
        if (isMasked) {
            return TagVisualSpec(
                shape = CircleShape,
                primaryColor = Color.Gray,
                containerColor = Color.Gray.copy(alpha = 0.15f),
                borderColor = Color.Gray.copy(alpha = 0.35f),
                textColor = Color.Gray,
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.Normal
            )
        }

        return when (tag.uppercase().trim()) {
            "A" -> TagVisualSpec(
                // A: Propriétaire - Classic Royal Navy Blue, Perfect Circle, Prestigious
                shape = CircleShape,
                primaryColor = Color(0xFF1E3A8A),
                containerColor = Color(0xFFDBEAFE),
                borderColor = Color(0xFF1E3A8A),
                textColor = Color(0xFF1E3A8A),
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.Black
            )
            "B" -> TagVisualSpec(
                // B: Collaborateur - Emerald Green, Rounded Pill/Squircle, Fresh & Confident
                shape = RoundedCornerShape(7.dp),
                primaryColor = Color(0xFF047857),
                containerColor = Color(0xFFD1FAE5),
                borderColor = Color(0xFF047857),
                textColor = Color(0xFF047857),
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Bold
            )
            "C" -> TagVisualSpec(
                // C: Collaborateur - Royal Purple / Violet, Cut-Corner Hexagon/Ticket, Creative
                shape = CutCornerShape(6.dp),
                primaryColor = Color(0xFF7C3AED),
                containerColor = Color(0xFFEDE9FE),
                borderColor = Color(0xFF7C3AED),
                textColor = Color(0xFF7C3AED),
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.ExtraBold
            )
            "D" -> TagVisualSpec(
                // D: Collaborateur - Amber / Ochre Gold, Smooth Rounded Diamond/Capsule
                shape = RoundedCornerShape(topStart = 10.dp, bottomEnd = 10.dp, topEnd = 3.dp, bottomStart = 3.dp),
                primaryColor = Color(0xFFB45309),
                containerColor = Color(0xFFFEF3C7),
                borderColor = Color(0xFFB45309),
                textColor = Color(0xFFB45309),
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Black
            )
            "E" -> TagVisualSpec(
                // E: Collaborateur - Deep Rose Magenta, Tear-drop organic pill
                shape = RoundedCornerShape(topStart = 3.dp, bottomEnd = 3.dp, topEnd = 10.dp, bottomStart = 10.dp),
                primaryColor = Color(0xFFBE185D),
                containerColor = Color(0xFFFCE7F3),
                borderColor = Color(0xFFBE185D),
                textColor = Color(0xFFBE185D),
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.Bold
            )
            "F" -> TagVisualSpec(
                // F: Collaborateur - Deep Cyan / Teal, Octagonal / Boxy modern
                shape = RoundedCornerShape(3.dp),
                primaryColor = Color(0xFF0E7490),
                containerColor = Color(0xFFCFFAFE),
                borderColor = Color(0xFF0E7490),
                textColor = Color(0xFF0E7490),
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.SemiBold
            )
            "G" -> TagVisualSpec(
                // G: Collaborateur - Terracotta Rust / Warm Crimson, Stamped Oval
                shape = RoundedCornerShape(50),
                primaryColor = Color(0xFFC2410C),
                containerColor = Color(0xFFFFEDD5),
                borderColor = Color(0xFFC2410C),
                textColor = Color(0xFFC2410C),
                fontStyle = FontStyle.Normal,
                fontWeight = FontWeight.ExtraBold
            )
            else -> {
                val fallbackProfile = CollaboratorPresets.getProfile(tag)
                TagVisualSpec(
                    shape = CircleShape,
                    primaryColor = Color(fallbackProfile.colorHex),
                    containerColor = Color(fallbackProfile.secondaryColorHex),
                    borderColor = Color(fallbackProfile.colorHex),
                    textColor = Color(fallbackProfile.colorHex),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    /**
     * Specific handwritten text style for the message line written by this author,
     * so user A, B, C, D, E, F, G have their own unique, distinct handwriting signature.
     */
    fun getLineTextStyle(tag: String, authorColor: Color): TextStyle {
        return when (tag.uppercase().trim()) {
            "A" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                color = authorColor
            )
            "B" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 19.5.sp,
                fontWeight = FontWeight.Medium,
                fontStyle = FontStyle.Italic,
                color = authorColor
            )
            "C" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 21.sp,
                fontWeight = FontWeight.SemiBold,
                fontStyle = FontStyle.Normal,
                color = authorColor
            )
            "D" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                fontStyle = FontStyle.Italic,
                letterSpacing = 0.5.sp,
                color = authorColor
            )
            "E" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Normal,
                letterSpacing = 0.3.sp,
                color = authorColor
            )
            "F" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 20.5.sp,
                fontWeight = FontWeight.Medium,
                fontStyle = FontStyle.Italic,
                color = authorColor
            )
            "G" -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 21.sp,
                fontWeight = FontWeight.Black,
                fontStyle = FontStyle.Normal,
                color = authorColor
            )
            else -> TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                color = authorColor
            )
        }
    }
}

/**
 * Renders the distinctive author badge in the margin of a notebook line.
 */
@Composable
fun AuthorTagBadge(
    tag: String,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 26.dp,
    fontSize: TextUnit = 16.sp,
    isMasked: Boolean = false
) {
    val spec = AuthorTagVisuals.getVisualSpec(tag, isMasked)

    Box(
        modifier = modifier
            .size(sizeDp)
            .clip(spec.shape)
            .background(spec.containerColor)
            .border(1.5.dp, spec.borderColor, spec.shape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = if (isMasked) "•" else tag,
            style = TextStyle(
                fontFamily = FontFamily.Cursive,
                fontSize = fontSize,
                fontWeight = spec.fontWeight,
                fontStyle = spec.fontStyle,
                color = spec.textColor
            )
        )
    }
}
