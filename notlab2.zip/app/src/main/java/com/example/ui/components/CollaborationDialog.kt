package com.example.ui.components

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Collaborator
import com.example.data.model.DeviceContact
import com.example.data.util.ContactHelper

val CountryCodes = listOf(
    "+509" to "Haïti (+509)",
    "+1" to "États-Unis / Canada (+1)",
    "+33" to "France (+33)",
    "+1 809" to "Rép. Dominicaine (+1 809)"
)

/**
 * SCREEN 3: Share & Collaboration Bottom Sheet.
 *
 * Implements:
 * - Current members list (profile image, name, online status, permissions)
 * - NO invitation links
 * - "Inviter une personne" phone number interface with country code selector (+509 default)
 * - Strict 8-digit phone validation (e.g. +509 1234 5678)
 * - "Choisir dans mes contacts" with runtime READ_CONTACTS permission
 * - Contacts with Notlab shown first with a badge
 * - Member permissions management ("Peut modifier" or "Lecture seule")
 * - Member removal by the owner
 * - "Quitter ce partage" action
 * - All UI in French
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollaborationDialog(
    collaborators: List<Collaborator>,
    deviceContacts: List<DeviceContact>,
    userPhoneNumber: String,
    totalPages: Int,
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onUpdateUserPhone: (String) -> Unit,
    onInviteCollaborator: (name: String, phone: String, pages: List<Int>, canWrite: Boolean) -> Boolean,
    onToggleWriteAuthorization: (Collaborator, Boolean) -> Unit,
    onToggleAllCollaboratorsWrite: ((Boolean) -> Unit)? = null,
    onRemoveCollaborator: (Collaborator) -> Unit,
    onUpdateCollaboratorPages: (Collaborator, List<Int>) -> Unit,
    onRefreshContacts: () -> Unit
) {
    val context = LocalContext.current

    // Invitation view state
    var showInviteView by remember { mutableStateOf(false) }
    var selectedCountryCode by remember { mutableStateOf("+509") }
    var countryMenuExpanded by remember { mutableStateOf(false) }
    var inviteRawDigits by remember { mutableStateOf("") }
    var inviteName by remember { mutableStateOf("") }
    var invitePermissionWrite by remember { mutableStateOf(true) }
    var invitePermissionMenuExpanded by remember { mutableStateOf(false) }

    // Contact picker state
    var showContactPickerSheet by remember { mutableStateOf(false) }
    var contactSearchQuery by remember { mutableStateOf("") }

    // Quit confirmation dialog
    var showQuitConfirmDialog by remember { mutableStateOf(false) }

    // Permission launcher for READ_CONTACTS (requested only on demand)
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        onRefreshContacts()
        if (isGranted) {
            showContactPickerSheet = true
        }
    }

    fun handleOpenContactPicker() {
        if (ContactHelper.hasContactPermission(context)) {
            onRefreshContacts()
            showContactPickerSheet = true
        } else {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    val is8DigitsValid = inviteRawDigits.filter { it.isDigit() }.length == 8

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF161A24),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 18.dp)
                .testTag("collaboration_bottom_sheet")
        ) {
            // 1. Header: Group Icon + Title + Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2563EB).copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Group,
                            contentDescription = null,
                            tint = Color(0xFF3B82F6),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Partage et collaboration",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(32.dp).testTag("button_close_collab_sheet")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fermer",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 2. Current Members List
            val owner = collaborators.firstOrNull { it.isCurrentUser }
                ?: collaborators.firstOrNull()
            val guests = collaborators.filter { !it.isCurrentUser }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF1E2433))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                // Member 1: Owner (John (Vous))
                MemberRowItem(
                    name = owner?.name ?: "John (Vous)",
                    subtitle = "En ligne",
                    avatarColor = Color(0xFF2563EB),
                    avatarInitials = "J",
                    isOnline = true,
                    isCurrentUser = true
                )

                // Guests
                if (guests.isEmpty()) {
                    // Default sample guest Alexandre if list has only 1
                    MemberRowItem(
                        name = "Alexandre",
                        subtitle = "En ligne",
                        avatarColor = Color(0xFF10B981),
                        avatarInitials = "A",
                        isOnline = true,
                        isCurrentUser = false
                    )
                } else {
                    guests.forEach { guest ->
                        HorizontalDivider(color = Color(0xFF2B3347), thickness = 0.8.dp)
                        MemberRowItem(
                            name = guest.name,
                            subtitle = if (guest.isOnline) "En ligne" else "Hors ligne",
                            avatarColor = Color(guest.avatarColor),
                            avatarInitials = guest.name.take(1).uppercase(),
                            isOnline = guest.isOnline,
                            isCurrentUser = false
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Main Action: "+ Inviter une personne"
            if (!showInviteView) {
                Button(
                    onClick = { showInviteView = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("button_invite_person"),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
                ) {
                    Icon(
                        imageVector = Icons.Default.PersonAdd,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Inviter une personne",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }
            } else {
                // 4. Phone Number Invitation Interface
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("panel_invite_phone"),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E2433),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E384D))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Inviter par numéro de téléphone",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            IconButton(
                                onClick = { showInviteView = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Annuler",
                                    tint = Color(0xFF94A3B8),
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Optional Contact Name
                        OutlinedTextField(
                            value = inviteName,
                            onValueChange = { inviteName = it },
                            label = { Text("Nom du contact (optionnel)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("input_invite_name"),
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color(0xFF2563EB),
                                unfocusedBorderColor = Color(0xFF333C52),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Country Code Selector + Phone Number Input
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Country Code Dropdown
                            Box {
                                OutlinedButton(
                                    onClick = { countryMenuExpanded = true },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.height(56.dp).testTag("button_country_selector"),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333C52))
                                ) {
                                    Text(selectedCountryCode, color = Color.White, fontWeight = FontWeight.Bold)
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White)
                                }

                                DropdownMenu(
                                    expanded = countryMenuExpanded,
                                    onDismissRequest = { countryMenuExpanded = false }
                                ) {
                                    CountryCodes.forEach { (code, label) ->
                                        DropdownMenuItem(
                                            text = { Text(label) },
                                            onClick = {
                                                selectedCountryCode = code
                                                countryMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // 8-digit Phone Input
                            OutlinedTextField(
                                value = inviteRawDigits,
                                onValueChange = { input ->
                                    val digitsOnly = input.filter { it.isDigit() }.take(8)
                                    inviteRawDigits = digitsOnly
                                },
                                label = { Text("Numéro (8 chiffres)") },
                                placeholder = { Text("1234 5678") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                trailingIcon = {
                                    if (is8DigitsValid) {
                                        Icon(
                                            Icons.Default.Check,
                                            contentDescription = "Valide",
                                            tint = Color(0xFF10B981)
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("input_invite_phone"),
                                shape = RoundedCornerShape(10.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = if (is8DigitsValid) Color(0xFF10B981) else Color(0xFF2563EB),
                                    unfocusedBorderColor = if (is8DigitsValid) Color(0xFF10B981) else Color(0xFF333C52),
                                    focusedTextColor = Color.White,
                                    unfocusedTextColor = Color.White
                                )
                            )
                        }

                        // Helper validation message
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (is8DigitsValid) {
                                "✓ Format valide : $selectedCountryCode ${ContactHelper.format8Digits(inviteRawDigits)}"
                            } else {
                                "Le numéro doit comporter exactement 8 chiffres (ex: 1234 5678)."
                            },
                            fontSize = 11.sp,
                            color = if (is8DigitsValid) Color(0xFF10B981) else Color(0xFF94A3B8),
                            fontWeight = if (is8DigitsValid) FontWeight.SemiBold else FontWeight.Normal
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Permission selector: "Peut modifier" or "Lecture seule"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Autorisation :",
                                fontSize = 13.sp,
                                color = Color(0xFFCBD5E1),
                                fontWeight = FontWeight.Medium
                            )

                            Box {
                                OutlinedButton(
                                    onClick = { invitePermissionMenuExpanded = true },
                                    shape = RoundedCornerShape(8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF333C52)),
                                    modifier = Modifier.testTag("button_invite_permission_menu")
                                ) {
                                    Icon(
                                        imageVector = if (invitePermissionWrite) Icons.Default.Edit else Icons.Default.Visibility,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = if (invitePermissionWrite) Color(0xFF3B82F6) else Color(0xFF94A3B8)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (invitePermissionWrite) "Peut modifier" else "Lecture seule",
                                        fontSize = 12.sp,
                                        color = Color.White
                                    )
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = Color.White)
                                }

                                DropdownMenu(
                                    expanded = invitePermissionMenuExpanded,
                                    onDismissRequest = { invitePermissionMenuExpanded = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Peut modifier") },
                                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF3B82F6)) },
                                        onClick = {
                                            invitePermissionWrite = true
                                            invitePermissionMenuExpanded = false
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Lecture seule") },
                                        leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF94A3B8)) },
                                        onClick = {
                                            invitePermissionWrite = false
                                            invitePermissionMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons: "Choisir dans mes contacts" & "Inviter"
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = { handleOpenContactPicker() },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("button_pick_from_contacts"),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF3B82F6))
                            ) {
                                Icon(Icons.Default.Contacts, contentDescription = null, modifier = Modifier.size(15.dp), tint = Color(0xFF3B82F6))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Mes contacts", fontSize = 12.sp, color = Color(0xFF3B82F6))
                            }

                            Button(
                                onClick = {
                                    val formattedPhone = "$selectedCountryCode ${ContactHelper.format8Digits(inviteRawDigits)}"
                                    val finalName = inviteName.ifBlank { "Invité (${inviteRawDigits.takeLast(4)})" }
                                    onInviteCollaborator(finalName, formattedPhone, listOf(1, 2), invitePermissionWrite)
                                    showInviteView = false
                                    inviteRawDigits = ""
                                    inviteName = ""
                                },
                                enabled = is8DigitsValid,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("button_submit_invite"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2563EB),
                                    disabledContainerColor = Color(0xFF2B3345)
                                )
                            ) {
                                Text("Inviter", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 5. Section: Permissions
            Text(
                text = "PERMISSIONS",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF94A3B8),
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Guest permission rows with dropdown "Peut modifier v" or "Lecture seule"
            val displayGuests = if (guests.isEmpty()) {
                listOf(
                    Collaborator(
                        id = 999L,
                        name = "Alexandre",
                        phoneNumber = "+509 3712 3456",
                        canWrite = true,
                        isOnline = true,
                        avatarColor = 0xFF10B981
                    )
                )
            } else guests

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF1E2433))
            ) {
                displayGuests.forEachIndexed { index, guest ->
                    if (index > 0) {
                        HorizontalDivider(color = Color(0xFF2B3347), thickness = 0.8.dp)
                    }
                    GuestPermissionRow(
                        collaborator = guest,
                        onPermissionChanged = { canWrite ->
                            onToggleWriteAuthorization(guest, canWrite)
                        },
                        onDelete = {
                            onRemoveCollaborator(guest)
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // 6. Bottom Action: "Quitter ce partage"
            TextButton(
                onClick = { showQuitConfirmDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("button_leave_sharing")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = null,
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Quitter ce partage",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color(0xFFEF4444)
                )
            }
        }
    }

    // 7. Contact Picker Dialog (Shows contacts who already have Notlab FIRST!)
    if (showContactPickerSheet) {
        val allContacts = if (deviceContacts.isNotEmpty()) deviceContacts else ContactHelper.getFallbackContacts()
        val filtered = allContacts
            .filter {
                it.name.contains(contactSearchQuery, ignoreCase = true) ||
                    it.phoneNumber.contains(contactSearchQuery)
            }
            .sortedByDescending { it.hasNotlab } // Notlab users FIRST

        AlertDialog(
            onDismissRequest = { showContactPickerSheet = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Contacts, contentDescription = null, tint = Color(0xFF2563EB))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Choisir dans mes contacts", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                    Text(
                        text = "Les utilisateurs qui ont déjà Notlab apparaissent en premier.",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = contactSearchQuery,
                        onValueChange = { contactSearchQuery = it },
                        placeholder = { Text("Rechercher un contact...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_search_contacts"),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f).testTag("list_device_contacts"),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filtered) { contact ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        // Auto-populate name and extracted 8-digit number
                                        inviteName = contact.name
                                        val digits = contact.phoneNumber.filter { it.isDigit() }
                                        inviteRawDigits = digits.takeLast(8)
                                        showInviteView = true
                                        showContactPickerSheet = false
                                    }
                                    .testTag("contact_item_${contact.name}"),
                                shape = RoundedCornerShape(10.dp),
                                color = if (contact.hasNotlab) Color(0xFF2563EB).copy(alpha = 0.12f) else Color(0xFF1E2433),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (contact.hasNotlab) Color(0xFF2563EB).copy(alpha = 0.4f) else Color(0xFF2B3347)
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(if (contact.hasNotlab) Color(0xFF2563EB) else Color(0xFF475569)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = contact.name.take(1).uppercase(),
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = contact.name,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 13.sp,
                                                color = Color.White
                                            )
                                            Text(
                                                text = contact.phoneNumber,
                                                fontSize = 11.sp,
                                                color = Color(0xFF94A3B8)
                                            )
                                        }
                                    }

                                    if (contact.hasNotlab) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(Color(0xFF2563EB))
                                                .padding(horizontal = 8.dp, vertical = 3.dp)
                                        ) {
                                            Text(
                                                text = "Notlab",
                                                color = Color.White,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showContactPickerSheet = false }) {
                    Text("Fermer")
                }
            }
        )
    }

    // 8. Quit Collaboration Confirmation Dialog
    if (showQuitConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showQuitConfirmDialog = false },
            title = { Text("Quitter ce partage ?") },
            text = {
                Text("Voulez-vous vraiment quitter ce cahier partagé ? Vous ne pourrez plus voir les mises à jour collaboratives.")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showQuitConfirmDialog = false
                        onDismiss()
                    }
                ) {
                    Text("Oui, quitter", color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showQuitConfirmDialog = false }) {
                    Text("Annuler")
                }
            }
        )
    }
}

/**
 * Single member display row for Screen 3.
 */
@Composable
private fun MemberRowItem(
    name: String,
    subtitle: String,
    avatarColor: Color,
    avatarInitials: String,
    isOnline: Boolean,
    isCurrentUser: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp)
            .testTag("member_row_$name"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Profile Image / Avatar
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(avatarColor)
                    .border(1.5.dp, Color.White.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = avatarInitials,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = name,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color.White
                )
                Text(
                    text = subtitle,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isOnline) Color(0xFF10B981) else Color(0xFF94A3B8)
                )
            }
        }

        // Green Online status indicator dot
        if (isOnline) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF10B981))
                    .border(1.5.dp, Color(0xFF1E2433), CircleShape)
            )
        }
    }
}

/**
 * Guest collaborator permission control row.
 */
@Composable
private fun GuestPermissionRow(
    collaborator: Collaborator,
    onPermissionChanged: (Boolean) -> Unit,
    onDelete: () -> Unit
) {
    var menuExpanded by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("guest_permission_row_${collaborator.name}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(collaborator.avatarColor)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = collaborator.name.take(1).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = collaborator.name,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = Color.White
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            // Dropdown selector: "Peut modifier v" or "Lecture seule v"
            Box {
                OutlinedButton(
                    onClick = { menuExpanded = true },
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E384D)),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(34.dp).testTag("button_permission_dropdown_${collaborator.name}")
                ) {
                    Text(
                        text = if (collaborator.canWrite) "Peut modifier" else "Lecture seule",
                        fontSize = 11.sp,
                        color = if (collaborator.canWrite) Color(0xFF3B82F6) else Color(0xFF94A3B8),
                        fontWeight = FontWeight.Medium
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Peut modifier") },
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color(0xFF3B82F6)) },
                        onClick = {
                            onPermissionChanged(true)
                            menuExpanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Lecture seule") },
                        leadingIcon = { Icon(Icons.Default.Visibility, contentDescription = null, tint = Color(0xFF94A3B8)) },
                        onClick = {
                            onPermissionChanged(false)
                            menuExpanded = false
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Delete / Remove member button (owner can remove)
            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp).testTag("button_remove_member_${collaborator.name}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Supprimer",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
