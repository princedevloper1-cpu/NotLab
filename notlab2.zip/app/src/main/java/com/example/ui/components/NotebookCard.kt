package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotebookItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Notebook Card for the Notlab Home Screen.
 * Shows small notebook thumbnail, notebook name, member count, page count, and date.
 */
@Composable
fun NotebookCard(
    notebook: NotebookItem,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }

    val dateFormat = remember { SimpleDateFormat("d MMM yyyy", Locale.FRENCH) }
    val formattedDate = remember(notebook.dateModified) {
        dateFormat.format(Date(notebook.dateModified))
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("notebook_card_${notebook.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF161B26)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF232A3B))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 1. Small realistic notebook thumbnail with spiral rings on left
            Box(
                modifier = Modifier
                    .size(width = 36.dp, height = 46.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFFBF9F5))
                    .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(4.dp))
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height

                    // Spiral wire loops on the left edge
                    val rings = 5
                    val stepY = h / (rings + 1)
                    for (i in 1..rings) {
                        val cy = stepY * i
                        // Dark wire ring hole
                        drawCircle(
                            color = Color(0xFF0F172A),
                            radius = 1.8f,
                            center = Offset(4f, cy)
                        )
                        // Metal spiral coil highlight
                        drawLine(
                            color = Color(0xFF64748B),
                            start = Offset(1f, cy - 2f),
                            end = Offset(5f, cy + 2f),
                            strokeWidth = 1.2f
                        )
                    }

                    // Vertical faint red margin line
                    drawLine(
                        color = Color(0xFFEF4444).copy(alpha = 0.4f),
                        start = Offset(9f, 0f),
                        end = Offset(9f, h),
                        strokeWidth = 0.8f
                    )

                    // Horizontal faint blue ruled lines
                    for (i in 1..6) {
                        val ly = (h / 7f) * i
                        drawLine(
                            color = Color(0xFF93C5FD).copy(alpha = 0.45f),
                            start = Offset(10f, ly),
                            end = Offset(w - 2f, ly),
                            strokeWidth = 0.6f
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // 2. Notebook Info (Title, members, pages)
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = notebook.title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(3.dp))

                val memberLabel = if (notebook.memberCount > 1) {
                    "${notebook.memberCount} personnes"
                } else {
                    "1 personne"
                }
                val pageLabel = "${notebook.pageCount} page${if (notebook.pageCount > 1) "s" else ""}"

                Text(
                    text = "$memberLabel • $pageLabel",
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )
            }

            // 3. Right: Date & Context Menu
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = formattedDate,
                    fontSize = 12.sp,
                    color = Color(0xFF94A3B8)
                )

                Box {
                    IconButton(
                        onClick = { showMenu = true },
                        modifier = Modifier.size(24.dp).testTag("button_notebook_menu_${notebook.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options du cahier",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false },
                        modifier = Modifier.background(Color(0xFF1E2433))
                    ) {
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = if (notebook.isFavorite) "Retirer des favoris" else "Ajouter aux favoris",
                                    color = Color.White,
                                    fontSize = 13.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (notebook.isFavorite) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = null,
                                    tint = if (notebook.isFavorite) Color(0xFFFBBF24) else Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            onClick = {
                                showMenu = false
                                onToggleFavorite()
                            }
                        )

                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "Supprimer",
                                    color = Color(0xFFEF4444),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }
        }
    }
}
