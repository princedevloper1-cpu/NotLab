package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Collaborator
import com.example.data.model.DrawingPoint
import com.example.data.model.DrawingStroke
import com.example.data.model.NotebookLineEntry
import com.example.data.model.ToolType
import com.example.ui.theme.getFontFamilyById

/**
 * SCREEN 1: Notebook Page as the main focus.
 *
 * Implements:
 * - Realistic cream lined notebook paper
 * - 4 punched binder holes on left margin
 * - Classic vertical red margin line
 * - Ruled blue lines
 * - Top header with date "19 septembre 2026"
 * - Title "Plan pou pwojè Notlab la:" highlighted in yellow
 * - Checklist items (interactive checkboxes to toggle [ ] and [x])
 * - Collaborative author cursor indicators:
 *   - Alexandre: blue pill name badge + cursor '|'
 *   - John: green author cursor indicator 'John |'
 * - Doodle on bottom right:
 *   - Lightbulb with yellow rays and "Big ideas\nBetter together\n- Notlab ♡"
 * - Freehand drawing canvas (Pen, Highlighter, Eraser)
 * - Text tool support
 * - Line composer at the bottom of the page
 */
@Composable
fun NotebookPaper(
    strokes: List<DrawingStroke>,
    lineEntries: List<NotebookLineEntry>,
    selectedTool: ToolType,
    selectedColor: Color,
    strokeWidth: Float,
    lineStyle: String, // "ruled", "grid", "blank"
    paperTone: String,
    textContent: String,
    collaborators: List<Collaborator>,
    canCurrentUserWrite: Boolean,
    isPrivacyMode: Boolean = false,
    onTogglePrivacyMode: (() -> Unit)? = null,
    onToggleChecklist: ((NotebookLineEntry) -> Unit)? = null,
    onTextChange: (String) -> Unit,
    onStrokeDrawn: (DrawingStroke) -> Unit,
    onEraseAtPoint: (DrawingPoint) -> Unit,
    onAddLineEntry: (String, Long) -> Unit,
    onDeleteLineEntry: (NotebookLineEntry) -> Unit,
    selectedFontId: String = "handwriting_1",
    selectedFontSize: Float = 17f,
    isBold: Boolean = false,
    isItalic: Boolean = false,
    isUnderline: Boolean = false,
    selectedTextColor: Long = 0xFF1E293B,
    selectedTextAlign: String = "left",
    onOpenTypography: (() -> Unit)? = null,
    isStrokeSmoothingEnabled: Boolean = true,
    penStyle: String = "Normal",
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val currentPoints = remember { mutableStateListOf<DrawingPoint>() }
    var currentDragStroke by remember { mutableStateOf<DrawingStroke?>(null) }

    // State for the line writer bar at the bottom of the page
    var currentLineInput by remember { mutableStateOf("") }
    var selectedWritingAuthorId by remember { mutableStateOf<Long?>(null) }

    // Paper background color - warm cream realistic paper
    val paperBgColor = when (paperTone) {
        "white" -> Color(0xFFFFFFFF)
        "vintage" -> Color(0xFFFBF6EC)
        "cream" -> Color(0xFFFFFBEB)
        else -> Color(0xFFFFFDF5) // realistic lined-paper notebook style
    }

    val ruledLineColor = Color(0xFF93C5FD).copy(alpha = 0.65f) // Soft blue ruled lines
    val marginLineColor = Color(0xFFEF4444).copy(alpha = 0.65f) // Classic red margin line
    val spiralHoleColor = Color(0xFF1E293B).copy(alpha = 0.35f) // Binder holes

    val topHeaderOffsetDp = 64.dp
    val lineSpacingDp = 38.dp
    val marginOffsetDp = 52.dp

    val lineSpacingPx = with(density) { lineSpacingDp.toPx() }
    val marginOffsetPx = with(density) { marginOffsetDp.toPx() }
    val topHeaderOffsetPx = with(density) { topHeaderOffsetDp.toPx() }

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .shadow(elevation = 8.dp, shape = RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(paperBgColor)
            .testTag("notebook_paper_container")
    ) {
        // 1. Ruled Paper Canvas Background (Lined paper + Red margin + 4 punched binder holes)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            // Render 4 binder holes on left edge
            val holeRadius = 7.dp.toPx()
            val holeX = 15.dp.toPx()
            val holeFractions = listOf(0.14f, 0.38f, 0.62f, 0.86f)
            holeFractions.forEach { frac ->
                val holeY = canvasHeight * frac
                // Dark outer punched hole
                drawCircle(
                    color = spiralHoleColor,
                    radius = holeRadius,
                    center = Offset(holeX, holeY)
                )
                // Subtle inner paper ring
                drawCircle(
                    color = Color(0xFFCBD5E1).copy(alpha = 0.5f),
                    radius = holeRadius * 0.75f,
                    center = Offset(holeX - 1.dp.toPx(), holeY - 1.dp.toPx())
                )
            }

            // Top double header line
            if (lineStyle != "blank") {
                drawLine(
                    color = ruledLineColor.copy(alpha = 0.9f),
                    start = Offset(0f, topHeaderOffsetPx - 8.dp.toPx()),
                    end = Offset(canvasWidth, topHeaderOffsetPx - 8.dp.toPx()),
                    strokeWidth = 1.8f
                )
                drawLine(
                    color = ruledLineColor.copy(alpha = 0.9f),
                    start = Offset(0f, topHeaderOffsetPx),
                    end = Offset(canvasWidth, topHeaderOffsetPx),
                    strokeWidth = 1.8f
                )
            }

            // Horizontal blue ruled lines
            if (lineStyle == "ruled" || lineStyle == "grid") {
                var currentY = topHeaderOffsetPx + lineSpacingPx
                while (currentY < canvasHeight) {
                    drawLine(
                        color = ruledLineColor,
                        start = Offset(0f, currentY),
                        end = Offset(canvasWidth, currentY),
                        strokeWidth = 1.2f
                    )
                    currentY += lineSpacingPx
                }
            }

            // Classic vertical Red Margin line
            if (lineStyle != "blank") {
                drawLine(
                    color = marginLineColor,
                    start = Offset(marginOffsetPx, 0f),
                    end = Offset(marginOffsetPx, canvasHeight),
                    strokeWidth = 2.0f
                )
            }
        }

        // 2. Ruled Lines Content Layer
        val guestCollaborators = collaborators.filter { !it.isCurrentUser }
        val isSoloWriting = guestCollaborators.isNotEmpty() && guestCollaborators.none { it.canWrite }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 72.dp) // Leave space for line composer
        ) {
            // A. Header area (Mode indicator + Top-Right Date "19 septembre 2026")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(topHeaderOffsetDp)
                    .padding(start = marginOffsetDp + 8.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left: Mode indicator banner
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(
                            if (isPrivacyMode) {
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.75f)
                            } else if (isSoloWriting) {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                            } else {
                                Color(0xFF2563EB).copy(alpha = 0.12f)
                            }
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isPrivacyMode) Icons.Default.Lock else if (isSoloWriting) Icons.Default.Person else Icons.Default.Group,
                        contentDescription = null,
                        tint = if (isPrivacyMode) MaterialTheme.colorScheme.error else Color(0xFF2563EB),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isPrivacyMode) "Mode Confidentiel 🔒" else if (isSoloWriting) "Mode Solo" else "Mode Partagé 👥",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isPrivacyMode) MaterialTheme.colorScheme.onErrorContainer else Color(0xFF1E293B)
                    )
                }

                // Right: Date in cursive script font matching the realistic notebook
                Text(
                    text = "19 septembre 2026",
                    style = TextStyle(
                        fontFamily = FontFamily.Cursive,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                )
            }

            // B. Ruled writing lines list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("notebook_lines_list")
            ) {
                itemsIndexed(lineEntries) { index, entry ->
                    val isOwnerEntry = (entry.authorTag == "A" || entry.authorName.contains("Moi", ignoreCase = true) || entry.authorName.contains("John", ignoreCase = true))
                    val isMasked = isPrivacyMode && !isOwnerEntry

                    NotebookSingleLineRow(
                        entry = entry,
                        lineIndex = index,
                        lineSpacingDp = lineSpacingDp,
                        marginOffsetDp = marginOffsetDp,
                        ruledLineColor = ruledLineColor,
                        isMasked = isMasked,
                        onToggleChecklist = { onToggleChecklist?.invoke(entry) },
                        onDelete = { onDeleteLineEntry(entry) }
                    )
                }
            }
        }

        // 3. Doodle on bottom right: Lightbulb with rays + handwritten note
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 76.dp, end = 20.dp),
            contentAlignment = Alignment.BottomEnd
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.testTag("notebook_bottom_doodle")
            ) {
                // Lightbulb doodle
                Canvas(modifier = Modifier.size(46.dp)) {
                    val yellowGlow = Color(0xFFF59E0B)
                    val darkInk = Color(0xFF1E293B)
                    // Glow Rays
                    drawLine(yellowGlow, Offset(23f, 4f), Offset(23f, 9f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                    drawLine(yellowGlow, Offset(10f, 9f), Offset(14f, 13f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                    drawLine(yellowGlow, Offset(36f, 9f), Offset(32f, 13f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                    drawLine(yellowGlow, Offset(4f, 22f), Offset(9f, 22f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                    drawLine(yellowGlow, Offset(37f, 22f), Offset(42f, 22f), strokeWidth = 2.5f, cap = StrokeCap.Round)
                    // Bulb body
                    drawCircle(Color(0xFFFEF08A), radius = 13f, center = Offset(23f, 23f))
                    drawCircle(darkInk, radius = 13f, center = Offset(23f, 23f), style = Stroke(width = 1.8f))
                    // Base lines
                    drawLine(darkInk, Offset(19f, 36f), Offset(27f, 36f), strokeWidth = 2f, cap = StrokeCap.Round)
                    drawLine(darkInk, Offset(20f, 39f), Offset(26f, 39f), strokeWidth = 2f, cap = StrokeCap.Round)
                }

                Text(
                    text = "Big ideas\nBetter together\n- Notlab ♡",
                    style = TextStyle(
                        fontFamily = FontFamily.Cursive,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        lineHeight = 16.sp
                    ),
                    textAlign = TextAlign.Center
                )
            }
        }

        // 4. Freehand Drawing Canvas Layer (Pen, Highlighter, Eraser)
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(selectedTool, selectedColor, strokeWidth, canCurrentUserWrite) {
                    if (!canCurrentUserWrite) return@pointerInput

                    detectDragGestures(
                        onDragStart = { offset ->
                            val pt = DrawingPoint(offset.x, offset.y)
                            if (selectedTool == ToolType.ERASER) {
                                onEraseAtPoint(pt)
                            } else {
                                currentPoints.clear()
                                currentPoints.add(pt)
                                val alpha = if (selectedTool == ToolType.HIGHLIGHTER) 0.40f else 1.0f
                                val actualWidth = if (selectedTool == ToolType.HIGHLIGHTER) strokeWidth * 2.5f else strokeWidth
                                currentDragStroke = DrawingStroke(
                                    toolType = selectedTool.name,
                                    color = selectedColor.value.toLong(),
                                    strokeWidth = actualWidth,
                                    alpha = alpha,
                                    points = listOf(pt)
                                )
                            }
                        },
                        onDrag = { change, _ ->
                            change.consume()
                            val pt = DrawingPoint(change.position.x, change.position.y)
                            if (selectedTool == ToolType.ERASER) {
                                onEraseAtPoint(pt)
                            } else {
                                currentPoints.add(pt)
                                currentDragStroke = currentDragStroke?.copy(points = currentPoints.toList())
                            }
                        },
                        onDragEnd = {
                            if (selectedTool != ToolType.ERASER) {
                                currentDragStroke?.let { stroke ->
                                    if (stroke.points.isNotEmpty()) {
                                        onStrokeDrawn(stroke)
                                    }
                                }
                            }
                            currentPoints.clear()
                            currentDragStroke = null
                        },
                        onDragCancel = {
                            currentPoints.clear()
                            currentDragStroke = null
                        }
                    )
                }
        ) {
            // Render saved strokes
            strokes.forEach { stroke ->
                drawStroke(stroke, isStrokeSmoothingEnabled, penStyle)
            }
            // Render active drag stroke
            currentDragStroke?.let { stroke ->
                drawStroke(stroke, isStrokeSmoothingEnabled, penStyle)
            }
        }

        // 5. Line Entry Composer at the bottom of the page
        val activeWriter = collaborators.firstOrNull { it.id == selectedWritingAuthorId }
            ?: collaborators.firstOrNull { it.isCurrentUser }
        val isAllowedToWrite = activeWriter?.canWrite ?: true

        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .shadow(elevation = 6.dp, shape = RoundedCornerShape(20.dp))
                .testTag("line_composer_container"),
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFF1E2433),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E384D))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Author tag pill selector & Typography trigger ("A" icon)
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(activeWriter?.avatarColor ?: 0xFF2563EB))
                        .border(1.5.dp, Color(0xFF60A5FA), CircleShape)
                        .clickable {
                            onOpenTypography?.invoke()
                        }
                        .testTag("composer_author_badge"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = activeWriter?.tag ?: "A",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedTextField(
                    value = currentLineInput,
                    onValueChange = { currentLineInput = it },
                    placeholder = {
                        Text(
                            text = if (isAllowedToWrite) "Écrire une ligne sur le cahier..." else "Écriture bloquée (Lecture seule)",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    },
                    textStyle = TextStyle(
                        fontFamily = getFontFamilyById(selectedFontId),
                        fontSize = selectedFontSize.sp,
                        fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal,
                        fontStyle = if (isItalic) FontStyle.Italic else FontStyle.Normal,
                        textDecoration = if (isUnderline) TextDecoration.Underline else TextDecoration.None,
                        color = Color.White
                    ),
                    enabled = isAllowedToWrite,
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("input_composer_text"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF2563EB),
                        unfocusedBorderColor = Color(0xFF333C52),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.width(6.dp))

                FilledIconButton(
                    onClick = {
                        if (currentLineInput.isNotBlank() && isAllowedToWrite) {
                            val targetAuthorId = activeWriter?.id ?: 0L
                            onAddLineEntry(currentLineInput.trim(), targetAuthorId)
                            currentLineInput = ""
                        }
                    },
                    enabled = currentLineInput.isNotBlank() && isAllowedToWrite,
                    modifier = Modifier.size(38.dp).testTag("button_send_line_entry")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Envoyer sur le cahier",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Renders a single handwritten-style line on the notebook paper.
 * Implements:
 * - Yellow highlighter behind title "Plan pou pwojè Notlab la:"
 * - Interactive checkboxes for [ ] and [x]
 * - Collaborative author cursor badges (Alexandre pill, John green cursor)
 */
@Composable
private fun NotebookSingleLineRow(
    entry: NotebookLineEntry,
    lineIndex: Int,
    lineSpacingDp: androidx.compose.ui.unit.Dp,
    marginOffsetDp: androidx.compose.ui.unit.Dp,
    ruledLineColor: Color,
    isMasked: Boolean = false,
    onToggleChecklist: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteOption by remember { mutableStateOf(false) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(lineSpacingDp)
            .drawBehind {
                drawLine(
                    color = ruledLineColor,
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 1.2f
                )
            }
            .clickable { showDeleteOption = !showDeleteOption },
        verticalAlignment = Alignment.Bottom
    ) {
        // 1. Left of red margin: Author Tag A, B...
        Box(
            modifier = Modifier
                .width(marginOffsetDp - 2.dp)
                .height(lineSpacingDp)
                .padding(bottom = 5.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color(entry.authorColor).copy(alpha = 0.15f))
                    .border(1.dp, Color(entry.authorColor), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = entry.authorTag,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(entry.authorColor)
                )
            }
        }

        Spacer(modifier = Modifier.width(6.dp))

        // 2. Right of red margin: Text entry sitting right on the ruled line
        Box(
            modifier = Modifier
                .weight(1f)
                .height(lineSpacingDp)
                .padding(bottom = 3.dp, end = 12.dp),
            contentAlignment = Alignment.BottomStart
        ) {
            val content = entry.content

            when {
                // Title line with yellow highlighter
                content.contains("Plan pou", ignoreCase = true) -> {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(0xFFFEF08A).copy(alpha = 0.85f))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                            .testTag("notebook_highlighted_title")
                    ) {
                        Text(
                            text = content,
                            style = TextStyle(
                                fontFamily = getFontFamilyById(entry.fontFamilyId),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1E293B)
                            )
                        )
                    }
                }

                // Checklist item: [ ] or [x]
                content.startsWith("[ ] ") || content.startsWith("[x] ") || content.startsWith("[] ") -> {
                    val isChecked = content.startsWith("[x] ")
                    val cleanText = content
                        .removePrefix("[ ] ")
                        .removePrefix("[x] ")
                        .removePrefix("[] ")

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clickable(onClick = onToggleChecklist)
                            .testTag("checklist_item_$lineIndex")
                    ) {
                        Icon(
                            imageVector = if (isChecked) Icons.Default.CheckBox else Icons.Default.CheckBoxOutlineBlank,
                            contentDescription = if (isChecked) "Tâche cochée" else "Tâche à cocher",
                            tint = if (isChecked) Color(0xFF2563EB) else Color(0xFF64748B),
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = cleanText,
                            style = TextStyle(
                                fontFamily = getFontFamilyById(entry.fontFamilyId),
                                fontSize = if (entry.fontSizeSp > 0f) entry.fontSizeSp.sp else 16.sp,
                                fontWeight = if (isChecked) FontWeight.Normal else (if (entry.isBold) FontWeight.Bold else FontWeight.Medium),
                                fontStyle = if (entry.isItalic) FontStyle.Italic else FontStyle.Normal,
                                color = if (isChecked) Color(0xFF64748B) else (if (entry.textColor != 0L && entry.textColor != 0xFF1E293BL) Color(entry.textColor) else Color(0xFF1E293B)),
                                textDecoration = if (isChecked) TextDecoration.LineThrough else (if (entry.isUnderline) TextDecoration.Underline else TextDecoration.None)
                            )
                        )
                    }
                }

                // Alexandre collaborative line with cursor indicator
                entry.authorName.contains("Alexandre", ignoreCase = true) || entry.authorTag == "B" -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.testTag("author_indicator_alexandre")
                    ) {
                        // Blue pill author badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF2563EB))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = "Alexandre",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = content,
                            style = TextStyle(
                                fontFamily = getFontFamilyById(entry.fontFamilyId),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2563EB)
                            )
                        )
                        Text(
                            text = " |",
                            style = TextStyle(
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2563EB)
                            )
                        )
                    }
                }

                // John author indicator line
                entry.authorName.contains("John", ignoreCase = true) && content.contains("Parfait", ignoreCase = true) -> {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.testTag("author_indicator_john")
                    ) {
                        Text(
                            text = "John | ",
                            style = TextStyle(
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF10B981)
                            )
                        )
                        Text(
                            text = "$content |",
                            style = TextStyle(
                                fontFamily = getFontFamilyById(entry.fontFamilyId),
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF10B981)
                            )
                        )
                    }
                }

                // Standard handwritten note line
                else -> {
                    val lineFontFamily = getFontFamilyById(entry.fontFamilyId)
                    val fontSize = if (entry.fontSizeSp > 0f) entry.fontSizeSp.sp else 18.sp
                    val fontWeight = if (entry.isBold) FontWeight.Bold else FontWeight.Normal
                    val fontStyle = if (entry.isItalic) FontStyle.Italic else FontStyle.Normal
                    val textDecoration = if (entry.isUnderline) TextDecoration.Underline else TextDecoration.None
                    val textColor = if (entry.textColor != 0L && entry.textColor != 0xFF1E293BL) Color(entry.textColor) else Color(entry.authorColor)
                    val textAlign = when (entry.textAlign) {
                        "center" -> TextAlign.Center
                        "right" -> TextAlign.End
                        else -> TextAlign.Start
                    }

                    Text(
                        text = content,
                        style = TextStyle(
                            fontFamily = lineFontFamily,
                            fontSize = fontSize,
                            fontWeight = fontWeight,
                            fontStyle = fontStyle,
                            textDecoration = textDecoration,
                            color = textColor,
                            textAlign = textAlign
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("notebook_line_text_$lineIndex")
                    )
                }
            }

            // Quick delete icon if tapped
            if (showDeleteOption) {
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Supprimer",
                        tint = Color(0xFFEF4444),
                        modifier = Modifier.size(15.dp)
                    )
                }
            }
        }
    }
}

/**
 * Draws a stroke onto the canvas, respecting smoothing and pen style.
 */
private fun DrawScope.drawStroke(
    stroke: DrawingStroke,
    isSmoothing: Boolean = true,
    penStyle: String = "Normal"
) {
    val points = stroke.points
    if (points.isEmpty()) return

    val strokeColor = Color(stroke.color.toULong()).copy(alpha = stroke.alpha)
    val cap = when {
        stroke.toolType == ToolType.HIGHLIGHTER.name -> StrokeCap.Square
        penStyle == "Calligraphie" || penStyle == "Biseauté" -> StrokeCap.Square
        else -> StrokeCap.Round
    }
    val join = when {
        penStyle == "Calligraphie" -> StrokeJoin.Miter
        else -> StrokeJoin.Round
    }

    if (points.size == 1) {
        val p = points.first()
        drawCircle(
            color = strokeColor,
            radius = stroke.strokeWidth / 2,
            center = Offset(p.x, p.y)
        )
        return
    }

    val path = Path()
    path.moveTo(points[0].x, points[0].y)

    if (isSmoothing) {
        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val curr = points[i]
            val midX = (prev.x + curr.x) / 2
            val midY = (prev.y + curr.y) / 2
            path.quadraticTo(prev.x, prev.y, midX, midY)
        }
        val last = points.last()
        path.lineTo(last.x, last.y)
    } else {
        for (i in 1 until points.size) {
            path.lineTo(points[i].x, points[i].y)
        }
    }

    drawPath(
        path = path,
        color = strokeColor,
        style = Stroke(
            width = stroke.strokeWidth,
            cap = cap,
            join = join
        )
    )
}
