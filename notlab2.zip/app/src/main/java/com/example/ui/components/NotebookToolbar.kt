package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FormatAlignCenter
import androidx.compose.material.icons.filled.FormatAlignLeft
import androidx.compose.material.icons.filled.FormatAlignRight
import androidx.compose.material.icons.filled.FormatBold
import androidx.compose.material.icons.filled.FormatItalic
import androidx.compose.material.icons.filled.FormatUnderlined
import androidx.compose.material.icons.filled.Highlight
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ToolType
import com.example.ui.theme.getFontDisplayName
import com.example.ui.theme.getFontFamilyById

// Primary colors from Screen 2
val PrimaryToolColors = listOf(
    Color(0xFF111827) to "Noir",
    Color(0xFF2563EB) to "Bleu",
    Color(0xFFEF4444) to "Rouge",
    Color(0xFF10B981) to "Vert",
    Color(0xFF8B5CF6) to "Violet"
)

// Extended colors accessible through the '+' button
val ExtendedToolColors = listOf(
    Color(0xFFFBBF24) to "Jaune Surligneur",
    Color(0xFF0284C7) to "Bleu Ciel",
    Color(0xFFF472B6) to "Rose",
    Color(0xFFD97706) to "Orange",
    Color(0xFF78350F) to "Marron"
)

// 3 Stroke thickness options from Screen 2
val StrokeThicknessOptions = listOf(
    2.5f to "Fin",
    5.0f to "Moyen",
    9.0f to "Épais"
)

/**
 * SCREEN 1 & SCREEN 2: Bottom Toolbar with Floating Tools Panel & Plus BottomSheet.
 *
 * Implements:
 * - Toolbar: Pen (Plume), Highlighter (Surligneur), Eraser (Gomme), Text (Texte), Color (Couleur), Plus (...)
 * - When Pen or Color is selected, opens a small floating panel above the toolbar.
 * - Allows stroke thickness and color selection.
 * - The "Plus" button opens a compact bottom sheet with extra actions:
 *   Add image, Add checklist, Add shape, Add voice note, Add attachment, Add new page
 * - Keeps the notebook visible behind the panel.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotebookToolbar(
    selectedTool: ToolType,
    selectedColor: Color,
    strokeWidth: Float,
    canUndo: Boolean,
    canRedo: Boolean,
    lineStyle: String,
    selectedFontId: String = "handwriting_1",
    fontSize: Float = 17f,
    isBold: Boolean = false,
    isItalic: Boolean = false,
    isUnderline: Boolean = false,
    selectedTextColor: Long = 0xFF1E293B,
    selectedTextAlign: String = "left",
    onOpenTypographySheet: () -> Unit = {},
    onFontSizeChanged: (Float) -> Unit = {},
    onToggleBold: () -> Unit = {},
    onToggleItalic: () -> Unit = {},
    onToggleUnderline: () -> Unit = {},
    onTextColorSelected: (Long) -> Unit = {},
    onTextAlignSelected: (String) -> Unit = {},
    isStrokeSmoothingEnabled: Boolean = true,
    penStyle: String = "Normal",
    onStrokeSmoothingToggled: (Boolean) -> Unit = {},
    onPenStyleSelected: (String) -> Unit = {},
    isPenSettingsOpen: Boolean = false,
    onTogglePenSettings: () -> Unit = {},
    onClosePenSettings: () -> Unit = {},
    onToolSelected: (ToolType) -> Unit,
    onColorSelected: (Color) -> Unit,
    onStrokeWidthSelected: (Float) -> Unit,
    onLineStyleSelected: (String) -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onClearPage: () -> Unit,
    onAddImage: (() -> Unit)? = null,
    onAddChecklist: (() -> Unit)? = null,
    onAddShape: (() -> Unit)? = null,
    onAddVoiceNote: (() -> Unit)? = null,
    onAddAttachment: (() -> Unit)? = null,
    onAddNewPage: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Floating tools panel state (Screen 2)
    var isFloatingPanelOpen by remember { mutableStateOf(true) }
    var isTextFloatingPanelOpen by remember { mutableStateOf(true) }
    var showExtendedColors by remember { mutableStateOf(false) }

    // Plus actions bottom sheet state (Screen 2)
    var showPlusBottomSheet by remember { mutableStateOf(false) }
    val plusSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            horizontalAlignment = Alignment.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            // SCREEN 5: Detailed Drawing Tool Settings Panel (Épaisseur 1/3/6 px, Couleurs, Lissage, Plume)
            AnimatedVisibility(
                visible = isPenSettingsOpen && selectedTool == ToolType.PEN,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 }
            ) {
                PenSettingsPanel(
                    strokeWidth = strokeWidth,
                    selectedColor = selectedColor,
                    isSmoothingEnabled = isStrokeSmoothingEnabled,
                    penStyle = penStyle,
                    onStrokeWidthSelected = onStrokeWidthSelected,
                    onColorSelected = onColorSelected,
                    onSmoothingToggled = onStrokeSmoothingToggled,
                    onPenStyleSelected = onPenStyleSelected,
                    onClose = onClosePenSettings,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }

            // SCREEN 2: Floating panel above toolbar (for Highlighter stroke width and color selection)
            val shouldShowFloatingPanel = isFloatingPanelOpen && (selectedTool == ToolType.HIGHLIGHTER)

            AnimatedVisibility(
                visible = shouldShowFloatingPanel,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 }
            ) {
                Surface(
                    modifier = Modifier
                        .padding(bottom = 8.dp, start = 8.dp)
                        .testTag("floating_tools_panel"),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF181C26),
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B3245))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        // Top Row: 3 Stroke Thicknesses (3 dots: small, medium, large)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            StrokeThicknessOptions.forEach { (thickness, label) ->
                                val isSelected = kotlin.math.abs(strokeWidth - thickness) < 1.0f
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isSelected) Color(0xFF2563EB).copy(alpha = 0.25f) else Color.Transparent
                                        )
                                        .border(
                                            width = if (isSelected) 1.5.dp else 0.dp,
                                            color = if (isSelected) Color(0xFF2563EB) else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { onStrokeWidthSelected(thickness) }
                                        .testTag("stroke_width_$label"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val dotRadius = when (thickness) {
                                        2.5f -> 4.dp
                                        5.0f -> 8.dp
                                        else -> 13.dp
                                    }
                                    Box(
                                        modifier = Modifier
                                            .size(dotRadius)
                                            .clip(CircleShape)
                                            .background(if (isSelected) Color.White else Color(0xFF94A3B8))
                                    )
                                }
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .padding(vertical = 6.dp),
                            color = Color(0xFF2B3245),
                            thickness = 0.8.dp
                        )

                        // Bottom Row: Color Dots (Black, Blue with ring, Red, Green, Purple, Plus)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            PrimaryToolColors.forEach { (color, name) ->
                                val isSelected = selectedColor == color
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(color)
                                        .border(
                                            width = if (isSelected) 2.5.dp else 1.dp,
                                            color = if (isSelected) Color(0xFF3B82F6) else Color(0xFF475569),
                                            shape = CircleShape
                                        )
                                        .clickable {
                                            onColorSelected(color)
                                        }
                                        .testTag("color_item_$name")
                                )
                            }

                            // '+' Button for more colors
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF222836))
                                    .border(1.dp, Color(0xFF374151), CircleShape)
                                    .clickable { showExtendedColors = !showExtendedColors }
                                    .testTag("button_more_colors"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Plus de couleurs",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        // Extended colors row (if '+' tapped)
                        AnimatedVisibility(visible = showExtendedColors) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                ExtendedToolColors.forEach { (color, name) ->
                                    val isSelected = selectedColor == color
                                    Box(
                                        modifier = Modifier
                                            .size(26.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(
                                                width = if (isSelected) 2.dp else 0.8.dp,
                                                color = if (isSelected) Color.White else Color(0xFF475569),
                                                shape = CircleShape
                                            )
                                            .clickable {
                                                onColorSelected(color)
                                                showExtendedColors = false
                                            }
                                            .testTag("extended_color_$name")
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // TEXT TOOL: Contextual Floating Typography Panel (Screen 2)
            val shouldShowTextPanel = isTextFloatingPanelOpen && selectedTool == ToolType.TEXT

            AnimatedVisibility(
                visible = shouldShowTextPanel,
                enter = fadeIn() + slideInVertically { it / 2 },
                exit = fadeOut() + slideOutVertically { it / 2 }
            ) {
                Surface(
                    modifier = Modifier
                        .padding(bottom = 8.dp)
                        .fillMaxWidth()
                        .testTag("floating_text_panel"),
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFF181C26),
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B3245))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        // First Row: Font picker, Size (-/+/sp), and Style toggles (B, I, U)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // 1. Font selector
                            Surface(
                                onClick = onOpenTypographySheet,
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFF222938),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF384259)),
                                modifier = Modifier.testTag("button_font_picker")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = getFontDisplayName(selectedFontId),
                                        style = TextStyle(
                                            fontFamily = getFontFamilyById(selectedFontId),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = Color.White
                                        ),
                                        maxLines = 1
                                    )
                                    Icon(
                                        imageVector = Icons.Default.ArrowDropDown,
                                        contentDescription = "Changer la police",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            // 2. Size controls
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(2.dp),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF222938))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                IconButton(
                                    onClick = { onFontSizeChanged((fontSize - 1f).coerceAtLeast(12f)) },
                                    modifier = Modifier.size(28.dp).testTag("button_font_size_decrease")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Remove,
                                        contentDescription = "Réduire la taille",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(
                                    text = "${fontSize.toInt()} sp",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE2E8F0),
                                    modifier = Modifier.padding(horizontal = 2.dp)
                                )
                                IconButton(
                                    onClick = { onFontSizeChanged((fontSize + 1f).coerceAtMost(32f)) },
                                    modifier = Modifier.size(28.dp).testTag("button_font_size_increase")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Augmenter la taille",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            // 3. Bold, Italic, Underline
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Bold
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isBold) Color(0xFF2563EB) else Color(0xFF222938))
                                        .border(1.dp, if (isBold) Color(0xFF3B82F6) else Color(0xFF384259), RoundedCornerShape(8.dp))
                                        .clickable(onClick = onToggleBold)
                                        .testTag("button_text_bold"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatBold,
                                        contentDescription = "Gras",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Italic
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isItalic) Color(0xFF2563EB) else Color(0xFF222938))
                                        .border(1.dp, if (isItalic) Color(0xFF3B82F6) else Color(0xFF384259), RoundedCornerShape(8.dp))
                                        .clickable(onClick = onToggleItalic)
                                        .testTag("button_text_italic"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatItalic,
                                        contentDescription = "Italique",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Underline
                                Box(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isUnderline) Color(0xFF2563EB) else Color(0xFF222938))
                                        .border(1.dp, if (isUnderline) Color(0xFF3B82F6) else Color(0xFF384259), RoundedCornerShape(8.dp))
                                        .clickable(onClick = onToggleUnderline)
                                        .testTag("button_text_underline"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatUnderlined,
                                        contentDescription = "Souligné",
                                        tint = Color.White,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }

                        HorizontalDivider(
                            modifier = Modifier.padding(vertical = 6.dp),
                            color = Color(0xFF2B3245),
                            thickness = 0.8.dp
                        )

                        // Second Row: Text Color selection and Alignment
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Text Colors
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val textColors = listOf(
                                    0xFF111827L to "Noir",
                                    0xFF2563EBL to "Bleu",
                                    0xFFEF4444L to "Rouge",
                                    0xFF10B981L to "Vert",
                                    0xFF8B5CF6L to "Violet"
                                )
                                textColors.forEach { (cVal, name) ->
                                    val isSelected = selectedTextColor == cVal
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(Color(cVal))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) Color(0xFF3B82F6) else Color(0xFF475569),
                                                shape = CircleShape
                                            )
                                            .clickable { onTextColorSelected(cVal) }
                                            .testTag("text_color_$name")
                                    )
                                }
                            }

                            // Alignment
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                // Left
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedTextAlign == "left") Color(0xFF2563EB) else Color(0xFF222938))
                                        .clickable { onTextAlignSelected("left") }
                                        .testTag("button_align_left"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatAlignLeft,
                                        contentDescription = "Aligner à gauche",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                // Center
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedTextAlign == "center") Color(0xFF2563EB) else Color(0xFF222938))
                                        .clickable { onTextAlignSelected("center") }
                                        .testTag("button_align_center"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatAlignCenter,
                                        contentDescription = "Centrer",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }

                                // Right
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (selectedTextAlign == "right") Color(0xFF2563EB) else Color(0xFF222938))
                                        .clickable { onTextAlignSelected("right") }
                                        .testTag("button_align_right"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FormatAlignRight,
                                        contentDescription = "Aligner à droite",
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // SCREEN 1: Bottom Toolbar Container
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notebook_bottom_toolbar"),
                shape = RoundedCornerShape(26.dp),
                color = Color(0xFF161A24),
                shadowElevation = 8.dp,
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF283042))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 6.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    // 1. Plume (Pen) - Reopens settings if already active
                    ToolbarPillItem(
                        icon = Icons.Default.Edit,
                        label = "Plume",
                        isSelected = selectedTool == ToolType.PEN,
                        testTag = "toolbar_pen",
                        onClick = {
                            if (selectedTool == ToolType.PEN) {
                                onTogglePenSettings()
                            } else {
                                onToolSelected(ToolType.PEN)
                                onTogglePenSettings()
                            }
                            isFloatingPanelOpen = false
                            isTextFloatingPanelOpen = false
                        }
                    )

                    // 2. Surligneur (Highlighter)
                    ToolbarPillItem(
                        icon = Icons.Default.Highlight,
                        label = "Surligneur",
                        isSelected = selectedTool == ToolType.HIGHLIGHTER,
                        testTag = "toolbar_highlighter",
                        onClick = {
                            onToolSelected(ToolType.HIGHLIGHTER)
                            onColorSelected(Color(0xFFFBBF24))
                            isFloatingPanelOpen = true
                            isTextFloatingPanelOpen = false
                            onClosePenSettings()
                        }
                    )

                    // 3. Gomme (Eraser)
                    ToolbarPillItem(
                        icon = Icons.Default.AutoFixHigh,
                        label = "Gomme",
                        isSelected = selectedTool == ToolType.ERASER,
                        testTag = "toolbar_eraser",
                        onClick = {
                            onToolSelected(ToolType.ERASER)
                            isFloatingPanelOpen = false
                            isTextFloatingPanelOpen = false
                            onClosePenSettings()
                        }
                    )

                    // 4. Texte (Text)
                    ToolbarPillItem(
                        icon = Icons.Default.TextFields,
                        label = "Texte",
                        isSelected = selectedTool == ToolType.TEXT,
                        testTag = "toolbar_text",
                        onClick = {
                            onClosePenSettings()
                            if (selectedTool == ToolType.TEXT) {
                                isTextFloatingPanelOpen = !isTextFloatingPanelOpen
                            } else {
                                onToolSelected(ToolType.TEXT)
                                isTextFloatingPanelOpen = true
                                isFloatingPanelOpen = false
                            }
                        }
                    )

                    // 5. Couleur (Color)
                    ToolbarPillItem(
                        icon = Icons.Default.Palette,
                        label = "Couleur",
                        isSelected = (isPenSettingsOpen && selectedTool == ToolType.PEN) || (isFloatingPanelOpen && selectedTool == ToolType.HIGHLIGHTER),
                        activeColor = selectedColor,
                        testTag = "toolbar_color",
                        onClick = {
                            if (selectedTool == ToolType.PEN) {
                                onTogglePenSettings()
                            } else if (selectedTool == ToolType.HIGHLIGHTER) {
                                isFloatingPanelOpen = !isFloatingPanelOpen
                            } else {
                                onToolSelected(ToolType.PEN)
                                onTogglePenSettings()
                            }
                            isTextFloatingPanelOpen = false
                        }
                    )

                    // 6. Plus (...)
                    ToolbarPillItem(
                        icon = Icons.Default.MoreHoriz,
                        label = "Plus",
                        isSelected = showPlusBottomSheet,
                        testTag = "toolbar_plus",
                        onClick = {
                            showPlusBottomSheet = true
                        }
                    )
                }
            }
        }
    }

    // SCREEN 2: "Plus" Compact Bottom Sheet with Extra Actions
    if (showPlusBottomSheet) {
        ModalBottomSheet(
            onDismissRequest = { showPlusBottomSheet = false },
            sheetState = plusSheetState,
            containerColor = Color(0xFF161A24),
            dragHandle = null
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
                    .testTag("plus_actions_bottom_sheet")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Actions supplémentaires",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    IconButton(
                        onClick = { showPlusBottomSheet = false },
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Fermer",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // The 6 requested extra actions:
                // 1. Ajouter une image
                PlusActionItem(
                    icon = Icons.Default.Image,
                    title = "Ajouter une image",
                    subtitle = "Insérer une photo ou un schéma sur la page",
                    testTag = "action_add_image",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddImage?.invoke()
                    }
                )

                // 2. Ajouter une liste de tâches
                PlusActionItem(
                    icon = Icons.Default.Checklist,
                    title = "Ajouter une liste de tâches",
                    subtitle = "Insérer des cases à cocher interactives",
                    testTag = "action_add_checklist",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddChecklist?.invoke()
                    }
                )

                // 3. Ajouter une forme
                PlusActionItem(
                    icon = Icons.Default.Category,
                    title = "Ajouter une forme",
                    subtitle = "Rectangle, cercle, flèche ou bulle d'idées",
                    testTag = "action_add_shape",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddShape?.invoke()
                    }
                )

                // 4. Ajouter une note vocale
                PlusActionItem(
                    icon = Icons.Default.Mic,
                    title = "Ajouter une note vocale",
                    subtitle = "Enregistrer un mémo audio collaboratif",
                    testTag = "action_add_voice_note",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddVoiceNote?.invoke()
                    }
                )

                // 5. Ajouter une pièce jointe
                PlusActionItem(
                    icon = Icons.Default.AttachFile,
                    title = "Ajouter une pièce jointe",
                    subtitle = "Joindre un document ou un fichier lié",
                    testTag = "action_add_attachment",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddAttachment?.invoke()
                    }
                )

                // 6. Ajouter une nouvelle page
                PlusActionItem(
                    icon = Icons.Default.NoteAdd,
                    title = "Ajouter une nouvelle page",
                    subtitle = "Créer une nouvelle feuille vierge",
                    testTag = "action_add_new_page",
                    onClick = {
                        showPlusBottomSheet = false
                        onAddNewPage?.invoke()
                    }
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

/**
 * Single Toolbar item button:
 * When active/selected: renders as a blue pill with white text & icon.
 * When inactive: renders as a clean icon + subtle label.
 */
@Composable
private fun ToolbarPillItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    activeColor: Color? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                if (isSelected) Color(0xFF2563EB) else Color.Transparent
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isSelected) Color.White else (activeColor ?: Color(0xFF94A3B8)),
                modifier = Modifier.size(19.dp)
            )
            if (isSelected) {
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = label,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

/**
 * Bottom Sheet row item for the Plus actions.
 */
@Composable
private fun PlusActionItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 10.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF2563EB).copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF3B82F6),
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = Color.White
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}
