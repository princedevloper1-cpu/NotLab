package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CollectionsBookmark
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Collaborator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PageNavigationHeader(
    currentPageNumber: Int,
    totalPages: Int,
    pageTitle: String,
    dateModified: Long,
    collaboratorCount: Int,
    activeCollaborator: Collaborator?,
    isSoloMode: Boolean = false,
    isPrivacyMode: Boolean = false,
    onToggleSoloMode: (() -> Unit)? = null,
    onTogglePrivacyMode: (() -> Unit)? = null,
    onPreviousPage: () -> Unit,
    onNextPage: () -> Unit,
    onAddPage: () -> Unit,
    onDeletePage: () -> Unit,
    onOpenPageList: () -> Unit,
    onOpenCollaboration: () -> Unit,
    onOpenGoogleSheetsSync: (() -> Unit)? = null,
    onNavigateHome: (() -> Unit)? = null,
    onTitleChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.FRENCH) }
    val formattedDate = remember(dateModified) {
        dateFormat.format(Date(if (dateModified > 0) dateModified else System.currentTimeMillis()))
    }
    var showOptionsMenu by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            // Row 1: Book Icon, Title, Status & Overflow Menu (Clean & Non-cluttered)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Page Title with elegant notebook icon
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (onNavigateHome != null) {
                        IconButton(
                            onClick = onNavigateHome,
                            modifier = Modifier.size(28.dp).testTag("button_back_home")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Retour à l'accueil",
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                    } else {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            modifier = Modifier.size(17.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    BasicTextField(
                        value = pageTitle,
                        onValueChange = onTitleChange,
                        singleLine = true,
                        textStyle = TextStyle(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        decorationBox = { innerTextField ->
                            if (pageTitle.isBlank()) {
                                Text(
                                    text = "Page $currentPageNumber...",
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            innerTextField()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_page_title")
                    )
                }

                // Discret badge if Privacy mode is active
                if (isPrivacyMode) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f))
                            .clickable { onTogglePrivacyMode?.invoke() }
                            .padding(horizontal = 7.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.VisibilityOff,
                            contentDescription = "Mode Confidentiel actif",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Confidentiel",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                }

                // Collaboration Members Button (Minimalist Pill)
                FilledTonalButton(
                    onClick = onOpenCollaboration,
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                    modifier = Modifier.testTag("button_open_collaboration")
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = "Membres",
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (collaboratorCount > 1) "$collaboratorCount" else "Inviter",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Professional Overflow Menu (⋮) gathering secondary actions cleanly
                Box {
                    IconButton(
                        onClick = { showOptionsMenu = true },
                        modifier = Modifier.size(34.dp).testTag("button_header_menu")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = "Options supplémentaires",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    DropdownMenu(
                        expanded = showOptionsMenu,
                        onDismissRequest = { showOptionsMenu = false }
                    ) {
                        // 1. Confidentiality Mode: Hide collaborator messages to protect privacy from onlookers
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = if (isPrivacyMode) "Désactiver Mode Confidentiel" else "Mode Confidentiel (Masquer)",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        text = "Masque les messages des autres sur le cahier",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (isPrivacyMode) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = null,
                                    tint = if (isPrivacyMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            },
                            onClick = {
                                showOptionsMenu = false
                                onTogglePrivacyMode?.invoke()
                            },
                            modifier = Modifier.testTag("menu_item_privacy_mode")
                        )

                        // 2. Solo / Shared Mode Toggle
                        if (collaboratorCount > 1 && onToggleSoloMode != null) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = if (isSoloMode) "Passer en Mode Partagé" else "Passer en Mode Solo (Verrouillé)",
                                        fontSize = 13.sp
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = if (isSoloMode) Icons.Default.LockOpen else Icons.Default.Lock,
                                        contentDescription = null
                                    )
                                },
                                onClick = {
                                    showOptionsMenu = false
                                    onToggleSoloMode.invoke()
                                },
                                modifier = Modifier.testTag("button_toggle_solo_mode")
                            )
                        }

                        // 3. Google Sheets Real-Time Cloud Sync (Test)
                        if (onOpenGoogleSheetsSync != null) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(
                                            text = "Synchronisation Google Sheets",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            text = "Sauvegarde & test collaboratif (7 users)",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.outline
                                        )
                                    }
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.TableChart,
                                        contentDescription = null,
                                        tint = Color(0xFF0F9D58) // Google Sheets Green
                                    )
                                },
                                onClick = {
                                    showOptionsMenu = false
                                    onOpenGoogleSheetsSync.invoke()
                                },
                                modifier = Modifier.testTag("button_open_sheets_sync")
                            )
                        }

                        // 4. View All Pages
                        DropdownMenuItem(
                            text = { Text("Toutes les pages ($totalPages)", fontSize = 13.sp) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.CollectionsBookmark,
                                    contentDescription = null
                                )
                            },
                            onClick = {
                                showOptionsMenu = false
                                onOpenPageList()
                            },
                            modifier = Modifier.testTag("button_all_pages")
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        // 4. Delete Page (Destructive action)
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = "Supprimer cette page",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.error
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error
                                )
                            },
                            onClick = {
                                showOptionsMenu = false
                                onDeletePage()
                            },
                            modifier = Modifier.testTag("button_delete_page")
                        )
                    }
                }
            }

            // Real-time presence indicator banner (if an active collaborator is writing)
            AnimatedVisibility(
                visible = activeCollaborator != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                activeCollaborator?.let { collab ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                            .padding(horizontal = 8.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF10B981))
                                .border(1.dp, Color.White, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${collab.name} écrit sur cette page...",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Row 2: Clean, Centered Pagination & Single Primary Add Page Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Page switcher: [<] Page 1 / 3 [>]
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(horizontal = 2.dp, vertical = 1.dp)
                ) {
                    IconButton(
                        onClick = onPreviousPage,
                        enabled = currentPageNumber > 1,
                        modifier = Modifier.size(28.dp).testTag("button_prev_page")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Page précédente",
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Text(
                        text = "$currentPageNumber / $totalPages",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .clickable(onClick = onOpenPageList)
                            .padding(horizontal = 6.dp)
                            .testTag("text_page_indicator")
                    )

                    IconButton(
                        onClick = onNextPage,
                        enabled = currentPageNumber < totalPages,
                        modifier = Modifier.size(28.dp).testTag("button_next_page")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Page suivante",
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Date label subtle & elegant
                Text(
                    text = formattedDate,
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.outline
                )

                // Single Add New Page Button
                FilledTonalButton(
                    onClick = onAddPage,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 9.dp, vertical = 3.dp),
                    modifier = Modifier.testTag("button_add_page")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(text = "Page", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}
