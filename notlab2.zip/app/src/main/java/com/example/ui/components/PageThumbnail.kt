package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotebookLineEntry
import com.example.data.model.NotebookPage

/**
 * Realistic miniature notebook page thumbnail.
 * Displays page lines/drawings, spiral punch holes, and selection border.
 * Supports tap to open and long press for contextual actions (Renommer, Dupliquer, Supprimer).
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PageThumbnail(
    page: NotebookPage,
    isSelected: Boolean,
    onClick: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showContextMenu by remember { mutableStateOf(false) }

    val parsedLines = remember(page.linesJson) {
        NotebookLineEntry.listFromJson(page.linesJson)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("page_thumbnail_${page.pageNumber}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f) // Standard notebook paper ratio
                .shadow(
                    elevation = if (isSelected) 6.dp else 2.dp,
                    shape = RoundedCornerShape(10.dp)
                )
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFFFBF9F5)) // Realistic ivory paper
                .then(
                    if (isSelected) {
                        Modifier.border(2.5.dp, Color(0xFF2563EB), RoundedCornerShape(10.dp))
                    } else {
                        Modifier.border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(10.dp))
                    }
                )
                .combinedClickable(
                    onClick = onClick,
                    onLongClick = { showContextMenu = true }
                )
        ) {
            // Realistic Ruled Paper Background & Binder Holes
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Punch holes on left edge
                val holeRadius = 2.8.dp.toPx()
                val holeX = 5.dp.toPx()
                val fractions = listOf(0.15f, 0.38f, 0.62f, 0.85f)
                fractions.forEach { frac ->
                    drawCircle(
                        color = Color(0xFF0F172A),
                        radius = holeRadius,
                        center = Offset(holeX, canvasHeight * frac)
                    )
                }

                // Vertical red margin line
                val marginX = 14.dp.toPx()
                drawLine(
                    color = Color(0xFFEF4444).copy(alpha = 0.5f),
                    start = Offset(marginX, 0f),
                    end = Offset(marginX, canvasHeight),
                    strokeWidth = 1f
                )

                // Ruled faint blue lines
                val startY = 16.dp.toPx()
                val stepY = 12.dp.toPx()
                var currentY = startY
                while (currentY < canvasHeight - 6.dp.toPx()) {
                    drawLine(
                        color = Color(0xFF93C5FD).copy(alpha = 0.45f),
                        start = Offset(marginX, currentY),
                        end = Offset(canvasWidth - 4.dp.toPx(), currentY),
                        strokeWidth = 0.8f
                    )
                    currentY += stepY
                }
            }

            // Preview of lines / notes inside thumbnail
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(start = 18.dp, top = 10.dp, end = 6.dp, bottom = 6.dp)
            ) {
                if (page.title.isNotBlank()) {
                    Text(
                        text = page.title,
                        fontSize = 7.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1E293B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                val previewEntries = parsedLines.take(5)
                if (previewEntries.isNotEmpty()) {
                    previewEntries.forEach { entry ->
                        Text(
                            text = entry.content,
                            fontSize = 6.sp,
                            color = Color(0xFF334155),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            lineHeight = 10.sp
                        )
                    }
                } else if (page.textContent.isNotBlank()) {
                    Text(
                        text = page.textContent,
                        fontSize = 6.sp,
                        color = Color(0xFF475569),
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis,
                        lineHeight = 9.sp
                    )
                } else {
                    // Empty lines placeholder
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "Page vide",
                        fontSize = 6.sp,
                        color = Color(0xFF94A3B8),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(modifier = Modifier.weight(1f))
                }
            }

            // Context Menu (Renommer, Dupliquer, Supprimer)
            DropdownMenu(
                expanded = showContextMenu,
                onDismissRequest = { showContextMenu = false },
                modifier = Modifier.background(Color(0xFF1E2433))
            ) {
                // Renommer
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Renommer",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onRename()
                    },
                    modifier = Modifier.testTag("menu_rename_page_${page.pageNumber}")
                )

                // Dupliquer
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Dupliquer",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onDuplicate()
                    },
                    modifier = Modifier.testTag("menu_duplicate_page_${page.pageNumber}")
                )

                HorizontalDivider(color = Color(0xFF2E384D), thickness = 0.5.dp)

                // Supprimer
                DropdownMenuItem(
                    text = {
                        Text(
                            text = "Supprimer",
                            color = Color(0xFFEF4444),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = null,
                            tint = Color(0xFFEF4444),
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    onClick = {
                        showContextMenu = false
                        onDelete()
                    },
                    modifier = Modifier.testTag("menu_delete_page_${page.pageNumber}")
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Page label underneath thumbnail (e.g. "Page 1", "Page 2")
        Text(
            text = "Page ${page.pageNumber}",
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) Color(0xFF60A5FA) else Color(0xFFCBD5E1),
            maxLines = 1
        )
    }
}
