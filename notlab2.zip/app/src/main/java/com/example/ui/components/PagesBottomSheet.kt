package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NotebookPage

/**
 * Bottom Sheet displaying "Toutes les pages" with thumbnail previews in a grid.
 * Allows opening a page, creating a new page, renaming, duplicating, and deleting pages.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PagesBottomSheet(
    pages: List<NotebookPage>,
    currentPageIndex: Int,
    sheetState: SheetState,
    onDismiss: () -> Unit,
    onSelectPage: (Int) -> Unit,
    onAddNewPage: () -> Unit,
    onRenamePage: (NotebookPage, String) -> Unit,
    onDuplicatePage: (NotebookPage) -> Unit,
    onDeletePage: (NotebookPage) -> Unit
) {
    var pageToRename by remember { mutableStateOf<NotebookPage?>(null) }
    var renameInput by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF131722),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp)
                .padding(top = 16.dp, bottom = 28.dp)
        ) {
            // Header: "Toutes les pages" + Close 'x' button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Toutes les pages",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.testTag("text_pages_sheet_title")
                )

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("button_close_pages_sheet")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fermer",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3-Column Grid of Pages
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
                    .testTag("grid_pages"),
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 4.dp)
            ) {
                itemsIndexed(pages) { index, page ->
                    val isCurrent = index == currentPageIndex
                    PageThumbnail(
                        page = page,
                        isSelected = isCurrent,
                        onClick = {
                            onSelectPage(index)
                            onDismiss()
                        },
                        onRename = {
                            pageToRename = page
                            renameInput = page.title
                        },
                        onDuplicate = {
                            onDuplicatePage(page)
                        },
                        onDelete = {
                            onDeletePage(page)
                        }
                    )
                }

                // "+ Nouvelle page" tile at the end of the grid
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("card_add_new_page"),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(0.72f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF1A202C))
                                .border(
                                    width = 1.2.dp,
                                    color = Color(0xFF384259),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable {
                                    onAddNewPage()
                                    onDismiss()
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Ajouter une nouvelle page",
                                    tint = Color.White,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Nouvelle page",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF94A3B8)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "",
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }

    // Rename Page Dialog
    if (pageToRename != null) {
        val targetPage = pageToRename!!
        AlertDialog(
            onDismissRequest = { pageToRename = null },
            containerColor = Color(0xFF1E2433),
            title = {
                Text(
                    text = "Renommer la Page ${targetPage.pageNumber}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Entrez un nouveau titre pour cette page :",
                        color = Color(0xFF94A3B8),
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = renameInput,
                        onValueChange = { renameInput = it },
                        placeholder = { Text("Titre de la page...", color = Color(0xFF64748B)) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2563EB),
                            unfocusedBorderColor = Color(0xFF384259),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_rename_page")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRenamePage(targetPage, renameInput.trim())
                        pageToRename = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("button_confirm_rename_page")
                ) {
                    Text("Enregistrer", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { pageToRename = null }) {
                    Text("Annuler", color = Color(0xFF94A3B8))
                }
            }
        )
    }
}
