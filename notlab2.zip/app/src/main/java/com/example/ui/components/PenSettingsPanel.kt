package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Compact floating panel / bottom sheet for Drawing Tool Settings.
 * Contains:
 * - Live preview of pen tip and smooth stroke
 * - Épaisseur (1 px, 3 px, 6 px)
 * - Couleurs (presets + custom color button)
 * - Options (Lissage du trait ON/OFF, Style de plume)
 */
@Composable
fun PenSettingsPanel(
    strokeWidth: Float,
    selectedColor: Color,
    isSmoothingEnabled: Boolean,
    penStyle: String,
    onStrokeWidthSelected: (Float) -> Unit,
    onColorSelected: (Color) -> Unit,
    onSmoothingToggled: (Boolean) -> Unit,
    onPenStyleSelected: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showStyleDropdown by remember { mutableStateOf(false) }
    var showExtraColors by remember { mutableStateOf(false) }

    // Preset colors from screenshot 5: Dark, Blue, Red, Green, Yellow, Purple
    val primaryColors = listOf(
        Color(0xFF1E293B), // Noir ardoise
        Color(0xFF2563EB), // Bleu roi
        Color(0xFFEF4444), // Rouge vif
        Color(0xFF10B981), // Vert émeraude
        Color(0xFFF59E0B), // Jaune ambre
        Color(0xFF8B5CF6)  // Violet vif
    )

    // Additional custom colors accessed through "+"
    val customColors = listOf(
        Color(0xFFF97316), // Orange
        Color(0xFFEC4899), // Rose
        Color(0xFF06B6D4), // Cyan
        Color(0xFF6366F1), // Indigo
        Color(0xFF78350F), // Marron
        Color(0xFF14B8A6)  // Turquoise
    )

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .shadow(elevation = 12.dp, shape = RoundedCornerShape(20.dp))
            .testTag("pen_settings_panel"),
        shape = RoundedCornerShape(20.dp),
        color = Color(0xFF181C26),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF283042))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // 1. Header: "Outils de dessin" + 'x' Close button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Outils de dessin",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(28.dp).testTag("button_close_pen_settings")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fermer les paramètres",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Interactive Live Preview Banner: Pen tip graphic on left + smooth wave curve on right
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF0F131C))
                    .border(1.dp, Color(0xFF222938), RoundedCornerShape(12.dp))
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Pen tip graphic
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E2433)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.size(24.dp)) {
                            // Stylus body & colored nib
                            val nibPath = Path().apply {
                                moveTo(size.width * 0.5f, 2f)
                                lineTo(size.width * 0.8f, size.height * 0.7f)
                                lineTo(size.width * 0.2f, size.height * 0.7f)
                                close()
                            }
                            drawPath(nibPath, color = selectedColor)
                            drawCircle(
                                color = Color(0xFF384259),
                                radius = 4f,
                                center = Offset(size.width * 0.5f, size.height * 0.85f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    // Smooth dynamic stroke preview curve
                    Canvas(
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        val path = Path()
                        val w = size.width
                        val h = size.height

                        path.moveTo(10f, h * 0.6f)
                        if (isSmoothingEnabled) {
                            path.cubicTo(
                                w * 0.3f, h * 0.1f,
                                w * 0.7f, h * 0.9f,
                                w - 10f, h * 0.4f
                            )
                        } else {
                            path.lineTo(w * 0.35f, h * 0.2f)
                            path.lineTo(w * 0.65f, h * 0.8f)
                            path.lineTo(w - 10f, h * 0.4f)
                        }

                        val cap = when (penStyle) {
                            "Calligraphie", "Biseauté" -> StrokeCap.Square
                            else -> StrokeCap.Round
                        }

                        drawPath(
                            path = path,
                            color = selectedColor,
                            style = Stroke(
                                width = strokeWidth.coerceIn(2f, 16f),
                                cap = cap,
                                join = StrokeJoin.Round
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Épaisseur du trait: 1 px, 3 px, 6 px
            Text(
                text = "Épaisseur du trait",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFCBD5E1)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1 px
                StrokeWidthCircleItem(
                    label = "1 px",
                    dotSize = 3.dp,
                    isSelected = strokeWidth <= 2.5f,
                    onClick = { onStrokeWidthSelected(2.0f) },
                    testTag = "pen_width_1px"
                )

                // 3 px (default selected)
                StrokeWidthCircleItem(
                    label = "3 px",
                    dotSize = 7.dp,
                    isSelected = strokeWidth > 2.5f && strokeWidth <= 4.5f,
                    onClick = { onStrokeWidthSelected(4.0f) },
                    testTag = "pen_width_3px"
                )

                // 6 px
                StrokeWidthCircleItem(
                    label = "6 px",
                    dotSize = 13.dp,
                    isSelected = strokeWidth > 4.5f,
                    onClick = { onStrokeWidthSelected(7.0f) },
                    testTag = "pen_width_6px"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Couleurs: Presets + "+" button
            Text(
                text = "Couleurs",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFCBD5E1)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                primaryColors.forEach { color ->
                    val isSelected = selectedColor == color
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(color)
                            .then(
                                if (isSelected) {
                                    Modifier.border(2.5.dp, Color.White, CircleShape)
                                } else {
                                    Modifier.border(1.dp, Color(0xFF384259), CircleShape)
                                }
                            )
                            .clickable { onColorSelected(color) }
                    )
                }

                // Custom color button "+"
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF222938))
                        .border(1.dp, Color(0xFF384259), CircleShape)
                        .clickable { showExtraColors = !showExtraColors }
                        .testTag("button_custom_color_picker"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Plus de couleurs",
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Expanded custom colors row if '+' was clicked
            AnimatedVisibility(visible = showExtraColors) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    customColors.forEach { color ->
                        val isSelected = selectedColor == color
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(color)
                                .then(
                                    if (isSelected) {
                                        Modifier.border(2.5.dp, Color.White, CircleShape)
                                    } else {
                                        Modifier.border(1.dp, Color(0xFF384259), CircleShape)
                                    }
                                )
                                .clickable {
                                    onColorSelected(color)
                                    showExtraColors = false
                                }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 5. Options
            Text(
                text = "Options",
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFFCBD5E1)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Option 1: Lissage du trait (ON/OFF)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Lissage du trait",
                    fontSize = 14.sp,
                    color = Color.White
                )

                Switch(
                    checked = isSmoothingEnabled,
                    onCheckedChange = onSmoothingToggled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = Color(0xFF2563EB),
                        uncheckedThumbColor = Color(0xFF94A3B8),
                        uncheckedTrackColor = Color(0xFF222938)
                    ),
                    modifier = Modifier.testTag("switch_stroke_smoothing")
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Option 2: Style de plume (Dropdown)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Style de plume",
                    fontSize = 14.sp,
                    color = Color.White
                )

                Box {
                    Surface(
                        onClick = { showStyleDropdown = true },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF222938),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF384259)),
                        modifier = Modifier.testTag("dropdown_pen_style")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = penStyle,
                                fontSize = 13.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Choisir le style",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showStyleDropdown,
                        onDismissRequest = { showStyleDropdown = false },
                        modifier = Modifier.background(Color(0xFF1E2433))
                    ) {
                        listOf("Normal", "Calligraphie", "Biseauté").forEach { style ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = style,
                                        color = if (penStyle == style) Color(0xFF60A5FA) else Color.White,
                                        fontWeight = if (penStyle == style) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = {
                                    onPenStyleSelected(style)
                                    showStyleDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Circular option for stroke thickness selection (1 px, 3 px, 6 px)
 */
@Composable
private fun StrokeWidthCircleItem(
    label: String,
    dotSize: androidx.compose.ui.unit.Dp,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xFF1E2433))
                .then(
                    if (isSelected) {
                        Modifier.border(2.dp, Color(0xFF2563EB), CircleShape)
                    } else {
                        Modifier.border(1.dp, Color(0xFF2E384D), CircleShape)
                    }
                )
                .testTag(testTag),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(dotSize)
                    .clip(CircleShape)
                    .background(if (isSelected) Color.White else Color(0xFFCBD5E1))
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = label,
            fontSize = 11.sp,
            color = if (isSelected) Color(0xFF60A5FA) else Color(0xFF94A3B8),
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}
