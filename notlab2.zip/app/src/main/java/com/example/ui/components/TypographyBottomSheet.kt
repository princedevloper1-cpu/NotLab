package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FormatColorText
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AvailableNotebookFonts
import com.example.ui.theme.FontCategory
import com.example.ui.theme.NotebookFontItem

/**
 * Compact Bottom Sheet: "Typographie"
 *
 * Implements:
 * - Separates fonts into:
 *   1) Écriture manuscrite:
 *      - Handwriting 1, default (Caveat - natural cursive handwriting)
 *      - Handwriting 2 (Patrick Hand)
 *      - Handwriting 3 (Satisfy)
 *   2) Classique:
 *      - Roboto
 *      - Poppins
 *      - Montserrat (Other clean font)
 * - Renders each font name using its own font style as a real-time visual preview!
 * - Highlights currently selected font.
 * - All labels in French.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TypographyBottomSheet(
    selectedFontId: String,
    onFontSelected: (String) -> Unit,
    onDismiss: () -> Unit,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    modifier: Modifier = Modifier
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFF141824),
        contentColor = Color.White,
        tonalElevation = 8.dp,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        dragHandle = {
            Box(
                modifier = Modifier
                    .padding(top = 10.dp, bottom = 6.dp)
                    .size(width = 38.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color(0xFF333C52))
            )
        },
        modifier = modifier.testTag("sheet_typographie")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF2563EB).copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FormatColorText,
                            contentDescription = null,
                            tint = Color(0xFF60A5FA),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Typographie",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "Style d'écriture pour vos notes",
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(32.dp).testTag("button_close_typographie")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Fermer",
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            HorizontalDivider(
                color = Color(0xFF232A3B),
                thickness = 1.dp,
                modifier = Modifier.padding(bottom = 14.dp)
            )

            val handwritingFonts = AvailableNotebookFonts.filter { it.category == FontCategory.HANDWRITING }
            val classicFonts = AvailableNotebookFonts.filter { it.category == FontCategory.CLASSIC }

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Section 1: Écriture manuscrite
                item {
                    Text(
                        text = "Écriture manuscrite",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF60A5FA),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                items(handwritingFonts.size) { index ->
                    val fontItem = handwritingFonts[index]
                    FontSelectionCard(
                        fontItem = fontItem,
                        isSelected = fontItem.id == selectedFontId,
                        onSelect = {
                            onFontSelected(fontItem.id)
                            onDismiss()
                        }
                    )
                }

                // Section 2: Classique
                item {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Classique",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF60A5FA),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                items(classicFonts.size) { index ->
                    val fontItem = classicFonts[index]
                    FontSelectionCard(
                        fontItem = fontItem,
                        isSelected = fontItem.id == selectedFontId,
                        onSelect = {
                            onFontSelected(fontItem.id)
                            onDismiss()
                        }
                    )
                }
            }
        }
    }
}

/**
 * Single card item previewing a font using its own font style.
 */
@Composable
private fun FontSelectionCard(
    fontItem: NotebookFontItem,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) Color(0xFF1E293B) else Color(0xFF181D29),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 1.5.dp else 1.dp,
            color = if (isSelected) Color(0xFF3B82F6) else Color(0xFF262E42)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("font_card_${fontItem.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Preview font title in its OWN font family!
                    Text(
                        text = fontItem.displayName,
                        style = TextStyle(
                            fontFamily = fontItem.fontFamily,
                            fontSize = if (fontItem.category == FontCategory.HANDWRITING) 20.sp else 16.sp,
                            fontWeight = if (fontItem.category == FontCategory.HANDWRITING) FontWeight.Medium else FontWeight.SemiBold,
                            color = if (isSelected) Color.White else Color(0xFFE2E8F0)
                        )
                    )

                    if (fontItem.isDefault) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF2563EB).copy(alpha = 0.25f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Défaut",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF93C5FD)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Preview sample text in its OWN font family!
                Text(
                    text = fontItem.previewSample,
                    style = TextStyle(
                        fontFamily = fontItem.fontFamily,
                        fontSize = if (fontItem.category == FontCategory.HANDWRITING) 16.sp else 13.sp,
                        color = if (isSelected) Color(0xFF93C5FD) else Color(0xFF94A3B8)
                    ),
                    maxLines = 1
                )
            }

            // Radio / Checkmark
            Box(
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) Color(0xFF2563EB) else Color.Transparent)
                    .border(
                        width = if (isSelected) 0.dp else 1.5.dp,
                        color = if (isSelected) Color.Transparent else Color(0xFF475569),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Sélectionné",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
