package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NotlabDarkBg = Color(0xFF0F1218)
val NotlabDarkSurface = Color(0xFF161A24)
val NotlabDarkSurfaceHigh = Color(0xFF1E2330)
val NotlabDarkBorder = Color(0xFF283042)
val NotlabBlue = Color(0xFF2563EB)
val NotlabBlueLight = Color(0xFF3B82F6)
val NotlabGreen = Color(0xFF10B981)
val NotlabRed = Color(0xFFEF4444)
val NotlabPurple = Color(0xFF8B5CF6)
val NotlabYellow = Color(0xFFFBBF24)
val NotlabTextPrimary = Color(0xFFF1F5F9)
val NotlabTextSecondary = Color(0xFF94A3B8)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

