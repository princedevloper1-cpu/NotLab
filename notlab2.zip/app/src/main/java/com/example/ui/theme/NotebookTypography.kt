package com.example.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.R

enum class FontCategory(val label: String) {
    HANDWRITING("Écriture manuscrite"),
    CLASSIC("Classique")
}

data class NotebookFontItem(
    val id: String,
    val displayName: String,
    val category: FontCategory,
    val fontFamily: FontFamily,
    val isDefault: Boolean = false,
    val previewSample: String = "Plan pou pwojè Notlab la"
)

// Downloaded local TTF Google Fonts
val Handwriting1FontFamily = FontFamily(Font(R.font.caveat, FontWeight.Normal))
val Handwriting2FontFamily = FontFamily(Font(R.font.patrick_hand, FontWeight.Normal))
val Handwriting3FontFamily = FontFamily(Font(R.font.satisfy, FontWeight.Normal))

val RobotoFontFamily = FontFamily(Font(R.font.roboto, FontWeight.Normal))
val PoppinsFontFamily = FontFamily(Font(R.font.poppins, FontWeight.Normal))
val MontserratFontFamily = FontFamily(Font(R.font.montserrat, FontWeight.Normal))

val AvailableNotebookFonts = listOf(
    // Écriture manuscrite
    NotebookFontItem(
        id = "handwriting_1",
        displayName = "Handwriting 1",
        category = FontCategory.HANDWRITING,
        fontFamily = Handwriting1FontFamily,
        isDefault = true,
        previewSample = "Écriture manuscrite naturelle (Défaut)"
    ),
    NotebookFontItem(
        id = "handwriting_2",
        displayName = "Handwriting 2",
        category = FontCategory.HANDWRITING,
        fontFamily = Handwriting2FontFamily,
        previewSample = "Notes scolaires & décontractées"
    ),
    NotebookFontItem(
        id = "handwriting_3",
        displayName = "Handwriting 3",
        category = FontCategory.HANDWRITING,
        fontFamily = Handwriting3FontFamily,
        previewSample = "Cursive fluide & élégante"
    ),
    // Classique
    NotebookFontItem(
        id = "roboto",
        displayName = "Roboto",
        category = FontCategory.CLASSIC,
        fontFamily = RobotoFontFamily,
        previewSample = "Moderne, neutre et très lisible"
    ),
    NotebookFontItem(
        id = "poppins",
        displayName = "Poppins",
        category = FontCategory.CLASSIC,
        fontFamily = PoppinsFontFamily,
        previewSample = "Géométrique, chaleureux et épuré"
    ),
    NotebookFontItem(
        id = "montserrat",
        displayName = "Montserrat",
        category = FontCategory.CLASSIC,
        fontFamily = MontserratFontFamily,
        previewSample = "Élégant, contemporain et précis"
    )
)

fun getFontFamilyById(id: String): FontFamily {
    return AvailableNotebookFonts.firstOrNull { it.id == id }?.fontFamily ?: Handwriting1FontFamily
}

fun getFontDisplayName(id: String): String {
    return AvailableNotebookFonts.firstOrNull { it.id == id }?.displayName ?: "Handwriting 1"
}
