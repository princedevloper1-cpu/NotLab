package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = NotlabBlue,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    primaryContainer = androidx.compose.ui.graphics.Color(0xFF1E3A8A),
    onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFFDBEAFE),
    secondary = NotlabGreen,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    background = NotlabDarkBg,
    onBackground = NotlabTextPrimary,
    surface = NotlabDarkSurface,
    onSurface = NotlabTextPrimary,
    surfaceVariant = NotlabDarkSurfaceHigh,
    onSurfaceVariant = NotlabTextSecondary,
    surfaceContainerLowest = NotlabDarkBg,
    surfaceContainerLow = NotlabDarkSurface,
    surfaceContainer = NotlabDarkSurface,
    surfaceContainerHigh = NotlabDarkSurfaceHigh,
    surfaceContainerHighest = androidx.compose.ui.graphics.Color(0xFF252C3B),
    outline = NotlabDarkBorder,
    outlineVariant = androidx.compose.ui.graphics.Color(0xFF222836),
    error = NotlabRed,
    onError = androidx.compose.ui.graphics.Color.White
  )

private val LightColorScheme = DarkColorScheme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  // Dynamic color is available on Android 12+
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
