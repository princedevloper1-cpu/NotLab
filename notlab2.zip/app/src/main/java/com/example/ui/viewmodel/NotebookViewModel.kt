package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.NotebookDatabase
import com.example.data.model.Collaborator
import com.example.data.model.CollaboratorPresets
import com.example.data.model.DeviceContact
import com.example.data.model.DrawingPoint
import com.example.data.model.DrawingStroke
import com.example.data.model.NotebookItem
import com.example.data.model.NotebookLineEntry
import com.example.data.model.NotebookPage
import com.example.data.model.ToolType
import com.example.data.repository.NotebookRepository
import com.example.data.sheets.GoogleSheetsSyncService
import com.example.data.sheets.UserRegistrationSheetsService
import com.example.data.util.ContactHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlin.math.hypot

class NotebookViewModel(application: Application) : AndroidViewModel(application) {

    private val db = NotebookDatabase.getDatabase(application)
    private val repository: NotebookRepository = NotebookRepository(db.notebookDao())
    private val collaboratorDao = db.collaboratorDao()
    private val sheetsSyncService = GoogleSheetsSyncService(application)
    private val userRegService = UserRegistrationSheetsService(application)
    private var autoSaveJob: Job? = null

    // -------------------------------------------------------------
    // NAVIGATION & MULTI-NOTEBOOK MANAGEMENT (Home vs Editor)
    // -------------------------------------------------------------
    enum class AppScreen {
        HOME,
        NOTEBOOK_EDITOR
    }

    private val _currentScreen = MutableStateFlow(AppScreen.HOME)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val notebooksPrefs = application.getSharedPreferences("notlab_notebooks_prefs", android.content.Context.MODE_PRIVATE)

    // Pre-loaded notebooks matching the reference screenshot:
    // 1. "Nòt de réunion", 2 personnes • 8 pages, 19 sept. 2026
    // 2. "Idées App", 1 personne • 5 pages, 18 sept. 2026
    // 3. "Projets", 3 personnes • 12 pages, 17 sept. 2026
    // 4. "Personnel", 1 personne • 4 pages, 15 sept. 2026
    // 5. "Musique", 2 personnes • 6 pages, 12 sept. 2026
    private val defaultNotebooks = listOf(
        NotebookItem(
            id = "nb_1",
            title = "Nòt de réunion",
            memberCount = 2,
            pageCount = 8,
            dateModified = 1790000000000L, // 19 sept. 2026
            isShared = true,
            isFavorite = true
        ),
        NotebookItem(
            id = "nb_2",
            title = "Idées App",
            memberCount = 1,
            pageCount = 5,
            dateModified = 1789913600000L, // 18 sept. 2026
            isShared = false,
            isFavorite = true
        ),
        NotebookItem(
            id = "nb_3",
            title = "Projets",
            memberCount = 3,
            pageCount = 12,
            dateModified = 1789827200000L, // 17 sept. 2026
            isShared = true,
            isFavorite = false
        ),
        NotebookItem(
            id = "nb_4",
            title = "Personnel",
            memberCount = 1,
            pageCount = 4,
            dateModified = 1789654400000L, // 15 sept. 2026
            isShared = false,
            isFavorite = false
        ),
        NotebookItem(
            id = "nb_5",
            title = "Musique",
            memberCount = 2,
            pageCount = 6,
            dateModified = 1789395200000L, // 12 sept. 2026
            isShared = true,
            isFavorite = true
        )
    )

    private val _notebooks = MutableStateFlow<List<NotebookItem>>(
        NotebookItem.listFromJson(notebooksPrefs.getString("saved_notebooks", null)).ifEmpty { defaultNotebooks }
    )
    val notebooks: StateFlow<List<NotebookItem>> = _notebooks.asStateFlow()

    private val _activeNotebook = MutableStateFlow<NotebookItem>(_notebooks.value.first())
    val activeNotebook: StateFlow<NotebookItem> = _activeNotebook.asStateFlow()

    // -------------------------------------------------------------
    // DRAWING TOOL SETTINGS & PERSISTENCE (1px, 3px, 6px, Lissage, Plume)
    // -------------------------------------------------------------
    private val drawingPrefs = application.getSharedPreferences("notlab_drawing_prefs", android.content.Context.MODE_PRIVATE)

    private val _isStrokeSmoothingEnabled = MutableStateFlow(
        drawingPrefs.getBoolean("stroke_smoothing", true)
    )
    val isStrokeSmoothingEnabled: StateFlow<Boolean> = _isStrokeSmoothingEnabled.asStateFlow()

    private val _penStyle = MutableStateFlow(
        drawingPrefs.getString("pen_style", "Normal") ?: "Normal"
    )
    val penStyle: StateFlow<String> = _penStyle.asStateFlow()

    private val _isPenSettingsOpen = MutableStateFlow(false)
    val isPenSettingsOpen: StateFlow<Boolean> = _isPenSettingsOpen.asStateFlow()

    // Page manager bottom sheet state ("Toutes les pages")
    private val _isPagesSheetOpen = MutableStateFlow(false)
    val isPagesSheetOpen: StateFlow<Boolean> = _isPagesSheetOpen.asStateFlow()

    // All pages in notebook
    private val _pages = MutableStateFlow<List<NotebookPage>>(emptyList())
    val pages: StateFlow<List<NotebookPage>> = _pages.asStateFlow()

    // Currently selected page index (0-based) - Page 2 by default (2 / 8)
    private val _currentPageIndex = MutableStateFlow(1)
    val currentPageIndex: StateFlow<Int> = _currentPageIndex.asStateFlow()

    // Current page object
    private val _currentPage = MutableStateFlow<NotebookPage?>(null)
    val currentPage: StateFlow<NotebookPage?> = _currentPage.asStateFlow()

    // Drawing state
    private val _strokes = MutableStateFlow<List<DrawingStroke>>(emptyList())
    val strokes: StateFlow<List<DrawingStroke>> = _strokes.asStateFlow()

    // Line entries on the ruled notebook page (A, B, A, B lines)
    private val _lineEntries = MutableStateFlow<List<NotebookLineEntry>>(emptyList())
    val lineEntries: StateFlow<List<NotebookLineEntry>> = _lineEntries.asStateFlow()

    private val undoStack = mutableListOf<List<DrawingStroke>>()
    private val redoStack = mutableListOf<List<DrawingStroke>>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    // Active tool state
    private val _selectedTool = MutableStateFlow(ToolType.PEN)
    val selectedTool: StateFlow<ToolType> = _selectedTool.asStateFlow()

    // Ink color
    private val _selectedColor = MutableStateFlow(Color(0xFF1E3A8A)) // Royal Blue ink default
    val selectedColor: StateFlow<Color> = _selectedColor.asStateFlow()

    // Pen stroke width
    private val _strokeWidth = MutableStateFlow(4.0f)
    val strokeWidth: StateFlow<Float> = _strokeWidth.asStateFlow()

    // Typography preferences & states
    private val typographyPrefs = application.getSharedPreferences("notlab_typography_prefs", android.content.Context.MODE_PRIVATE)

    // Remember the user's last selected font and automatically reuse it for the next text.
    // Default font for new notebook text must be Handwriting 1 ("handwriting_1").
    private val _selectedFontId = MutableStateFlow(
        typographyPrefs.getString("selected_font_id", "handwriting_1") ?: "handwriting_1"
    )
    val selectedFontId: StateFlow<String> = _selectedFontId.asStateFlow()

    private val _selectedFontSize = MutableStateFlow(17f)
    val selectedFontSize: StateFlow<Float> = _selectedFontSize.asStateFlow()

    private val _isBold = MutableStateFlow(false)
    val isBold: StateFlow<Boolean> = _isBold.asStateFlow()

    private val _isItalic = MutableStateFlow(false)
    val isItalic: StateFlow<Boolean> = _isItalic.asStateFlow()

    private val _isUnderline = MutableStateFlow(false)
    val isUnderline: StateFlow<Boolean> = _isUnderline.asStateFlow()

    private val _selectedTextColor = MutableStateFlow(0xFF1E293B) // Dark charcoal ink default
    val selectedTextColor: StateFlow<Long> = _selectedTextColor.asStateFlow()

    private val _selectedTextAlign = MutableStateFlow("left")
    val selectedTextAlign: StateFlow<String> = _selectedTextAlign.asStateFlow()

    private val _isTypographySheetOpen = MutableStateFlow(false)
    val isTypographySheetOpen: StateFlow<Boolean> = _isTypographySheetOpen.asStateFlow()

    // Typed text content for the page
    private val _textContent = MutableStateFlow("")
    val textContent: StateFlow<String> = _textContent.asStateFlow()

    // Page title
    private val _pageTitle = MutableStateFlow("")
    val pageTitle: StateFlow<String> = _pageTitle.asStateFlow()

    // Line style: "ruled", "grid", "blank"
    private val _lineStyle = MutableStateFlow("ruled")
    val lineStyle: StateFlow<String> = _lineStyle.asStateFlow()

    // Paper tone: "ivory", "cream", "white", "vintage"
    private val _paperTone = MutableStateFlow("ivory")
    val paperTone: StateFlow<String> = _paperTone.asStateFlow()

    // Message feedback
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()

    // Collaboration states
    private val _collaborators = MutableStateFlow<List<Collaborator>>(emptyList())
    val collaborators: StateFlow<List<Collaborator>> = _collaborators.asStateFlow()

    // User registration status (onboarding)
    private val _isUserRegistered = MutableStateFlow(userRegService.isUserRegistered())
    val isUserRegistered: StateFlow<Boolean> = _isUserRegistered.asStateFlow()

    private val _isOnboardingCompleted = MutableStateFlow(userRegService.isUserRegistered())
    val isOnboardingCompleted: StateFlow<Boolean> = _isOnboardingCompleted.asStateFlow()

    fun completeOnboarding() {
        _isOnboardingCompleted.value = true
    }

    fun openAuthScreen() {
        _isOnboardingCompleted.value = false
    }

    fun loginUser(name: String, phone: String) {
        val cleanName = name.trim()
        val cleanPhone = phone.trim()
        userRegService.markLocalRegistration(cleanName, cleanPhone)
        _registeredUserName.value = cleanName
        _userPhoneNumber.value = cleanPhone
        _isUserRegistered.value = true
        _registrationError.value = null

        // Update room collaborator
        val allCollabs = _collaborators.value
        val owner = allCollabs.firstOrNull { it.isCurrentUser }
        if (owner != null) {
            viewModelScope.launch {
                collaboratorDao.updateCollaborator(
                    owner.copy(name = cleanName, phoneNumber = cleanPhone)
                )
            }
        }
    }

    private val _isRegistering = MutableStateFlow(false)
    val isRegistering: StateFlow<Boolean> = _isRegistering.asStateFlow()

    private val _registrationError = MutableStateFlow<String?>(null)
    val registrationError: StateFlow<String?> = _registrationError.asStateFlow()

    private val _registeredUserName = MutableStateFlow(userRegService.getRegisteredUserName())
    val registeredUserName: StateFlow<String> = _registeredUserName.asStateFlow()

    // Current user's phone number
    private val _userPhoneNumber = MutableStateFlow(
        userRegService.getRegisteredUserPhone().ifBlank { "+509 3700 1234" }
    )
    val userPhoneNumber: StateFlow<String> = _userPhoneNumber.asStateFlow()

    val initialWebhookUrl: String? get() = userRegService.getWebhookUrl()

    // Device contacts list
    private val _deviceContacts = MutableStateFlow<List<DeviceContact>>(emptyList())
    val deviceContacts: StateFlow<List<DeviceContact>> = _deviceContacts.asStateFlow()

    // Simulated real-time active collaborator on current page
    private val _activeCollaboratorOnPage = MutableStateFlow<Collaborator?>(null)
    val activeCollaboratorOnPage: StateFlow<Collaborator?> = _activeCollaboratorOnPage.asStateFlow()

    // Privacy & Confidentiality Mode: Hide collaborator messages to protect user privacy from onlookers
    private val _isPrivacyModeEnabled = MutableStateFlow(false)
    val isPrivacyModeEnabled: StateFlow<Boolean> = _isPrivacyModeEnabled.asStateFlow()

    private val _privacyPin = MutableStateFlow("1234")
    val privacyPin: StateFlow<String> = _privacyPin.asStateFlow()

    // Google Sheets Cloud Sync states
    private val _isSheetsSyncing = MutableStateFlow(false)
    val isSheetsSyncing: StateFlow<Boolean> = _isSheetsSyncing.asStateFlow()

    private val _spreadsheetUrl = MutableStateFlow<String?>(sheetsSyncService.getSpreadsheetUrl())
    val spreadsheetUrl: StateFlow<String?> = _spreadsheetUrl.asStateFlow()

    private val _lastSheetsSyncTime = MutableStateFlow(sheetsSyncService.getLastSyncTime())
    val lastSheetsSyncTime: StateFlow<Long> = _lastSheetsSyncTime.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureDefaultPage()
            repository.allPages.collect { pageList ->
                _pages.value = pageList
                if (pageList.isNotEmpty()) {
                    val currentIndex = _currentPageIndex.value.coerceIn(0, pageList.size - 1)
                    _currentPageIndex.value = currentIndex
                    val active = pageList[currentIndex]
                    if (_currentPage.value?.id != active.id) {
                        loadPage(active)
                    } else {
                        _currentPage.value = active
                    }
                    updateActiveCollaboratorForPage(active.pageNumber)
                }
            }
        }

        // Listen to collaborators list
        viewModelScope.launch {
            collaboratorDao.getAllCollaborators().collect { collabList ->
                _collaborators.value = collabList
                val currentPgNum = _currentPage.value?.pageNumber ?: 1
                updateActiveCollaboratorForPage(currentPgNum)
            }
        }

        // Initialize default user and sample collaborator if empty
        viewModelScope.launch {
            if (collaboratorDao.getCollaboratorCount() == 0) {
                val ownerName = _registeredUserName.value.ifBlank { "Moi (Propriétaire)" }
                val profileA = CollaboratorPresets.getProfile("A")
                val profileB = CollaboratorPresets.getProfile("B")

                collaboratorDao.insertCollaborator(
                    Collaborator(
                        name = ownerName,
                        phoneNumber = _userPhoneNumber.value,
                        tag = "A",
                        assignedPages = "1, 2, 3, 4, 5",
                        avatarColor = profileA.colorHex,
                        canWrite = true,
                        isOnline = true,
                        isCurrentUser = true
                    )
                )
                // Add sample collaborator "B" with write authorization
                collaboratorDao.insertCollaborator(
                    Collaborator(
                        name = "Alexandre (Ami B)",
                        phoneNumber = "+509 3712 3456",
                        tag = "B",
                        assignedPages = "1, 2",
                        avatarColor = profileB.colorHex,
                        canWrite = true,
                        isOnline = true,
                        isCurrentUser = false
                    )
                )
            }
        }

        // Load device contacts
        loadDeviceContacts()

        // Real-time presence simulator loop
        startRealTimePresenceSimulation()
    }

    fun loadDeviceContacts() {
        viewModelScope.launch {
            val contacts = ContactHelper.fetchDeviceContacts(getApplication())
            _deviceContacts.value = contacts
        }
    }

    private fun loadPage(page: NotebookPage) {
        _currentPage.value = page
        _pageTitle.value = page.title
        _textContent.value = page.textContent
        _lineStyle.value = page.lineStyle
        _paperTone.value = page.paperTone

        val loadedStrokes = DrawingStroke.listFromJson(page.strokesJson)
        _strokes.value = loadedStrokes

        // Load collaborative line entries (A, B, A, B lines on notebook)
        val loadedLines = NotebookLineEntry.listFromJson(page.linesJson)
        _lineEntries.value = loadedLines

        undoStack.clear()
        redoStack.clear()
        _canUndo.value = false
        _canRedo.value = false

        updateActiveCollaboratorForPage(page.pageNumber)
    }

    private fun updateActiveCollaboratorForPage(pageNumber: Int) {
        val collabs = _collaborators.value
        val activeOther = collabs.firstOrNull { collab ->
            !collab.isCurrentUser && collab.isOnline && collab.getAssignedPageList().contains(pageNumber)
        }
        _activeCollaboratorOnPage.value = activeOther
    }

    fun selectPage(index: Int) {
        val list = _pages.value
        if (index in list.indices) {
            saveCurrentPageSync()
            _currentPageIndex.value = index
            loadPage(list[index])
        }
    }

    fun nextPage() {
        val list = _pages.value
        val nextIdx = _currentPageIndex.value + 1
        if (nextIdx < list.size) {
            selectPage(nextIdx)
        }
    }

    fun previousPage() {
        val prevIdx = _currentPageIndex.value - 1
        if (prevIdx >= 0) {
            selectPage(prevIdx)
        }
    }

    fun addNewPage() {
        viewModelScope.launch {
            saveCurrentPageSync()
            val newPage = repository.addNewPage()
            val updatedList = _pages.value
            val newIdx = updatedList.indexOfFirst { it.id == newPage.id }.takeIf { it >= 0 }
                ?: (updatedList.size)
            _currentPageIndex.value = newIdx
            loadPage(newPage)
            _message.value = "Nouvelle page ajoutée ! (Page ${newPage.pageNumber})"
        }
    }

    fun deleteCurrentPage() {
        val active = _currentPage.value ?: return
        val list = _pages.value
        if (list.size <= 1) {
            clearCurrentPage()
            _message.value = "La page a été effacée. Le cahier doit contenir au moins 1 page !"
            return
        }

        viewModelScope.launch {
            val currentIdx = _currentPageIndex.value
            repository.deletePage(active)
            val newIdx = (currentIdx - 1).coerceAtLeast(0)
            _currentPageIndex.value = newIdx
            _message.value = "Page ${active.pageNumber} supprimée !"
        }
    }

    fun clearMessage() {
        _message.value = null
    }

    // Tools & Styling
    fun selectTool(tool: ToolType) {
        _selectedTool.value = tool
        if (tool == ToolType.HIGHLIGHTER) {
            _strokeWidth.value = 18.0f
        } else if (tool == ToolType.PEN && _strokeWidth.value > 10.0f) {
            _strokeWidth.value = 4.0f
        } else if (tool == ToolType.PENCIL && _strokeWidth.value > 10.0f) {
            _strokeWidth.value = 3.0f
        }
    }

    // -------------------------------------------------------------
    // NAVIGATION METHODS (Home vs Notebook Editor)
    // -------------------------------------------------------------
    fun navigateToEditor(notebook: NotebookItem? = null) {
        if (notebook != null) {
            _activeNotebook.value = notebook
        }
        _currentScreen.value = AppScreen.NOTEBOOK_EDITOR
    }

    fun navigateToHome() {
        saveCurrentPageSync()
        _currentScreen.value = AppScreen.HOME
    }

    // -------------------------------------------------------------
    // NOTEBOOK CRUD & FAVORITES
    // -------------------------------------------------------------
    private fun saveNotebooksToPrefs() {
        notebooksPrefs.edit().putString("saved_notebooks", NotebookItem.listToJson(_notebooks.value)).apply()
    }

    fun createNewNotebook(title: String = "") {
        val count = _notebooks.value.size + 1
        val newTitle = title.ifBlank { "Nòt $count" }
        val newNotebook = NotebookItem(
            title = newTitle,
            memberCount = 1,
            pageCount = 1,
            dateModified = System.currentTimeMillis(),
            isShared = false,
            isFavorite = false
        )
        val updated = listOf(newNotebook) + _notebooks.value
        _notebooks.value = updated
        _activeNotebook.value = newNotebook
        saveNotebooksToPrefs()
        navigateToEditor(newNotebook)
        _message.value = "Nouveau cahier « $newTitle » créé !"
    }

    fun selectNotebook(notebook: NotebookItem) {
        _activeNotebook.value = notebook
        navigateToEditor(notebook)
    }

    fun toggleNotebookFavorite(notebookId: String) {
        val updated = _notebooks.value.map {
            if (it.id == notebookId) it.copy(isFavorite = !it.isFavorite) else it
        }
        _notebooks.value = updated
        saveNotebooksToPrefs()
    }

    fun deleteNotebook(notebookId: String) {
        val updated = _notebooks.value.filterNot { it.id == notebookId }
        _notebooks.value = updated.ifEmpty { defaultNotebooks }
        saveNotebooksToPrefs()
        _message.value = "Cahier supprimé"
    }

    // -------------------------------------------------------------
    // PAGE MANAGER ACTIONS (Renommer, Dupliquer, Supprimer, etc.)
    // -------------------------------------------------------------
    fun openPagesSheet() {
        _isPagesSheetOpen.value = true
    }

    fun closePagesSheet() {
        _isPagesSheetOpen.value = false
    }

    fun renamePage(page: NotebookPage, newTitle: String) {
        if (newTitle.isBlank()) return
        viewModelScope.launch {
            val updated = page.copy(title = newTitle, dateModified = System.currentTimeMillis())
            repository.updatePage(updated)
            if (_currentPage.value?.id == page.id) {
                _pageTitle.value = newTitle
                _currentPage.value = updated
            }
            _message.value = "Page renommée en « $newTitle »"
        }
    }

    fun duplicatePage(page: NotebookPage) {
        viewModelScope.launch {
            saveCurrentPageSync()
            val totalCount = _pages.value.size
            val newPageNumber = totalCount + 1
            val duplicated = NotebookPage(
                pageNumber = newPageNumber,
                title = if (page.title.isNotBlank()) "${page.title} (Copie)" else "Page $newPageNumber",
                strokesJson = page.strokesJson,
                textContent = page.textContent,
                linesJson = page.linesJson,
                lineStyle = page.lineStyle,
                paperTone = page.paperTone,
                dateCreated = System.currentTimeMillis(),
                dateModified = System.currentTimeMillis()
            )
            repository.insertPage(duplicated)
            _message.value = "Page dupliquée avec succès !"
        }
    }

    fun deletePage(page: NotebookPage) {
        viewModelScope.launch {
            if (_pages.value.size <= 1) {
                clearCurrentPage()
                _message.value = "La page a été effacée. Le cahier doit contenir au moins 1 page !"
                return@launch
            }
            val currentIdx = _currentPageIndex.value
            repository.deletePage(page)
            val newIdx = (currentIdx - 1).coerceAtLeast(0)
            _currentPageIndex.value = newIdx
            _message.value = "Page ${page.pageNumber} supprimée !"
        }
    }

    // -------------------------------------------------------------
    // DRAWING TOOL SETTINGS (1 px, 3 px, 6 px, Couleurs, Lissage, Plume)
    // -------------------------------------------------------------
    fun openPenSettings() {
        _isPenSettingsOpen.value = true
    }

    fun closePenSettings() {
        _isPenSettingsOpen.value = false
    }

    fun togglePenSettings() {
        _isPenSettingsOpen.value = !_isPenSettingsOpen.value
    }

    fun setStrokeSmoothing(enabled: Boolean) {
        _isStrokeSmoothingEnabled.value = enabled
        drawingPrefs.edit().putBoolean("stroke_smoothing", enabled).apply()
    }

    fun setPenStyle(style: String) {
        _penStyle.value = style
        drawingPrefs.edit().putString("pen_style", style).apply()
    }

    fun setPenStrokeWidth(width: Float) {
        _strokeWidth.value = width
        drawingPrefs.edit().putFloat("pen_stroke_width", width).apply()
    }

    fun setPenColor(color: Color) {
        _selectedColor.value = color
        drawingPrefs.edit().putLong("pen_color", color.value.toLong()).apply()
    }

    fun selectColor(color: Color) {
        _selectedColor.value = color
    }

    fun setStrokeWidth(width: Float) {
        _strokeWidth.value = width
    }

    fun setLineStyle(style: String) {
        _lineStyle.value = style
        scheduleAutoSave()
    }

    fun setPaperTone(tone: String) {
        _paperTone.value = tone
        scheduleAutoSave()
    }

    fun updateTitle(title: String) {
        _pageTitle.value = title
        scheduleAutoSave()
    }

    fun updateTextContent(text: String) {
        _textContent.value = text
        scheduleAutoSave()
    }

    // -------------------------------------------------------------
    // LINE-BY-LINE COLLABORATION (A, B, A, B... on the notebook lines)
    // -------------------------------------------------------------

    /**
     * Appends a message from an authorized user to the next notebook line.
     * Checks if the author has permission to write.
     */
    fun addLineEntry(content: String, authorId: Long = 0L) {
        if (content.isBlank()) return

        val author = _collaborators.value.firstOrNull { it.id == authorId }
            ?: _collaborators.value.firstOrNull { it.isCurrentUser }
            ?: return

        // Verify write authorization
        if (!author.canWrite) {
            _message.value = "Action bloquée : ${author.name} n'est pas autorisé(e) à écrire sur ce cahier."
            return
        }

        val currentLines = _lineEntries.value.toMutableList()
        val nextLineIndex = currentLines.size
        val pgNum = _currentPage.value?.pageNumber ?: 1

        val newEntry = NotebookLineEntry(
            pageNumber = pgNum,
            lineIndex = nextLineIndex,
            authorName = author.name,
            authorPhone = author.phoneNumber,
            authorTag = author.tag,
            content = content,
            timestamp = System.currentTimeMillis(),
            authorColor = author.avatarColor,
            fontFamilyId = _selectedFontId.value,
            fontSizeSp = _selectedFontSize.value,
            isBold = _isBold.value,
            isItalic = _isItalic.value,
            isUnderline = _isUnderline.value,
            textColor = _selectedTextColor.value,
            textAlign = _selectedTextAlign.value
        )

        currentLines.add(newEntry)
        _lineEntries.value = currentLines
        scheduleAutoSave()
        _message.value = "Ligne ${nextLineIndex + 1} (${author.tag}) enregistrée !"

        // Sync new line to Google Sheet if token is configured
        val token = sheetsSyncService.getAccessToken()
        if (!token.isNullOrBlank()) {
            viewModelScope.launch {
                sheetsSyncService.appendSingleLine(token, pgNum, nextLineIndex + 1, newEntry)
            }
        }
    }

    // -------------------------------------------------------------
    // TYPOGRAPHY ACTIONS & PREFERENCES PERSISTENCE
    // -------------------------------------------------------------

    fun setFont(fontId: String) {
        _selectedFontId.value = fontId
        typographyPrefs.edit().putString("selected_font_id", fontId).apply()
    }

    fun setFontSize(sizeSp: Float) {
        _selectedFontSize.value = sizeSp.coerceIn(12f, 32f)
    }

    fun toggleBold() {
        _isBold.value = !_isBold.value
    }

    fun toggleItalic() {
        _isItalic.value = !_isItalic.value
    }

    fun toggleUnderline() {
        _isUnderline.value = !_isUnderline.value
    }

    fun setTextColor(color: Long) {
        _selectedTextColor.value = color
    }

    fun setTextAlign(align: String) {
        _selectedTextAlign.value = align
    }

    fun openTypographySheet() {
        _isTypographySheetOpen.value = true
    }

    fun closeTypographySheet() {
        _isTypographySheetOpen.value = false
    }

    fun deleteLineEntry(entry: NotebookLineEntry) {
        val currentLines = _lineEntries.value.toMutableList()
        currentLines.removeAll { it.id == entry.id }
        _lineEntries.value = currentLines
        scheduleAutoSave()
        _message.value = "Ligne supprimée."
    }

    /**
     * Toggles a checklist line between [ ] and [x] on tap.
     */
    fun toggleChecklistLine(entry: NotebookLineEntry) {
        val currentContent = entry.content
        val newContent = when {
            currentContent.startsWith("[ ] ") -> currentContent.replaceFirst("[ ] ", "[x] ")
            currentContent.startsWith("[x] ") -> currentContent.replaceFirst("[x] ", "[ ] ")
            currentContent.startsWith("[] ") -> currentContent.replaceFirst("[] ", "[x] ")
            else -> currentContent
        }
        if (newContent != currentContent) {
            val updated = _lineEntries.value.map {
                if (it.id == entry.id || (it.lineIndex == entry.lineIndex && it.pageNumber == entry.pageNumber)) {
                    it.copy(content = newContent)
                } else it
            }
            _lineEntries.value = updated
            scheduleAutoSave()
        }
    }

    // Plus extra actions (Screen 2)
    fun addChecklistAction() {
        addLineEntry("[ ] Nouvelle tâche à faire")
    }

    fun addShapeAction() {
        val stroke = DrawingStroke(
            toolType = ToolType.PEN.name,
            color = 0xFF2563EB,
            strokeWidth = 3f,
            points = listOf(
                DrawingPoint(100f, 320f),
                DrawingPoint(280f, 320f),
                DrawingPoint(280f, 440f),
                DrawingPoint(100f, 440f),
                DrawingPoint(100f, 320f)
            )
        )
        addStroke(stroke)
        _message.value = "Forme ajoutée sur la page !"
    }

    fun addImageAction() {
        _message.value = "Image insérée sur la page."
    }

    fun addVoiceNoteAction() {
        _message.value = "Note vocale collaborative prête à l'enregistrement 🎙️"
    }

    fun addAttachmentAction() {
        _message.value = "Pièce jointe liée à la page."
    }

    // Stroke management
    fun addStroke(stroke: DrawingStroke) {
        undoStack.add(_strokes.value)
        redoStack.clear()
        _canUndo.value = true
        _canRedo.value = false

        _strokes.value = _strokes.value + stroke
        scheduleAutoSave()
    }

    fun eraseStrokesNear(point: DrawingPoint, radius: Float = 28f): Boolean {
        val currentStrokes = _strokes.value
        var erasedAny = false

        val remainingStrokes = currentStrokes.filterNot { stroke ->
            val hits = stroke.points.any { p ->
                hypot(p.x - point.x, p.y - point.y) <= (radius + stroke.strokeWidth / 2)
            }
            if (hits) erasedAny = true
            hits
        }

        if (erasedAny) {
            undoStack.add(currentStrokes)
            redoStack.clear()
            _canUndo.value = true
            _canRedo.value = false
            _strokes.value = remainingStrokes
            scheduleAutoSave()
            return true
        }
        return false
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            val previousState = undoStack.removeAt(undoStack.lastIndex)
            redoStack.add(_strokes.value)
            _strokes.value = previousState
            _canUndo.value = undoStack.isNotEmpty()
            _canRedo.value = true
            scheduleAutoSave()
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            val nextState = redoStack.removeAt(redoStack.lastIndex)
            undoStack.add(_strokes.value)
            _strokes.value = nextState
            _canUndo.value = true
            _canRedo.value = redoStack.isNotEmpty()
            scheduleAutoSave()
        }
    }

    fun clearCurrentPage() {
        if (_strokes.value.isNotEmpty() || _textContent.value.isNotEmpty() || _lineEntries.value.isNotEmpty()) {
            undoStack.add(_strokes.value)
            redoStack.clear()
            _canUndo.value = true
            _canRedo.value = false
            _strokes.value = emptyList()
            _textContent.value = ""
            _lineEntries.value = emptyList()
            scheduleAutoSave()
            _message.value = "La page a été nettoyée !"
        }
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(400)
            saveCurrentPageSync()
        }
    }

    private fun saveCurrentPageSync() {
        val active = _currentPage.value ?: return
        val strokesJson = DrawingStroke.listToJson(_strokes.value)
        val linesJson = NotebookLineEntry.listToJson(_lineEntries.value)
        val updatedPage = active.copy(
            title = _pageTitle.value,
            textContent = _textContent.value,
            strokesJson = strokesJson,
            linesJson = linesJson,
            lineStyle = _lineStyle.value,
            paperTone = _paperTone.value,
            dateModified = System.currentTimeMillis()
        )
        _currentPage.value = updatedPage
        viewModelScope.launch {
            repository.updatePage(updatedPage)
        }
    }

    // -------------------------------------------------------------
    // COLLABORATION & GUEST MANAGEMENT (Maximum 7 collaborators)
    // -------------------------------------------------------------

    fun setUserPhoneNumber(phone: String) {
        val formatted = ContactHelper.formatPhoneNumber(phone)
        _userPhoneNumber.value = formatted
        viewModelScope.launch {
            val currentOwner = _collaborators.value.firstOrNull { it.isCurrentUser }
            if (currentOwner != null) {
                collaboratorDao.updateCollaborator(currentOwner.copy(phoneNumber = formatted))
            }
            _message.value = "Numéro du propriétaire mis à jour : $formatted"
        }
    }

    /**
     * Toggles whether all guest collaborators can write or are locked in read-only (Solo mode for user).
     */
    fun toggleAllCollaboratorsWritePermission(allowGuestsToWrite: Boolean) {
        viewModelScope.launch {
            val collabs = _collaborators.value
            collabs.forEach { collab ->
                if (!collab.isCurrentUser) {
                    collaboratorDao.updateCollaborator(collab.copy(canWrite = allowGuestsToWrite))
                }
            }
            _message.value = if (allowGuestsToWrite) {
                "Mode Partagé : Tous les collaborateurs sont autorisés à écrire."
            } else {
                "Mode Solo (Verrouillé) : Vous écrivez seul(e). Les invités sont en lecture seule 🔒."
            }
        }
    }

    /**
     * Toggles whether a collaborator is authorized to write or read-only.
     */
    fun toggleWriteAuthorization(collaborator: Collaborator, canWrite: Boolean) {
        viewModelScope.launch {
            collaboratorDao.updateCollaborator(collaborator.copy(canWrite = canWrite))
            val status = if (canWrite) "autorisé(e) à écrire." else "restreint(e) en lecture seule."
            _message.value = "${collaborator.name} est maintenant $status"
        }
    }

    /**
     * Invite / Add a collaborator (Up to 7 collaborators maximum)
     */
    fun inviteCollaborator(
        name: String,
        phoneNumber: String,
        assignedPages: List<Int>,
        canWrite: Boolean = true
    ): Boolean {
        val totalMembers = _collaborators.value.size
        if (totalMembers >= 7) {
            _message.value = "Limite atteinte : Le cahier est limité aux 7 membres (A, B, C, D, E, F, G) !"
            return false
        }

        if (name.isBlank() || phoneNumber.isBlank()) {
            _message.value = "Veuillez renseigner un nom et un numéro de téléphone."
            return false
        }

        if (!ContactHelper.isValidPhoneNumber(phoneNumber)) {
            _message.value = "Numéro invalide ! Veuillez saisir un numéro valide (au moins 8 chiffres, ex: +509 3700 1234)."
            return false
        }

        val formattedPhone = ContactHelper.formatPhoneNumber(phoneNumber)

        viewModelScope.launch {
            val pagesString = if (assignedPages.isEmpty()) "1" else assignedPages.sorted().joinToString(", ")
            val existingTags = _collaborators.value.map { it.tag }
            val assignedTag = CollaboratorPresets.getNextAvailableTag(existingTags)
            val profile = CollaboratorPresets.getProfile(assignedTag)

            val existing = collaboratorDao.getByPhone(formattedPhone)
            if (existing != null) {
                collaboratorDao.updateCollaborator(
                    existing.copy(
                        name = name,
                        phoneNumber = formattedPhone,
                        assignedPages = pagesString,
                        canWrite = canWrite,
                        isOnline = true
                    )
                )
                _message.value = "$name (${existing.tag}) mis à jour pour les pages : $pagesString"
            } else {
                collaboratorDao.insertCollaborator(
                    Collaborator(
                        name = name,
                        phoneNumber = formattedPhone,
                        tag = assignedTag,
                        assignedPages = pagesString,
                        avatarColor = profile.colorHex,
                        canWrite = canWrite,
                        isOnline = true,
                        isCurrentUser = false
                    )
                )
                _message.value = "Membre $name ajouté avec le profil unique [$assignedTag] • Pages : $pagesString"
            }

            val currentPg = _currentPage.value?.pageNumber ?: 1
            updateActiveCollaboratorForPage(currentPg)
        }
        return true
    }

    fun removeCollaborator(collaborator: Collaborator) {
        viewModelScope.launch {
            collaboratorDao.deleteCollaborator(collaborator)
            _message.value = "${collaborator.name} a été retiré(e) du cahier."
            val currentPg = _currentPage.value?.pageNumber ?: 1
            updateActiveCollaboratorForPage(currentPg)
        }
    }

    fun updateCollaboratorPages(collaborator: Collaborator, newAssignedPages: List<Int>) {
        viewModelScope.launch {
            val pagesString = newAssignedPages.sorted().joinToString(", ")
            collaboratorDao.updateCollaborator(collaborator.copy(assignedPages = pagesString))
            _message.value = "Pages mises à jour pour ${collaborator.name} : $pagesString"
            val currentPg = _currentPage.value?.pageNumber ?: 1
            updateActiveCollaboratorForPage(currentPg)
        }
    }

    fun setPrivacyPin(newPin: String) {
        if (newPin.length >= 4) {
            _privacyPin.value = newPin
            _message.value = "Code PIN de confidentialité mis à jour avec succès."
        } else {
            _message.value = "Le code PIN doit comporter au moins 4 chiffres."
        }
    }

    fun togglePrivacyMode(enable: Boolean, enteredPin: String = ""): Boolean {
        if (!enable) {
            // Unlocking requires PIN if one was set
            if (_privacyPin.value.isNotEmpty() && enteredPin != _privacyPin.value) {
                _message.value = "Code PIN incorrect. Impossible d'afficher les messages masqués."
                return false
            }
            _isPrivacyModeEnabled.value = false
            _message.value = "Mode Confidentiel désactivé : Tous les messages sont visibles."
            return true
        } else {
            _isPrivacyModeEnabled.value = true
            _message.value = "Mode Confidentiel activé 🔒 : Les messages des collaborateurs sont masqués."
            return true
        }
    }

    private fun startRealTimePresenceSimulation() {
        viewModelScope.launch {
            while (true) {
                delay(8000)
                val currentPg = _currentPage.value?.pageNumber ?: 1
                val collabs = _collaborators.value
                val friend = collabs.firstOrNull { !it.isCurrentUser && it.getAssignedPageList().contains(currentPg) }
                if (friend != null) {
                    _activeCollaboratorOnPage.value = friend.copy(isOnline = true)
                } else {
                    _activeCollaboratorOnPage.value = null
                }
            }
        }
    }

    // -------------------------------------------------------------
    // GOOGLE SHEETS SYNC OPERATIONS
    // -------------------------------------------------------------

    fun saveSheetsAccessToken(token: String) {
        sheetsSyncService.saveAccessToken(token)
        _message.value = "Jeton Google Sheets configuré !"
    }

    fun syncCurrentNotebookToGoogleSheets(tokenOverride: String? = null) {
        val token = tokenOverride ?: sheetsSyncService.getAccessToken()
        if (token.isNullOrBlank()) {
            _message.value = "Veuillez connecter votre compte Google pour synchroniser avec Google Sheets."
            return
        }

        viewModelScope.launch {
            _isSheetsSyncing.value = true
            _message.value = "Synchronisation vers Google Sheets en cours..."

            // Ensure current page changes are committed
            saveCurrentPageSync()

            val result = sheetsSyncService.syncAllToSheets(
                token = token,
                pages = _pages.value,
                collaborators = _collaborators.value
            )

            result.onSuccess { url ->
                _spreadsheetUrl.value = url
                _lastSheetsSyncTime.value = System.currentTimeMillis()
                _message.value = "Synchronisation Google Sheets réussie ! Feuille mise à jour."
            }.onFailure { err ->
                _message.value = "Échec synchronisation Google Sheets: ${err.message ?: "Erreur réseau"}"
            }

            _isSheetsSyncing.value = false
        }
    }

    fun pullLinesFromGoogleSheets(tokenOverride: String? = null) {
        val token = tokenOverride ?: sheetsSyncService.getAccessToken()
        if (token.isNullOrBlank()) {
            _message.value = "Veuillez fournir un jeton Google pour importer les lignes."
            return
        }

        viewModelScope.launch {
            _isSheetsSyncing.value = true
            val result = sheetsSyncService.fetchLinesFromSheet(token)

            result.onSuccess { rows ->
                if (rows.isNotEmpty()) {
                    val currentPg = _currentPage.value?.pageNumber ?: 1
                    val newLinesForThisPage = mutableListOf<NotebookLineEntry>()

                    rows.forEachIndexed { index, row ->
                        // Expected row format: [Page, Ligne, Auteur Tag, Nom Auteur, Téléphone, Contenu Ligne, Date]
                        val pg = row.getOrNull(0)?.toIntOrNull() ?: 1
                        if (pg == currentPg) {
                            val tag = row.getOrNull(2) ?: "B"
                            val name = row.getOrNull(3) ?: "Collaborateur"
                            val phone = row.getOrNull(4) ?: ""
                            val content = row.getOrNull(5) ?: ""
                            if (content.isNotBlank()) {
                                val authorColor = CollaboratorPresets.getProfile(tag).colorHex
                                newLinesForThisPage.add(
                                    NotebookLineEntry(
                                        id = (index + 1).toString(),
                                        pageNumber = pg,
                                        lineIndex = index,
                                        authorName = name,
                                        authorPhone = phone,
                                        authorTag = tag,
                                        content = content,
                                        timestamp = System.currentTimeMillis(),
                                        authorColor = authorColor
                                    )
                                )
                            }
                        }
                    }

                    if (newLinesForThisPage.isNotEmpty()) {
                        _lineEntries.value = newLinesForThisPage
                        scheduleAutoSave()
                        _message.value = "${newLinesForThisPage.size} lignes importées depuis Google Sheets !"
                    } else {
                        _message.value = "Aucune nouvelle ligne trouvée pour la page $currentPg."
                    }
                }
            }.onFailure { err ->
                _message.value = "Échec lecture Google Sheets: ${err.message}"
            }
            _isSheetsSyncing.value = false
        }
    }

    /**
     * Enregistre l'utilisateur avec son nom et numéro de téléphone directement dans la base Google Sheets.
     * Si l'enregistrement dans la base Google Sheets échoue, l'utilisateur n'est pas validé.
     */
    fun registerUser(name: String, phone: String, webhookUrl: String? = null) {
        viewModelScope.launch {
            _isRegistering.value = true
            _registrationError.value = null
            val cleanName = name.trim()
            val cleanPhone = phone.trim()

            val regResult = userRegService.registerUser(
                name = cleanName,
                phone = cleanPhone,
                webhookUrl = webhookUrl
            )

            if (regResult.isSuccess) {
                _userPhoneNumber.value = cleanPhone
                _registeredUserName.value = cleanName
                _isUserRegistered.value = true
                _isRegistering.value = false
                _registrationError.value = null

                // Mettre à jour l'auteur propriétaire dans la base Room
                val allCollabs = _collaborators.value
                val owner = allCollabs.firstOrNull { it.isCurrentUser }
                if (owner != null) {
                    collaboratorDao.updateCollaborator(
                        owner.copy(name = cleanName, phoneNumber = cleanPhone)
                    )
                } else {
                    collaboratorDao.insertCollaborator(
                        Collaborator(
                            name = cleanName,
                            phoneNumber = cleanPhone,
                            tag = "A",
                            assignedPages = "1, 2, 3, 4, 5",
                            avatarColor = 0xFF1E3A8A,
                            canWrite = true,
                            isOnline = true,
                            isCurrentUser = true
                        )
                    )
                }

                val msg = regResult.getOrNull() ?: "Inscription enregistrée avec succès dans la base Google Sheets !"
                _message.value = msg
            } else {
                _isRegistering.value = false
                val errorMsg = regResult.exceptionOrNull()?.message
                    ?: "Échec de l'enregistrement dans la base de données Google Sheets."
                _registrationError.value = errorMsg
                _message.value = errorMsg
            }
        }
    }

    fun clearRegistrationError() {
        _registrationError.value = null
    }

    override fun onCleared() {
        super.onCleared()
        saveCurrentPageSync()
    }
}
