package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.NotebookLineEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Cahier de Notes", appName)
  }

  @Test
  fun `notebook line entry default font is handwriting 1`() {
    val entry = NotebookLineEntry(
      pageNumber = 1,
      lineIndex = 0,
      authorName = "Alexandre",
      authorPhone = "+50912345678",
      authorTag = "A",
      content = "Bonjou Notlab"
    )

    assertEquals("handwriting_1", entry.fontFamilyId)
    assertEquals(17f, entry.fontSizeSp, 0.01f)
    assertFalse(entry.isBold)
    assertFalse(entry.isItalic)
    assertFalse(entry.isUnderline)
    assertEquals("left", entry.textAlign)
  }

  @Test
  fun `notebook line entry typography serialization roundtrip`() {
    val entry = NotebookLineEntry(
      pageNumber = 2,
      lineIndex = 3,
      authorName = "Marie",
      authorPhone = "+50987654321",
      authorTag = "M",
      content = "Texte personnalisé",
      fontFamilyId = "handwriting_2",
      fontSizeSp = 20f,
      isBold = true,
      isItalic = true,
      isUnderline = true,
      textColor = 0xFF2563EB,
      textAlign = "center"
    )

    val json = entry.toJson()
    val restored = NotebookLineEntry.fromJson(json)

    assertEquals("handwriting_2", restored.fontFamilyId)
    assertEquals(20f, restored.fontSizeSp, 0.01f)
    assertTrue(restored.isBold)
    assertTrue(restored.isItalic)
    assertTrue(restored.isUnderline)
    assertEquals(0xFF2563EB, restored.textColor)
    assertEquals("center", restored.textAlign)
  }
}
